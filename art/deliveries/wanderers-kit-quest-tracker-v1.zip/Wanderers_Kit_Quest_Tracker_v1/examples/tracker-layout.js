// Engine-neutral reference. Quest data, IDs, icons and commands stay game-owned.
export function trackerView(quests, {width=420, folded=false, maxVisible=8}={}) {
  const rows = folded ? [] : quests.slice(0,maxVisible).map((q,i)=>({
    questId:q.id,
    rect:[0,54+i*88,width,80],
    background:'tracker-entry',
    seal:q.ready ? 'seal-check' : 'seal-hourglass',
    icon:q.existingObjectiveIcon, // Existing inventory/combat texture reference.
    objective:q.shortObjective,
    count:`${q.current} / ${q.target}`,
    detail:q.ready ? {kind:'caption',text:'Ready to turn in'} : {
      kind:'progress',value:q.target>0 ? Math.max(0,Math.min(1,q.current/q.target)) : 0
    },
    tooltip:{questTitle:q.title,town:q.town}
  }));
  return {
    headerCount:quests.length,
    header:[0,0,240,44],
    chevron:folded?'chevron-right':'chevron-down',
    rows,
    size:[folded?240:width,rows.length ? 54+rows.length*80+(rows.length-1)*8 : 44],
    overflowCount:folded?0:Math.max(0,quests.length-maxVisible)
  };
}

export function entryFields(width, countText, measureBold18) {
  const right=width-32;
  const countWidth=Math.max(78,Math.ceil(measureBold18(countText)));
  return {
    pin:[width/2-8,-3,16,16],
    seal:[12,16,48,48],
    icon:[76,14,52,52],
    objective:[144,10,Math.max(0,right-countWidth-10-144),28],
    count:[right-countWidth,10,countWidth,28],
    countRight:right,
    track:[144,50,width-160,12],
    fill:[147,53,width-166,6],
    ready:[144,43,width-160,28]
  };
}
