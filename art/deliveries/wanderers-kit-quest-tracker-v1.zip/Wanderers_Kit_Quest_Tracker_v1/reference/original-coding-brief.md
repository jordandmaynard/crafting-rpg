# Wanderer's Kit: Quest Tracker v1, art brief

## What it is

Emberwild's quest tracker is a small HUD list down the left edge of the screen. It shows the quests the player has accepted from a town's quest board. It is always on screen over the 3D world, which can be grass, stone, water, snow or night. So the pieces need solid backing and a dark edge or soft shadow so they stay readable anywhere.

It must match the Wanderer's Kit quest board (v1): warm timber, parchment, brass pins and wax seals. Today the game builds the tracker from the board's status tags. Those are too tall and too ornate to stack, and their ribbons can't take a second row, so the result looks messy (see the v583 screenshot in the thread).

## Reference layout

- Reference viewport: 1920×1080. The game scales the whole tracker uniformly from its top-left corner.
- Position: about 14 px from the left edge, about 210 px from the top.
- From the top down:
  1. The header tab.
  2. Up to about 8 quest entries, stacked with a 6 px gap.
- Folded, only the header tab shows.

## Pieces needed

Please supply lossless RGBA PNGs at 2× the logical size, with no text baked in. Say the slice borders in source pixels, as in the board kit's `assets.json`.

1. **Header tab**
   - About 190×44 logical.
   - Holds a fold chevron, the word "Quests" and a count, e.g. `‹ Quests 3`.
   - Horizontal three-slice or nine-slice so it can widen for other languages.
   - Hover, pressed and disabled states are done in code by tinting: ×1.08, ×0.9 and 1 px down, ×0.72.
2. **Chevron glyphs**
   - Fold and unfold, 20×20 logical.
   - White alpha masks, tinted in code. The board kit's chevrons can be reused if they suit.
3. **Quest entry plate**
   - About 360×60 logical.
   - Horizontal three-slice: a fixed left section with a round socket for the state emblem, a stretchable middle, and a fixed right cap.
   - Two text rows fit on it: the objective, plus a progress bar under it.
   - Should stack cleanly, lighter in weight than the board's status tag.
   - One neutral plate is enough. If the ready state needs a different plate, supply both: "in progress" and "ready to turn in".
4. **State emblems**
   - Two, about 40×40 logical, sitting in the plate's socket.
   - In progress: the hourglass seal, blue-grey, as on the board.
   - Ready to turn in: the check seal, olive green, as on the board.
   - Optional: a soft glow ring for the ready state, which code can pulse.
5. **Progress bar**
   - Thin track, about 270×12 logical, as a nine-slice with its borders.
   - Fill sprite with its content rectangle, as the board kit's `progress-fill` has.
   - A second fill in the ready colour is optional.

## Runtime text (drawn by the game, not baked)

- Objective and count, e.g. `Deliver leather` with `3 / 3` right-aligned.
- Wanderer's Kit serif, 17–18 px bold.
- Say which ink colour reads best on the plate.
- The quest title and town show as a hover tooltip only.

## Suggested entry layout (logical px; change it if the art wants otherwise)

| Element | x, y, w, h |
|---|---|
| Plate | 0, 0, 360, 60 |
| Emblem | 8, 10, 40, 40 |
| Objective text | 58, 8, 230, 24 |
| Count (right-aligned) | 288, 8, 60, 24 |
| Progress track | 58, 36, 290, 12 |

## Deliverables, as with the quest board kit

- `assets/`: the PNGs.
- `assets.json`: sizes, logical sizes and slice borders.
- `layout.json`: the rectangles above, as final.
- `HANDOFF.md`.
- A preview of three stacked entries (two in progress, one ready) and the folded tab. Show them over a bright grass background and a dark night background.
