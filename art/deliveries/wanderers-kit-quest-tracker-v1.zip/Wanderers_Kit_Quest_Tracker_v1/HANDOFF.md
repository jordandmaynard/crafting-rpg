# Wanderer’s Kit — Quest Tracker v1

Approved direction: the **wider parchment tracker with the original full-size seals and a separate item/combat icon column**. The existing inventory icons and crossed-swords art remain game-owned. None are remade or exported into this kit.

## What is supplied

`assets/` contains ten lossless, transparent RGBA PNGs, all at **2 source pixels per logical pixel**. They are blank reusable art with no objective, count, header word or ready caption baked in. The three wax emblems intentionally contain their hourglass/check/laurel designs.

| Asset | Source pixels | Logical size | Use |
|---|---|---|---|
| `tracker-header.png` | 480×88 | 240×44 | Blank timber tab, complete end rivets |
| `tracker-entry.png` | 840×160 | 420×80 | Neutral parchment for active and ready entries |
| `seal-hourglass.png` | 96×96 | 48×48 | Blue-gray active quest seal |
| `seal-check.png` | 96×96 | 48×48 | Olive green ready seal |
| `seal-laurel.png` | 96×96 | 48×48 | Gold laurel seal, supplied for reuse |
| `progress-track.png` | 520×24 | 260×12 | Empty thin track, adapted from the board kit |
| `progress-fill.png` | 32×24 | See fill UVs below | Same board-kit olive fill |
| `pin-brass.png` | 32×32 | 16×16 | Separate small brass pin, reused from the board kit |
| `chevron-right.png` | 40×40 | 20×20 | White mask, folded |
| `chevron-down.png` | 40×40 | 20×20 | White mask, expanded |

`extras/seals/` additionally contains the **same three complete standalone seals at 256×256**, for larger uses elsewhere. These are not attached to ribbons or paper and have no broad glow/haze outside their wax perimeter. Gold laurel is an optional extra; it does not add unaccepted offers to this accepted-quest HUD or change quest-state rules.

`assets.json` lists all dimensions, logical sizes, source-pixel slice borders and SHA-256 hashes. `layout.json` is the authoritative layout. `examples/tracker-layout.js` gives engine-neutral placement, text reservation and fill calculations. The preview/reference files are not runtime sprites.

## Changes from the coding brief

These changes follow the approved mockup rather than forcing its art back into the earlier size suggestions:

| Element | Initial suggestion | Final |
|---|---|---|
| Entry | About360×60 | **420×80** |
| Header | About190×44 | **240×44** |
| State emblem canvas | About40×40 | **48×48**, preserved as the prominent seal |
| Objective art | None | **52×52 contain box** for existing item/combat art |
| Gap between entries | 6 | **8** |
| Ready detail row | Full progress bar | **“Ready to turn in”** caption instead |
| State backing | Possible separate ready plate | **One neutral paper plate** for both states |

The larger image boxes include the original item sprites’ transparent padding. Do not crop or stretch them to make their painted silhouettes fill the box. No seal reduction is needed to fit the icon column. Both rows still use the same18px objective/count font; the extra paper height gives physical edges, a pin, seals and text clear breathing room.

## Import and slicing

Import all runtime PNGs as sRGB, straight/unassociated alpha, with normal alpha blending and linear filtering. Disable automatic trimming and importer padding changes. All sprites have a transparent safety border and cleared transparent RGB. The parchment’s usable center is fully opaque, so the world cannot wash through its text backing. If your engine premultiplies internally, convert once and use the corresponding blending; do not premultiply twice.

Keep both header and entry height fixed at their logical values and stretch horizontally only. First scale source height by0.5, then preserve the fixed end widths below while stretching the center. Borders are in **source pixels**, not logical pixels.

| Sprite | Slice method | Source-pixel borders |
|---|---|---|
| Header | Horizontal three-slice | Left72, right72 |
| Entry | Horizontal three-slice | Left96, right96 |
| Track | Nine-slice | Left16, top6, right16, bottom6 |

At2× density, header end sections become36px each and paper ends48px each. Do not stretch the header rivets, paper folded corner or progress end caps. The paper has no baked socket: the seal is a separate overlay. The pin is also separate so it can stay at the center when a plate widens. Never tile a small center strip repeatedly; stretch the quiet continuous center to avoid a stamped/repeating band.

The seals and chevrons use uniform scaling. Do not slice a seal, clip its lobes, attach a strip to its right edge or tint its material differently at night. The larger256px seal extras come from the same master cutouts as the96px HUD art.

## Placement and stacking

Reference viewport: **1920×1080**. Tracker anchor: **(14,210)**. Scale the entire tracker uniformly from its top-left anchor under the game’s existing HUD/DPI policy, including fonts, sprites, spacing and hit regions.

Header is at local(0,0), size240×44. First entry starts at **y54** (44px header plus10px gap). Entry `i` starts at **(0,54+i×88)**. Three entries occupy310px total height; eight occupy750px, ending at screen y960 at reference scale. Do not add a full wooden frame around the list.

Folded state draws only the header with a right chevron. Its interaction bounds must shrink to the header’s240×44 area; invisible old entry bounds must not steal world clicks. Expanded state uses the down chevron. Keep the current tracked/accepted count visible in both states. For no entries, follow the existing game policy for showing the header or hiding an empty tracker; do not invent disabled quest behavior.

If more quests exist than the current visible tracking limit, use the game’s existing tracking/overflow behavior. The eight-entry reference is a layout capacity, not a new rule deleting or abandoning accepted quests. The example view reports overflow explicitly rather than discarding data.

## Header and entry rectangles

All values are logical pixels relative to the relevant component’s top-left.

| Header element | x,y,width,height |
|---|---|
| Tab | 0,0,240,44 |
| Chevron | 24,12,20,20 |
| “Quests” label | 56,6,112,32 |
| Count | 176,6,40,32 |

The count is centered in its field; for localized wider headers it can remain at center x=`headerWidth-34`. Grow the middle of the tab if the actual font/language needs more room. Keep both rivets clear. Do not bake “Quests”, a numeral or a chevron into the background.

| Entry element | x,y,width,height |
|---|---|
| Paper | 0,0,420,80 |
| Pin | 202,-3,16,16 |
| State seal | 12,16,48,48 |
| Existing objective icon | 76,14,52,52 |
| Objective text | 144,10,156,28 |
| Count, right-aligned | 310,10,78,28 |
| Active progress track | 144,50,260,12 |
| Active inner fill | 147,53,254,6 |
| Ready caption, replaces bar | 144,43,260,28 |

The count’s right edge is **x388**, intentionally inset32px from the paper’s right edge to clear the folded corner. The bar can extend to x404 because it sits lower than that fold. The pin crosses the paper’s top edge, while its16px canvas remains clear of the text. Entry pitch88 leaves it clear of the preceding plate.

For a wider localized plate of width`W`, keep the seal, icon and left text start unchanged. Set pin x=`W/2-8`, count right edge=`W-32`, track width=`W-160`, and fill width=`W-166`. Maintain the same80px height. Reference widths420,460 and500 are shown in the slice stress preview.

## Text, icons and progress

Reuse the shipped Wanderer’s Kit serif. The preview uses DejaVu Serif for spacing only; no new font is bundled. Objective/count: **18px bold**, ink **`#4a2c18`**. Ready caption:18px bold, dark olive **`#485b26`**. Header word/count:22px, cream **`#f3dfb5`**. White chevrons are alpha masks, tinted to the same cream.

Only the short objective and count appear on the plate. Quest title and town remain hover/focus tooltip content; do not add a title row that crowds the two-row design. Bind all text and tooltip data by quest ID.

Measure the count first. Reserve at least78px for it, increasing the reservation for wider values (e.g.125/1000); then shorten the objective with an ellipsis and expose its full wording in the tooltip. Keep a10px gap between objective and count. Never truncate an actual numeric count or let it overlap the objective. If a localization cannot fit a meaningful short objective, widen the parchment’s center or use the game’s established localized short label, rather than shrinking the seal.

Use the existing inventory item sprite for gathering/delivery, and the **existing crossed-swords/combat sprite** for kill objectives. Contain-fit the complete sprite in52×52 without recoloring, posterizing, adding a background frame or changing its inventory appearance. These textures stay in the existing item/icon registry. The package’s `assets/` and `extras/` contain no item or combat icon file.

For an active objective, draw the empty track and then its fill. The fill PNG’s source content rectangle is **(4,4,24,16)** inside the32×24 canvas. Use that rectangle as the fill UVs, stretch it to the full254×6 logical trough, then clip horizontally to the completion fraction. Do not scale the full track/caps with progress. Clamp the fraction to0..1 and handle a zero/invalid target through the current quest model without division by zero.

For a ready objective, keep the same paper and count, select the green check seal, hide track/fill and draw **“Ready to turn in”**. Read readiness from the authoritative quest state; do not infer it solely from a stale display count. The tracker is informational: the caption does not add a claim/accept/reroll button or replace the board’s turn-in action.

## States and event routing

Use one normal header/plate texture. Header hover RGB×1.08; pressed RGB×0.90 with the whole header, label, count and chevron shifted down1px; unavailable RGB×0.72. Alpha remains unchanged. Leave the entry stack anchor fixed when the header is pressed, so rows do not jump. No separate painted pressed/hover/disabled asset is needed.

The entry paper is identical for active and ready states. The seal/caption supply status; no green paper variant or pulse glow is required. Keep status text as well as color so readiness is not communicated by hue alone. Hovering an entry should continue to resolve the parent quest tooltip even when the pointer is over its seal, icon or progress bar. Those decorative children should not become independent action targets.

Do not apply world lighting, a night color grade or a dimming scrim to the tracker art. It uses the exact same textures and ink colors on bright grass, snow, stone and at night. The opaque backing and narrow edge/shadow provide contrast. The normal HUD does not block input outside its visible plates/header or create a full-screen modal.

## Preview and validation

`previews/bright-and-night.png` shows the same three-entry assembly and folded header on both backgrounds, enlarged1.25× for review. `expanded-transparent.png` and `folded-transparent.png` are the native logical-size review assemblies. `eight-entry-stack.png` checks the full stack height. `standalone-seals.png` shows the96px HUD seals and256px extras. `asset-contact-sheet.png` shows all blank runtime pieces, and `slice-stress-check.png` checks wider paper and long counts/objectives. These preview images contain demonstration text and existing item art; import only the runtime sprites as sprites.

The reference folder preserves the approved widened mockup, original coding brief and built-in image-edit prompt provenance. Each seal was produced independently with a full wax silhouette, avoiding adjacent-glyph crop contamination. Progress, pin and chevron art reuse the board kit. Technical finishing includes silhouette/stray-alpha cleanup, transparent padding,2× export and center-only horizontal fitting. All final runtime text remains separate.

`validation.json` records PNG sizes,2× density, alpha borders, cleared transparent RGB, hashes, opaque paper backing and eight-entry fit. Final packing also decodes every PNG, parses every JSON and checks ZIP CRC. The assemblies were visually reviewed for complete paper/seal edges, clear text/count spacing and unchanged day/night UI colors. The coding agent still needs application checks for the shipped font, DPI, tooltip/focus routing, live quest updates and header fold persistence.
