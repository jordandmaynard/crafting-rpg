# Wanderer’s Kit — Field Compass A

Start with HANDOFF.md and layout.json. Install ui/minimap/ at logical sizes, not raw texture sizes. No zoom buttons.

Open preview.html after extracting the entire folder. The game map and clock remain live integration inputs. assembled-preview.png is a static reference; all-pieces-dark-light.png shows the cuts.

Seven watch PNGs and the celestial renderer are reused unchanged. Sources are reference art only, not runtime assets.
