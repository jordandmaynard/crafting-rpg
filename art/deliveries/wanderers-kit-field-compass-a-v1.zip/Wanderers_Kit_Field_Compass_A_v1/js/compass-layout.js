(function (root) {
  'use strict';
  function norm(degrees) {
    if (!Number.isFinite(degrees)) throw new TypeError('Bearing must be finite.');
    return ((degrees % 360) + 360) % 360;
  }
  function state({northLocked = true, cameraBearingDeg = 0, playerBearingDeg = 0} = {}) {
    const upBearingDeg = northLocked ? 0 : norm(cameraBearingDeg);
    const cardinals = ['N','E','S','W'].map((label, i) => {
      const angle = (i * 90 - upBearingDeg) * Math.PI / 180;
      return {label, x:174 + 143 * Math.sin(angle), y:164 - 143 * Math.cos(angle), rotationDeg:0};
    });
    return {upBearingDeg, mapRotationDeg:-upBearingDeg, tickRotationDeg:-upBearingDeg,
      playerRotationDeg:norm(playerBearingDeg - upBearingDeg), cardinals};
  }
  const api = {normalizeBearing:norm, state};
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.WandererCompass = api;
})(typeof window !== 'undefined' ? window : globalThis);
