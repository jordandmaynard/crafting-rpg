# Wanderer’s Kit — Field Compass A

Replace the rectangular minimap, separate compass disk and old watch casing with the approved round A design. Remove both zoom buttons. Keep the existing minimap renderer, exploration data, world-map action and authoritative game clock. This package supplies art and a reference adapter; it does not modify a game repository.

## Install and reuse

Install the PNGs in `ui/minimap/`. PNGs are lossless sRGB straight RGBA. New frame exports are at **2× logical size**; do not interpret texture dimensions as UI dimensions. Use `layout.json` for placement and `manifest.json` for file dimensions and hashes. Keep smooth sampling for painted UI art and nearest-neighbor sampling for map terrain.

The following are copied **byte for byte** from `wanderers-kit-minimap-watch-b-v1`:

- `sky-day.png`, `sky-dawn.png`, `sky-dusk.png`, `sky-night.png`
- `sun.png`, `moon.png`, `watch-index.png`
- `js/celestial-watch.js`, `transitions.json`, Spectral fonts and license

If these exact watch files are already installed, keep them. The new `watch-housing.png` replaces the old bezel because the rectangular minimap’s old bezel has an adjoining upper edge, and A needs a complete separate enclosure with a location tag. Its scale is now along the bottom, matching A. The old `minimap-frame.png`, `watch-bezel.png`, `compass-face.png` and `compass-needle.png` are not part of the new assembly. Leave them available for any other screens that still use them; remove only their old minimap instances.

`lock-button.png` reuses the old circular leather/brass face at a smaller size. The closed/open padlock glyphs are separate semantic states. Hover, selected and unavailable treatments use tints of normal art; no additional frame textures are needed.

## Parts and layer order

| Back to front | File / live content | Behavior |
|---|---|---|
| Map | Game minimap and parchment fog | Circular clip; rotate map content in free mode. |
| Watch sky | Existing celestial-watch canvas | Scrolling sky and independent sun/moon. |
| Leather case | `compass-ring.png` | Fixed orientation; transparent center. |
| Compass marks | `compass-ticks.png` | Rotate around the map center with map orientation. |
| Compass letters | Live N/E/S/W or `cardinal-*.png` | Orbit with compass; individual letters remain upright. |
| Player marker | Existing game marker | Heading relative to map orientation. Demo triangle is not a production asset. |
| Watch case/tag | `watch-housing.png` | Fixed; transparent sky opening, blank parchment. |
| Watch pointer | Reused `watch-index.png` | Fixed, centered over watch. |
| Place / time | Live game strings | Dark brown Spectral; do not bake into textures. |
| Compass mode | `lock-button.png` + closed/open glyph | North lock toggle, separate hit target. |

`map-aperture-mask.png` is an optional white-alpha circular mask for engines that need a sprite mask. It has the same registration as the ring; place at the ring rect. Engines with a circular scissor/stencil can use the numeric clip instead. Do not draw this mask as a white layer.

## Exact geometry

All coordinates below are **group-local logical pixels**, before HUD scale. Group size is **348×426**. Anchor top **18**, right **20**, using the actual viewport edges. Apply one group scale `s=min(viewportWidth/1920,viewportHeight/1080)`; do not apply it again to children. Artwork keeps its aspect ratio; no nine-slicing or repeating of the ring or housing.

| Element | x, y, width, height / geometry |
|---|---|
| Ring and tick textures | 10, 0, 328, 328 |
| Map center / rotation pivot | 174, 164 |
| Map clip | Circle radius 131; painted aperture edge is approximately 128–130 |
| Visible outer ring | Radius 156; transparent export padding retained |
| Cardinal centers | Radius 143 around map center |
| Cardinal fallback sprites | 32×32, centered on each calculated position |
| Watch housing + blank tag | 26, 326, 296, 98 |
| Watch canvas destination / bleed | 44, 339, 260, 34 |
| Fixed watch index | 166, 322, 16, 30 |
| Place label rect | 102, 383, 144, 20; centered at 174,392 |
| Time label rect | 102, 402, 144, 14; centered at 174,408 |
| Lock background and glyph | 313, 292, 32, 32 |

Place text: Spectral 400 **14px**; time: **10px**; color `#3c2717`. Use ellipsis for long localized names, with the full name available in a tooltip. Do not stretch or squeeze text. The supplied N/E/S/W fallback sprites use Spectral 600 at the intended scale, with a small shadow. If using runtime text instead, center actual glyph ink bounds in each target box; font baseline centering alone moves letters toward the stitching.

The watch renderer still owns its original **272×34** drawing space. Draw its canvas into the new destination rect; the housing covers the bleed and sets the visible aperture. It needs no clock/math changes. Its original glyph PNGs have their own dimensions in the manifest; retain those bytes and let the renderer size them.

## Compass behavior

Use world bearings with **north=0°, east=90°, south=180°, west=270°**, increasing clockwise. Convert the engine’s yaw/sign/zero into this convention once at the adapter boundary.

Let `up` be the world bearing at screen top. In north-locked mode `up=0`. In free rotation use the **camera/view bearing** (or the chosen map-up bearing), not necessarily the character’s facing. A character can face independently of the camera.

```js
up = northLocked ? 0 : cameraBearingDeg;
mapRotationDeg = -up;
tickRotationDeg = -up;
playerMarkerRotationDeg = playerBearingDeg - up;

// For each world cardinal bearing b = 0,90,180,270:
a = radians(b - up);
letterCenterX = 174 + 143 * sin(a);
letterCenterY = 164 - 143 * cos(a);
letterRotationDeg = 0;
```

`js/compass-layout.js` implements this contract as a small optional reference. It exposes `WandererCompass.state({northLocked,cameraBearingDeg,playerBearingDeg})`. Positive image rotation is clockwise for browser canvas/CSS; engines using counterclockwise-positive rotation must convert the sign. Normalize/smooth yaw across 359→0 on the shortest angular path.

North-locked example, facing east: N top / E right / S bottom / W left, arrow points right. Free rotation with camera facing east: E top / S right / W bottom / N left. An east-facing player then points up. If the player turns away from camera forward, its arrow must turn relative to the map.

**Do not rotate a parent containing the leather ring, watch, labels or lock control.** Rotate the map and ticks about the same pivot. Position cardinal sprites individually without rotating their glyphs. Render fog, world markers and map paths in the same map coordinate transform; keep marker labels upright if the existing UI does that.

Render enough surrounding world data to cover a rotating circular aperture. Do not rotate an old tightly cropped rectangular minimap texture and expose its corners/background. A square texture covering at least the circle diameter is sufficient for the circular clip at arbitrary rotation when it is centered correctly; render extra extent for icons/antialias bleed as needed. Keep the game’s generated **pixel look** and existing exploration state. Unknown areas use opaque parchment fog; transparent map pixels should not reveal gameplay through the minimap.

## Watch clock and crossfades

Continue to drive the reused renderer from the game clock, not browser wall time. Its phase is `0=midnight, .25=dawn, .5=noon, .75=dusk`, wrapped into `[0,1)`. Map the game’s actual day/night schedule into these display anchors if durations differ.

| Phase | Sky |
|---|---|
| 0–.19 | Night |
| .19–.25 | Night → dawn |
| .25–.31 | Dawn → day |
| .31–.69 | Day |
| .69–.75 | Day → dusk |
| .75–.81 | Dusk → night |
| .81–1 | Night |

The existing renderer uses smoothstep between keys, a shared scroll offset for every sky layer, and opaque compositing during crossfades. Keep all three. Do not fade both sky layers to partial opacity over transparency. Only sky lighting crossfades; the frame, ticks, sun/moon identities and index are independent. The sun and moon are separate, clean, unchanged sprites, not crops of the assembled preview.

The sky loop is 1024×128, sampled as an 8:1 tile. The renderer wraps at midnight; do not reset an independent CSS animation. Its marker track places the sun at the center at noon and moon at midnight, clipping/fading them at the window edge. Reuse that logic. Keep the game’s existing named time label authoritative. Freeze the last valid phase if clock data is unavailable.

## Input, states and screen clearance

The lock control invokes the actual north-lock command and reflects confirmed game state. Its click must stop propagation so it does not also open the world map. Keep map-click/open-world-map behavior. No plus/minus textures, buttons or hit boxes should remain. Preserve any existing desktop wheel/keyboard zoom behavior only if that remains part of the game’s input design.

Suggested normal-art state treatments: hover brightness 1.10; selected a subtle warm overlay; unavailable brightness .65 and reduced saturation. Keep the frame opaque. Do not tint the map or sky when highlighting only the lock button. Give keyboard focus a runtime outline; no separate focus art is supplied. Closed and open glyphs express different compass modes, rather than hover states.

Reserve the **full 348×426** rectangle. At 1920×1080 the group origin is **1552,18**, bottom **444**. This replaces the old 315×378 reservation. An 800×480 refining window can use origin **732,420**, ending x1532/y900, to clear this minimap and the bottom bars. Feed these rectangles into the existing window manager rather than forcing dragged windows back to an example origin.

When the large map is open, the example compact factor is **.60**, replacing the old .70 factor for this new component. Keep top/right anchors unchanged; only shrink the group. Its bottom becomes 273.6, leaving 26.4 logical pixels before the old world-map bookmark top at300. Adjust through the game’s layout manager if that map layout has since changed.

## Verification and sources

`assembled-preview.png` shows north-up and east-up placement using the actual source pixel-map screenshot. `all-pieces-dark-light.png` exposes transparent cuts against both backgrounds. `preview.html` offers manual orientation and time controls after extracting the whole package. These controls do not represent new gameplay UI. Production textures contain no place name, example map, sample HP or character data.

The ring and watch housing were prepared from approved A with the built-in image generator, then alpha-cleaned, registered and fitted into the production geometry. Leather hue was compared with approved A and adjusted modestly, preserving brass highlights; `sources/material-match.json` records the measurements. The full ring and housing are exported intact, with transparent padding and no sliced metalwork. Compass ticks and fallback text are separate deterministic layers.

`validation.json` records export alpha/padding checks, unchanged reused-file hashes and compass orientation/wrap checks. Actual game yaw conversion, fog rendering, click ownership, clock mapping and neighboring window layout still require integration checks in the game. The original game font may replace the included Spectral face if already standardized, keeping the same ink-bound clearances.
