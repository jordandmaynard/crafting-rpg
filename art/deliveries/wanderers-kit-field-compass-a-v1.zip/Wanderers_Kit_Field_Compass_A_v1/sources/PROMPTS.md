# Art preparation

Built-in image generation referenced to approved A.

Ring: isolate the approved left circular frame on true transparency, blank center, warm chestnut leather and thin honey brass, stitching, no letters, ticks, map, buttons, watch or background. Keep all edges intact.

Watch housing: isolate the approved horizontal watch and attached blank parchment tag, transparent sky aperture, bottom tick rail, four corner guards, no sky, sun, moon, pointer, text, map or buttons. Preserve A materials and full silhouette.

The generated masters were alpha-cleaned and fitted into the numeric contract in layout.json. Watch content and renderer are reused.
