# Wanderer’s Kit — Region and POI toast icons

19 new brass relief emblems: 11 biomes and 8 points of interest. This is an icon delta for the existing discovery/region toast. Keep the toast frame, laurels, stitching, placement, text and animation. Existing discovery, sun and moon assets remain available for their original events.

## Choose the correct export

| Folder | Size | Use |
|---|---|---|
| `badges-96/*.png` | 96×96 RGBA | Complete circular badge for the current frame with its baked-in star. Recommended for the shipped toast. |
| `glyphs-256/*.png` | 256×256 RGBA | Transparent symbol only, for an empty circular inset or other UI uses. No ring or backing. |
| `shared/toast-badge-blank-96.png` | 96×96 RGBA | Shared empty backing if the engine prefers composing the glyph at runtime. |

The badge ring and outer transparency reuse the existing toast sun crest. Its center uses clean leather from the shipped blank compass face; every badge uses this same backing. The toast frame itself is unchanged. Each symbol was generated separately, rather than cut from a crowded icon sheet. Transparent glyphs contain no neighboring icons, labels or frames.

All exports are lossless sRGB PNG with straight RGBA and smooth antialiased alpha. These are painterly UI elements, not the game's binary-alpha pixel-art item icons. Use linear filtering and uniform scaling. Do not stretch or nine-slice the badges. Texture atlases, if used, need the engine's usual transparent padding/extruded borders.

## Drop-in placement

For the 558×151 native toast frame in `Wanderers_Kit_Top_Center_HUD_Rebuilt_v3`, draw the entire 96×96 badge canvas into:

```text
x=242, y=1, width=80, height=80
```

This is the same destination as the existing sun/moon crest variants. Its center is **282,41** in frame coordinates. Apply the existing toast scale once to the whole assembly, including the badge. Preserve the full PNG canvas and its transparent padding; trimming to the alpha bounds and then drawing at 80×80 enlarges the ring and moves it out of registration.

Draw the badge **above the frame**, with normal source-over blending. It covers the baked star and includes its own complete brass rim. Do not draw a transparent glyph directly over the baked star: the old star would show through the glyph's empty spaces. Do not multiply the full badge alpha by a circular clip that cuts its outer bevel. Do not clip the toast group to the rectangular text/body panel: the medallion protrudes above it.

For a shared backing plus independent glyph, first draw the 96×96 backing at the destination above. In the backing's **native 96×96 space**, draw the full 256×256 glyph canvas into **12,12,72,72**. The combined registration is identical to `badges-96/`. Each glyph's ink fits a radius of approximately100px within its 256px source canvas, leaving more than3 native badge pixels of clearance before the inner rim. Avoid independently auto-fitting the glyphs; their exported padding establishes a consistent scale.

If the game uses a newer toast with an empty inset, center the glyph on that inset and use the same proportional safe area. Keep its silhouette inside the circle. Numeric coordinates above describe the known native v3 frame, not the dimensions of the enlarged screenshot in the request.

## Event mapping

Both export folders use the same filename stems. `icons.json` provides IDs, types, labels, paths and hashes; map these IDs to the game's actual enums in the implementation adapter.

| Type | Name | Filename stem | Design cue |
|---|---|---|---|
| Biome | Town | `town` | Three steep rooftops and central gate |
| Biome | Meadow | `meadow` | Grass and two wildflowers |
| Biome | Graveyard | `graveyard` | Two old gravestones |
| Biome | Forest | `forest` | Broadleaf tree cluster |
| Biome | Redwood forest | `redwood-forest` | Tall redwoods and flared trunks |
| Biome | Blasted volcanic wastes | `volcanic-wastes` | Cracked volcano and lava tongues |
| Biome | Desert | `desert` | Dunes and cactus |
| Biome | Alpine snow | `alpine-snow` | Jagged snow-capped peaks |
| Biome | Swamp | `swamp` | Crooked bare tree, cattails and ripple |
| Biome | Lake | `lake` | Broad enclosed water ripples and rocky shores |
| Biome | River | `river` | Winding channel and wave strokes |
| POI | Road | `road` | Curving medieval paving; no painted divider |
| POI | Dock | `dock` | Planks, mooring posts and ripples |
| POI | Obelisk | `obelisk` | Tapered monolith with angular incision |
| POI | Deep forest grotto | `deep-forest-grotto` | Natural cave arch with fern and vine |
| POI | Ancient willow tree | `ancient-willow` | Wide drooping canopy and twisted trunk |
| POI | Farm | `farm` | Barn and wheat |
| POI | Cabin | `cabin` | Log courses, steep roof and chimney |
| POI | Mausoleum | `mausoleum` | Pediment, columns and arched tomb doorway |

Names are identifiers/descriptions only; no text is baked into production icons. Keep biome/POI names, localization, entering/discovery messages and the existing event priority/debounce behavior in game code. The example names in the preview are demonstration strings.

## States and review

These toast icons are decorative and need no new hover frames. If the same icons are reused in an interactive list, apply the existing normal-art tint approach for hover, selected and unavailable states. Keep the shared ring and normal material colors consistent across all emblems.

`overview.png` shows all19 at an enlarged size and a50px full-canvas sample. `previews/toast-examples.png` shows six substitutions in the unchanged toast frame. `validation.json` records canvas counts, alpha padding and circular-fit checks. All production icons were individually inspected for subject and rendered together to check consistency. The frame and text shown in previews are not included as replacement runtime art.

`reference/PROMPTS.json` records the built-in image-generation prompt set. Production glyphs were alpha-cleaned, uniformly resized and placed within the circular safe area; there is no atlas slicing or background repainting in the glyph artwork. Integration still needs to bind the icon IDs to the game's region/POI events.
