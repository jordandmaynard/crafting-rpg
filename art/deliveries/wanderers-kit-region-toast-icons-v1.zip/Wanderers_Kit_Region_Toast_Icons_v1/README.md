# Wanderer’s Kit — Region Toast Icons

19 emblems: 11 biomes and 8 POIs.

Start with overview.png and HANDOFF.md. Use badges-96 on the existing toast; glyphs-256 are transparent symbols for empty insets. icons.json maps all names to filenames. No replacement toast frame is included.
