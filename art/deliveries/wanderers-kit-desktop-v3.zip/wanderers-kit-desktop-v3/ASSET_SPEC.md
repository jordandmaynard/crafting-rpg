# Wanderer’s Kit V3 — Asset measurements

All insets are **source pixels, left/top/right/bottom**. Divide by two for 1080p CSS. Layout rectangles in `layout.json` already use logical CSS pixels. Fixed assets have no slice cuts.

| File | Source size | Method | Slice L,T,R,B | Content L,T,R,B |
|---|---|---|---|---|
| `ui/panel-window.png` | 384×384 | 9-slice | 56,56,56,56 | 44,44,44,44 |
| `ui/btn.png` | 320×60 | 9-slice | 44,18,44,18 | 46,12,46,12 |
| `ui/keycap.png` | 44×44 | 9-slice | 14,14,14,14 | 10,8,10,10 |
| `ui/btn-hover.png` | 320×60 | 9-slice | 44,18,44,18 | 46,12,46,12 |
| `ui/btn-pressed.png` | 320×60 | 9-slice | 44,18,44,18 | 46,12,46,12 |
| `ui/btn-disabled.png` | 320×60 | 9-slice | 44,18,44,18 | 46,12,46,12 |
| `ui/btn-focus.png` | 320×60 | 9-slice | 44,18,44,18 | 46,12,46,12 |
| `ui/btn-on.png` | 320×60 | 9-slice | 44,18,44,18 | 46,12,46,12 |
| `ui/surface-parchment.png` | 256×256 | tile | 0,0,0,0 | 0,0,0,0 |
| `ui/surface-leather.png` | 100×100 | tile | 0,0,0,0 | 0,0,0,0 |
| `ui/inventory-backpack.png` | 1012×1464 | fixed | 0,0,0,0 | 0,0,0,0 |
| `ui/inventory-character.png` | 900×1328 | fixed | 0,0,0,0 | 0,0,0,0 |
| `ui/slot-hot.png` | 184×184 | 9-slice | 32,32,32,32 | 16,16,16,16 |
| `ui/cell.png` | 180×180 | 9-slice | 16,16,16,16 | 12,12,12,12 |
| `ui/slot-ability.png` | 184×184 | fixed | 0,0,0,0 | 0,0,0,0 |
| `ui/button-mode.png` | 220×188 | fixed | 0,0,0,0 | 0,0,0,0 |
| `ui/station-grinder-crest.png` | 320×284 | fixed | 0,0,0,0 | 0,0,0,0 |
| `ui/arrow-refine.png` | 96×64 | fixed | 0,0,0,0 | 0,0,0,0 |
| `ui/slot-hot-hover.png` | 184×184 | 9-slice | 32,32,32,32 | 16,16,16,16 |
| `ui/slot-hot-selected.png` | 184×184 | 9-slice | 32,32,32,32 | 16,16,16,16 |
| `ui/slot-hot-drop.png` | 184×184 | 9-slice | 32,32,32,32 | 16,16,16,16 |
| `ui/slot-hot-pressed.png` | 184×184 | 9-slice | 32,32,32,32 | 16,16,16,16 |
| `ui/cell-hover.png` | 180×180 | 9-slice | 16,16,16,16 | 12,12,12,12 |
| `ui/cell-focus.png` | 180×180 | 9-slice | 16,16,16,16 | 12,12,12,12 |
| `ui/cell-pressed.png` | 180×180 | 9-slice | 16,16,16,16 | 12,12,12,12 |
| `ui/slot-ability-hover.png` | 184×184 | fixed | 0,0,0,0 | 16,16,16,16 |
| `ui/slot-ability-selected.png` | 184×184 | fixed | 0,0,0,0 | 16,16,16,16 |
| `ui/slot-ability-pressed.png` | 184×184 | fixed | 0,0,0,0 | 16,16,16,16 |
| `ui/slot-ability-locked.png` | 184×184 | fixed | 0,0,0,0 | 16,16,16,16 |
| `ui/slot-ability-poor.png` | 184×184 | fixed | 0,0,0,0 | 16,16,16,16 |
| `ui/button-mode-hover.png` | 220×188 | fixed | 0,0,0,0 | 20,14,20,14 |
| `ui/button-mode-selected.png` | 220×188 | fixed | 0,0,0,0 | 20,14,20,14 |
| `ui/button-mode-pressed.png` | 220×188 | fixed | 0,0,0,0 | 20,14,20,14 |
| `ui/button-mode-disabled.png` | 220×188 | fixed | 0,0,0,0 | 20,14,20,14 |
| `ui/button-mode-focus.png` | 220×188 | fixed | 0,0,0,0 | 20,14,20,14 |
| `ui/icon-mode-pack.png` | 84×84 | fixed | 0,0,0,0 | 0,0,0,0 |
| `ui/icon-mode-build.png` | 84×84 | fixed | 0,0,0,0 | 0,0,0,0 |
| `ui/icon-mode-map.png` | 84×84 | fixed | 0,0,0,0 | 0,0,0,0 |
| `ui/cell-refine.png` | 220×220 | 9-slice | 30,30,30,30 | 18,18,18,18 |
| `ui/cell-refine-hover.png` | 220×220 | 9-slice | 30,30,30,30 | 18,18,18,18 |
| `ui/cell-refine-focus.png` | 220×220 | 9-slice | 30,30,30,30 | 18,18,18,18 |
| `ui/cell-refine-pressed.png` | 220×220 | 9-slice | 30,30,30,30 | 18,18,18,18 |
| `ui/frame-minimap.png` | 630×600 | fixed | 0,0,0,0 | 0,0,0,0 |
| `ui/frame-health.png` | 620×152 | fixed | 0,0,0,0 | 0,0,0,0 |
| `ui/ring-level.png` | 160×160 | fixed | 0,0,0,0 | 0,0,0,0 |
| `ui/compass.png` | 128×128 | fixed | 0,0,0,0 | 0,0,0,0 |
| `ui/compass-hover.png` | 128×128 | fixed | 0,0,0,0 | 0,0,0,0 |
| `ui/compass-on.png` | 128×128 | fixed | 0,0,0,0 | 0,0,0,0 |
| `ui/station-window.png` | 1440×1000 | fixed | 0,0,0,0 | 0,0,0,0 |
| `ui/bar-health-fill.png` | 32×28 | 3-slice-x | 4,0,4,0 | 0,0,0,0 |

Every asset has zero baked outset; shadows are CSS. State sizes and alpha footprints remain aligned. Fixed shells/medallions scale with their whole logical group. The 110px refining patch uses 30px source corner cuts / 15px CSS caps and 18px source / 9px CSS content padding.

## Exact live openings

- Minimap: source `[36,42,558,372]` in a 630×600 frame; logical `[18,21,279,186]`; radius 7 CSS px. The frame aperture is transparent.
- Health title: plate-local `[35,12,259,29]`.
- Health fill: plate-local `[29,45,262,14]`; clip width by current/max ratio.
- Health plate: `[48,9,310,76]` inside a 358×88 group. Level disk: `[0,4,80,80]`, drawn above it.
- Compass: `[238,17,64,64]` inside the minimap; N and needle are live.

Use **four** output cells (2×2) in the 720×500 station window. The coding handoff supersedes all previous eight-output layout instructions and explains legacy-save handling.

The inventory and bottom HUD retained their V2 dimensions. Existing cream mode glyphs are resampled reference cutouts; see their manifest notes.
