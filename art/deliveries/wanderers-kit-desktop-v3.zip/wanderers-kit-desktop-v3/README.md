# Wanderer’s Kit — Desktop V3

V3 returns refining to **four output slots** and brings its cells, the minimap, and the hero level/health indicator closer to the approved mockup. It includes **50 skin/glyph PNGs**, CSS, exact metadata, a coding-agent handoff, fonts/licenses, and offline proofs.

## Revised components

| Element | V3 design at 1080p |
|---|---|
| Refining | Four inputs and **four outputs**, both 2×2 grids |
| Refining cells | **110px**, raised worn-brass rim, corner rivets, dark leather well |
| Station casing | **720×500**, with preserved header and grinder crest |
| Minimap | Dedicated **315×300** leather/brass frame, alpha opening, parchment footer |
| Map opening | **279×186** at `[18,21]`, clip radius 7px |
| Compass | **64px** medallion; live upright N and separate rotating needle |
| Health plate | **310×76** parchment/leather frame with recessed channel |
| Level disk | **80px**, layered copper/leather, overlapping the plate |

All dimensions are logical CSS pixels before the shared screen-fit scale. The PNGs are 2× exports with sRGB and straight RGBA. The joined inventory and bottom controls retain V2’s sizes and art.

## Files to open

- `CODING_AGENT_HANDOFF.md`: complete current instructions. The four-output rule supersedes the earlier eight-output requirement. Legacy-save migration must preserve all existing items.
- `preview.html`: complete offline assembly with delivered skins and live text.
- `details.html` / `desktop-v3-details.png`: the new health, minimap, and refining frames, plus refining-cell states.
- `hud-proof.html`: retained bottom controls.
- `desktop-v3-preview-1920x1080.png` and `desktop-v3-preview-1280x720.png`: browser renders.
- `approved-vs-v3-comparison.png`: approved reference beside the new assembly.
- `layout.json`: exact logical anchors, overlay rectangles, counts, and sizes.
- `manifest.json` / `ASSET_SPEC.md`: source dimensions, methods, insets, states, alpha, and hashes.
- `wanderers-kit.css`: current layout/state rules. `core-fallback.css` retains shared primitives and font declarations.
- `PROMPTS-V3.json`: prompts for the five new image-generated frame components. Earlier prompts remain under `PROMPTS.json`.

Extract the complete ZIP, preserve its folders, and open the HTML files in a desktop browser. Fonts are bundled for offline use.

## Integration

Use `cell-refine*.png` only on station input/output cells. Keep its raised-brass treatment separate from the thinner inventory cell. Counts, titles, names, equipment, health values, levels, and keys remain live. The character PNG in `demo/` is a stand-in for the real game’s 3D renderer.

The minimap frame has a transparent opening for the runtime pixel map. Render/crop the map using actual world coordinates; never stretch geography or paint over it. The parchment footer is opaque. Keep the compass medallion and N upright while rotating only the live needle. The full world map retains the earlier pixel-map rule, with parchment reserved for unexplored fog/background.

`frame-health.png` contains the empty channel. Clip `bar-health-fill.png` inside the measured channel by the current/max-health ratio; do not scale the plate with the health value. Position the level disk above the plate in z order and render its number live.

The game repository has not been modified here. The coding agent should follow the handoff’s explicit replacements for the original brief, preserve existing commands/bindings, and migrate old eight-output saved stations without truncating their items.

## Verification

The offline composition was checked at **1280×720, 1920×1080, 2560×1440, 3840×2160, and 3440×1440**. Major groups stayed on screen without overlap. Counts are 20 pack cells, six gear slots, four inputs, and four outputs. Health clipping was exercised at 0/50/100%; the compass needle was rotated independently and its toggle state exercised. Dark text over parchment was checked in the frame detail proof.

All listed PNGs decode and embed sRGB; hashes, slice geometry, and family-state alpha footprints match. The 38 retained V2 skin files other than the station casing are byte-identical. See the two validation JSON files. Actual-game migration, drag/drop, gameplay logic, and live rendering require repository integration tests.

## Remaining scope and provenance

Dedicated close buttons, station-progress/XP/target/foe meters, storage/crafting/modal skins, map bookmarks/fog assets, and remaining utility glyphs are later passes. Touch controls and developer panels remain out of scope.

Cream mode glyphs remain reference cutouts exported at 84×84 for 42px display, not native 256px repaints. V3 frame art used the built-in image-generation tool with approved reference crops. Technical exports and state grading preserve aligned geometry. The narrower station casing preserves its physical ends through a center re-cut.
