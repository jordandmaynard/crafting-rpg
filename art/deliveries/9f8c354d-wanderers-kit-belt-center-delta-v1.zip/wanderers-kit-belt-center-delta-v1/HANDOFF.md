# Wanderer’s Kit — belt and center HUD delta v1

Replace the old health/level display and long bottom XP bar with the approved bottom-center belt assembly. Add the thick, continuous leather belt behind the existing hotbar and action controls. Only new center/belt assets are supplied. All existing button frames, backgrounds, icons, keycaps, slot counts, bindings and cooldown displays stay in use.

## What is delivered

Seven straight-alpha RGBA PNGs, at 2× logical resolution, plus exact layout coordinates and assembled proofs. The center has the latest right-hand trapezoid buckle, both extended keeper loops, empty glass tracks and room for live data. The name, level, HP count, XP label and all progress are not baked into the skin. The preview’s CaptRascal / 99 / 72/100 / 65% are demonstration values.

| Asset in `assets/` | PNG pixels | Logical pixels | Use |
|---|---:|---:|---|
| `belt-repeat-normal@2x.png` | 1024 × 232 | 512 × 116 | Full-width horizontal repeat behind existing controls |
| `center-body-normal@2x.png` | 1088 × 272 | 544 × 136 | Center leather, empty glass tracks, keepers and trapezoid buckle |
| `health-glass-fill@2x.png` | 748 × 52 | 374 × 26 | Full red glass fill; reveal by clipping |
| `health-clip-mask@2x.png` | 748 × 52 | 374 × 26 | Optional alpha mask for engines needing a separate mask |
| `experience-gold-fill@2x.png` | 640 × 28 | 320 × 14 | Full gold XP fill; reveal by clipping |
| `experience-clip-mask@2x.png` | 640 × 28 | 320 × 14 | Optional alpha mask for the XP interior |
| `experience-ten-percent-notches@2x.png` | 640 × 28 | 320 × 14 | Static 10–90% tick overlay across the entire track |

The fills already have the matching rounded alpha mask. Use the separate mask only if the renderer requires it; do not multiply edge alpha twice. White RGB in mask files carries coverage through alpha.

`layout.json` is authoritative. `previews/` images show the exported parts assembled, including an example with the existing controls cropped from the approved mockup. Those button/icon crops are proof-only and are not runtime assets. `reference/validation.json` contains asset hashes and export checks; `reference/material-audit.json` records the color samples.

## Place it at bottom center

Use the game’s current desktop HUD scale `s`. The reference design is expressed at a 1920-wide logical canvas; if no common HUD scale exists, start with `s = min(viewportWidth / 1920, viewportHeight / 1080)`.

At the normal scale:

```text
centerWidth = 544 * s
centerHeight = 136 * s
centerX = (viewportWidth - centerWidth) / 2
centerY = viewportHeight - 4*s - centerHeight
beltY = centerY + 9*s
beltHeight = 116*s
```

Repeat the belt texture across the entire viewport width at this height. Keep its aspect ratio and repeat in X; do not stretch grain/stitches across the screen. Align repeat phase to viewport center. On ultrawide displays the extra span is more repeats, not more stretched leather. The strip’s first and last columns match exactly, as does its reflection joint.

Put the center body over the belt, then the live meter layers and text. Keep the existing left and right groups in their current rectangles and at their current size. The belt is deliberately thick enough to sit behind both the buttons and their keycaps. The keeper loops extend above the top stitch and below the bottom stitch; do not crop them to the repeat strip’s shorter height.

The normal 544-pixel center is intended for the existing gap. If a supported resolution’s current button groups leave less room, scale the center assembly uniformly to fit that gap, with at least an 8*s gap on each side:

```text
gapHalf = min(viewportWidth/2 - leftGroupRight,
              rightGroupLeft - viewportWidth/2) - 8*s
centerScale = min(s, 2*gapHalf / 544)
```

Only apply this when `gapHalf > 0`. Keep the full-width belt at the normal HUD scale. Vertically align the scaled center’s stitch rows to the belt’s: the stitch midpoint is local y=66.5, so place the center at `normalCenterY + 66.5*(s-centerScale)`. The two rows will converge slightly within the keepers as the center shrinks. Prefer the game’s existing compact-HUD handling if the gap becomes too small for readable center text. Do not silently resize/reorder the current buttons to make room.

Snap final destinations consistently to the renderer’s pixel grid. This is smooth painted UI, not pixel-art sampling: use linear filtering, clamp center/fill sprites, and repeat X / clamp Y for the belt. Exported PNGs are straight alpha; convert once if the engine expects premultiplied textures. Add normal atlas extrusion if atlasing, and do not trim away the center’s layout origin.

## Center coordinates

All values below are local logical pixels at 1×. Multiply by the center’s actual display scale. `(x, y, width, height)` rectangles use top-left origin.

| Element | Placement | Text / behavior |
|---|---|---|
| Name | rect `(48, 17, 372, 25)` | Spectral SemiBold 24, left aligned, one line |
| HP interior | rect `(48, 48, 374, 26)` | Red fill under live HP count |
| HP count | center `(235, 61)` | Spectral SemiBold 22; `current / maximum` |
| XP label | center `(66, 97)` | Spectral SemiBold 17; `XP` |
| XP interior | rect `(101, 90, 320, 14)` | Gold fill; grows right toward buckle |
| XP notches | same XP rect | Static overlay, after fill; 9 ticks |
| Level label | center `(472, 50)` | Spectral SemiBold 16; `Lv` |
| Level value | center `(472, 82)` | Spectral SemiBold 36; live value |

Use the Spectral SemiBold font already supplied with the Wanderer’s Kit UI (`spectral-600.ttf`). No replacement font is added. Warm cream `#F0DFB7`, dark brown `#21130D` shadow at `(1,1)` logical pixels; HP count can also have a 1-pixel dark outline. The name rectangle is the visible glyph box’s top-left, not a font baseline. Match the assembled proof using the engine’s font metrics. Ellipsize long names within the rectangle; retain the full name in the existing tooltip/accessibility mechanism. Keep enough width for the live HP text; shrink that text modestly within the HP rectangle for unusually large numbers rather than truncating health values.

Levels 1, 9, 10 and 99 were rendered and measured. The two-digit glyph width is 38.5 logical pixels inside a 46-pixel safe width. `99` demonstrates capacity; it does not impose a new game level cap. Keep text upright: only the brass hardware has perspective. Do not mirror or shear the numeral.

The buckle’s reference outer quadrilateral is `(435,29) → (508,12) → (508,120.5) → (435,108)`. Its left/right sides are vertical and parallel. The top rises toward the right and the bottom falls toward the right, making the right side taller. Do not convert it back to a tilted rectangle or parallelogram.

## Live HP and XP

Use existing authoritative character data and progression rules. This is a visual relocation, not a change to combat or leveling.

```text
hpFraction = clamp(currentHP / maximumHP, 0, 1)  // maximumHP > 0; else 0

// If game XP is cumulative:
xpFraction = clamp((totalXP - thresholdForCurrentLevel) /
                   (thresholdForNextLevel - thresholdForCurrentLevel), 0, 1)

// If game already supplies within-level XP:
xpFraction = clamp(xpWithinLevel / xpNeededForLevel, 0, 1)
```

Guard zero/invalid denominators. At a level cap, use the game’s existing cap policy, including any capped XP label or full-meter convention; do not invent a new cap or reset behavior. Preserve the game’s overflow XP and existing level-up events. On a level change, update the number and the next level’s progress from the same authoritative state.

Draw each fill texture at its full fixed track size. Reveal its left portion through a rectangular clip whose width is `fullWidth * fraction`, while retaining the sprite’s rounded alpha. Do not resize the fill texture to its percentage: that would squeeze the glass highlights and distort the material. At 0%, skip the fill; at 100%, show the full fill. The empty polished glass already present in the center remains visible behind the missing portion. No knob, brass slider or extra cap is needed at the fill edge.

Render the notch overlay over the entire XP track, including its empty region. It has nine interior marks, exactly at local XP x=32,64,96,128,160,192,224,256,288 — 10% through 90% of its 320-pixel width. There is no squiggle, painted divider, square segmented meter or moving tick overlay. Both fills progress left-to-right; XP visually travels toward the right-hand level buckle.

Recommended draw order:

1. Full-width repeating belt.
2. Center normal body with empty tracks, keepers and buckle.
3. HP fill clipped inside its exact local rectangle.
4. XP fill clipped inside its exact local rectangle.
5. Static XP notch overlay.
6. Live name, HP count, XP, Lv and level text.
7. Existing hotbar/action button rendering, including keycaps and current states.

No new hover/selected/unavailable sprites are necessary. These new leather parts are decorative. Retain existing meter transitions or damage feedback where applicable. Use the established tint approach for any required feedback instead of creating alternate painted leather.

## Changes from the current implementation

- Stop rendering the old top-left health/level visuals once the new center is active; route the same name/health/level data into this display.
- Stop rendering the separate long bottom XP bar; route its existing progress to the compact gold track.
- Add the belt as a decorative underlay across the bottom. It must not become a full-width input-capture region. The belt and center background should pass pointer input through except where the game already has a specific interactive element/tooltip.
- Add the central assembly in the gap between the existing groups. Reuse all current hotbar, ability and mode buttons, icons, backgrounds, keycaps, state tints and bindings. No other UI windows or minimap assets change.
- Desktop PC is the target for this delta. Preserve the game’s existing HUD visibility, UI-scale and resolution controls.

## Material lock and validation

The trim/keeper pass restores a little chestnut saturation without brightening the dark center face. Warm leather received a restrained 7% relative saturation adjustment on the narrow trim and keepers only; golden brass and the broad center face were excluded. All values below are median-ROI measurements from the exported art and actual shipped PNGs, not whole-image averages.

| Sample | Median RGB | Hue | HSV saturation | Median L* |
|---|---|---:|---:|---:|
| New center face | 59,32,22 | 16.2° | 62.7% | 15.9 |
| New keeper leather | 79,39,23 | 17.1° | 70.9% | 20.8 |
| New belt face | 66,36,25 | 16.1° | 62.1% | 17.9 |
| New belt trim | 95,45.5,24 | 18.2° | 74.7% | 24.9 |
| Shipped map upper leather | 84,37,22 | 14.5° | 73.8% | 21.2 |
| Shipped backpack bedroll | 112,57,33 | 18.2° | 70.5% | 30.4 |
| Shipped backpack interior | 56,35,26 | 18.0° | 53.6% | 16.2 |

The new trim sits with the shipped warm red-brown leather rather than drifting into orange. Its brightness falls between the map trim and the rounded backpack bedroll. The center’s darker L* remains close to interior leather for readability. Grain has more local contrast than the backpack’s flatter interior; this is surface detail, not a global brightness lift. Retain the supplied colors as sRGB and avoid a second global warm tint.

Verified from exported assets: RGBA dimensions, cleaned RGB at fully transparent pixels, identical belt boundary columns and internal reflection joint, nine exact XP notch positions, double-digit level fit, the opposite top/bottom buckle slopes, extended loops, and 0/50/72/100% HP with 0/10/65/100% XP examples. Review `previews/meter-and-level-states.png` for the live-data examples. No running game code was provided; integration and in-game behavior still need validation by the coding agent.

Before accepting integration, confirm placement at supported desktop resolutions/UI scales; no button overlap; correct live HP/XP at empty/full/level-up/cap; name ellipsis and two-digit level fit; alpha/color sampling in the renderer; and unchanged control hitboxes/bindings. The proof PNGs are references, not skins to draw as one flattened HUD image.
