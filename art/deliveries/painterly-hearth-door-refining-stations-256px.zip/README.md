# Painterly buildable icons — hearth, door and refining stations

Individual 256×256 PNGs: `build-hearth`, `build-wood-door`, `build-saw-table`, `build-grinder`, `build-smelter`, and `build-tanning-rack`, each suffixed `-painterly-256x256.png`.

Each image is RGBA with true transparent background and alpha values restricted to 0 or 255. Import as individual square textures, preserve alpha, and use filtering/mipmaps for smaller non-integer display sizes. The images are inventory/build menu illustrations in the classic 2:1 isometric visual direction, not seamless world tiles. No UI border, background or cast shadow is baked in.

The door is now fully dark wood, including the upper panel, matching the planned in-game revision. The stations follow the earlier in-game references: open masonry hearth, sawing bench, hopper and wheel grinder, closed smelter, and hide-stretching rack. The 72px preview is provided to judge menu-scale legibility.

Made with built-in image generation using the earlier 64px buildable icons and painterly materials as references, then cropped, resized, and alpha-thresholded at 128.
