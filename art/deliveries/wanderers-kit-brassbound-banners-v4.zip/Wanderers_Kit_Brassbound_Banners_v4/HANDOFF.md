# Wanderer’s Kit — brassbound banners v4

Production backgrounds for the approved matched NPC/enemy design: continuous naturally grained leather, straight stitched rails, full-height brass guards, and a large circular level inset inside the enemy’s square left guard. Townspeople use decorative studs at both ends. All runtime text and HP are separate.

This is a new frame construction. Replace the earlier top-banner backgrounds and update the placement data below. The existing clean HP back/rim/fill, toast and crest assets remain in use. No game repository was supplied; integration code is not included.

## Delivered PNGs

| File in `assets/` | Dimensions | Use |
|---|---:|---|
| `npc_frame_blank.png` | 1088×128 | Complete blank townsperson frame |
| `enemy_frame_blank.png` | 1088×128 | Complete blank enemy frame, including empty circular level inset |
| `modules/end_stud_left.png` | 80×112 | NPC left brass guard |
| `modules/end_level_left.png` | 112×112 | Enemy left square guard; circular face is blank |
| `modules/end_stud_right.png` | 80×112 | Shared right brass guard |
| `modules/body_npc.png` | 912×112 | Whole continuous NPC panel and rails |
| `modules/body_enemy.png` | 880×112 | Whole continuous enemy panel and rails |

Use the complete frame PNG for the normal layout. The modules are optional assembly parts cut at the physical brass/body joints; they are not tiny repeat tiles. NPC assembly: left guard `(8,8)`, body `(88,8)`, right guard `(1000,8)`. Enemy assembly: level guard `(8,8)`, body `(120,8)`, right guard `(1000,8)`. All guards/body pieces are drawn at native size. Both completed frames have eight-pixel transparent outer padding and no baked name, level numeral, health text or fill.

`layout.json` is authoritative; `asset_manifest.json` records dimensions, bounds and hashes. Smooth RGBA antialiasing is retained, with clean RGB at fully transparent pixels. Use sRGB color textures and linear filtering; convert straight alpha once if the engine expects premultiplied input.

## Native coordinates and scaling

All positions below are in **native PNG pixels**, before one shared uniform UI display scale. For example, scale0.625 displays a frame at680×80. Do not apply another implicit 2× asset scale.

| Element | Placement |
|---|---|
| NPC name | center `(544,48)`, size28 |
| NPC profession | center `(544,86)`, size22, italic optional |
| Enemy level value | center `(64,64)`, size40 |
| Enemy name | center `(560,43)`, size28 |
| Enemy HP track | `(304,70,512,24)` |
| Enemy HP fill interior | `(313,77,494,10)`, radius4 |

Use the existing Spectral SemiBold and Spectral Italic UI fonts, cream `#F0DFB7`, dark brown shadow `#21130D` at native offset `(1,1)`. Coordinates refer to a text center, not a baseline; apply the renderer’s font metrics. The live level 1/9/10/99 was checked. Size40 two-digit text fits within a64×56 safe ink area centered at `(64,64)`, with ample space inside the circular face. Level99 is a fit test, not a progression cap.

The left level surround is already in the enemy background. Retire the old floating `level_medallion_blank.png` draw call; draw only the live numeral over the new circular inset. Townsperson frames have no number, circular socket or HP rendering.

Anchor either frame at top-center with root y=`-8*displayScale` to remove its safety margin from the viewport edge. Apply the same root translation and scale to every child. For long names, first measure the text in the leather interior (NPC x112…976; enemy x144…976). Use a modest font reduction or ellipsis with the full name in the current tooltip/accessibility path. Do not let text enter a guard.

## Reuse the existing clean HP layers

Keep v3’s existing `hp_track_back.png`, `hp_track_rim_overlay.png`, `hp_fill_amber.png` and optional `hp_fill_red.png`. They are not repainted or duplicated in this background-only package.

The original back/rim are636×28 with14-pixel caps. To draw at the v4 track rectangle512×24:

| Source region | Destination relative to track |
|---|---|
| `(0,0,14,28)` | `(0,0,12,24)` |
| `(14,0,608,28)` | `(12,0,488,24)` |
| `(622,0,14,28)` | `(500,0,12,24)` |

Apply the same construction to back and rim. Draw the full existing fill texture at `(313,77,494,10)`, with its matching rounded clip, then reveal the left portion through an additional rectangular clip of width `494*p`. Compute `p = maxHP>0 ? clamp(currentHP/maxHP,0,1) : 0`. Do not squeeze the fill texture as p changes. Skip the fill at0; reveal all at1; draw the rim above the fill. The preview uses these exported backgrounds and the actual old HP layers.

Draw order: background; HP back; clipped HP fill; HP rim; enemy name and level. NPC draws background, name, profession. Keep all existing targeting, hover, HP update and UI visibility behavior.

## Width behavior

The standard path draws the complete frame once. **Do not use the former `top_straight_repeat.png`, mirrored16-pixel grain, or old cap/notch assembly.** This design has a single continuous leather field, not a series of little material tiles.

If the product needs a slightly different width, keep the guards fixed and scale the complete continuous body panel horizontally within0.85–1.15 of its native width. Re-center the text/HP in the resized body. For larger differences, prefer a uniform whole-HUD scale or name ellipsis. Do not repeat or mirror the body texture; do not stretch the square level guard or circular inset. If exact fixed stitching pitch at arbitrary widths later becomes a requirement, produce a separately approved wide background instead of inventing new cuts from this one.

## Color lock

The screenshot comparison showed a real leather drift. Its relative red/saturation difference agrees with the native files; exact color targets use native PNGs rather than display-captured values, which include the browser/display transform. The approved mockup’s sampled native body was approximately RGB72,24,8, hue15.0°, saturation88.9%. The previous plain leather was RGB65,35,19, hue20.9°, saturation70.8%. The new production body is matched to the latter median, while preserving the generated leather’s irregular grain and lighting variation. The color correction is applied across the leather material; there is no smooth face patch or tiled strip.

Brass was evaluated separately. Original mid-tone gold pixels (excluding near-white highlights and deep shadows) had median hue28.92°. The new guards and rails required only approximately0.9–2.0° hue rotations to reach that family. Their saturation/value and specular highlights were retained. The large new flat brass plates naturally have a different highlight distribution from the old small rounded studs; that is geometry/lighting, not an intentional palette change. Avoid adding another global warm tint in the game.

`reference/color-audit.json` records the source and production samples and separate metal adjustments. `previews/color-comparison.png` shows old plain leather, the approved mockup and color-matched production art. The supplied browser screenshot was used for internal comparison; it is not redistributed.

## What to replace from earlier versions

- Replace NPC/enemy frame paths with these new backgrounds; both are now1088×128 (previous NPC896×144 and enemy1088×144).
- Remove the old floating level-ring background and move live level text to `(64,64)`, size40.
- Apply the new text and HP destination coordinates above; keep the old clean HP sources.
- Retire the old four cap/repeat/notch sprites for these banners. Use whole backgrounds, or the new whole-body modules if needed.
- Keep toast, sun/moon/dawn/dusk/compass icons and unrelated UI skins intact.

## Verification

All seven delivered pieces are shown on dark and light grounds in `previews/all-pieces-dark-light.png`. `assembled-preview.png` shows the exact exported art with live-data examples, and `level-and-health-states.png` checks1/9/10/99, empty/full HP and a long name. The manifest includes source bounds and hashes. PNG decoding and ZIP integrity are checked. No in-game source or running implementation was available; the coding agent must verify the final renderer’s text metrics, scaling, clipping and cache/atlas refresh.
