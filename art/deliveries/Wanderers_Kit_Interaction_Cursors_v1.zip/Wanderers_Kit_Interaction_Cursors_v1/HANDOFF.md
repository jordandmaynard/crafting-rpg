# Wanderer’s Kit — Interaction cursors

Three 32×32 interaction cursors. The revised hands are medieval steel gauntlets with four upper fingers plus a separate thumb, articulated finger plates and short steel cuffs. Clean silver-blue facets, crisp highlights and dark joint seams match the small weapon cursor treatment. The grabbing hand is cupped and reaches diagonally upper-left; the fighting hand is the same gauntlet closed into a compact fist. The talk cursor and existing weapon cursors are unchanged.

| State | PNG | Windows cursor | Art |
|---|---|---|---|
| Talk | `png/cursor-talk-32.png` | `cur/cursor-talk.cur` | Speech bubble, three dots, lower-center tail |
| Interact / use | `png/cursor-interact-hand-32.png` | `cur/cursor-interact-hand.cur` | Cupped steel gauntlet reaching upper-left |
| Unarmed attack | `png/cursor-fist-32.png` | `cur/cursor-fist.cur` | Closed fist aimed upper-left |

Merge these `png/` and `cur/` folders alongside the weapon cursor files. Add the entries in `cursors.json` to the cursor registry. Each source canvas is exactly32×32; each hotspot is **0,0 in top-left pixel coordinates**. The rounded artwork can leave transparent space at that location. Do not auto-trim or recenter on import. For software rendering, place the image’s top-left at the pointer coordinates. Convert the hotspot only if the engine/importer uses a different coordinate origin.

Use Talk for valid NPC conversation targets; Interact for doors, boxes, crafting tables and similar use targets; Fist for an unarmed attack target. Keep target availability, command priority and cursor switching in the game’s existing interaction code. These are normal-state images only; no new gameplay rules or pressed-state art are supplied.

The PNGs are lossless sRGB straight RGBA with binary alpha and cleared transparent RGB. Use native32px logical sizing under the same DPI policy as the weapon cursors. If deliberately enlarging a software cursor, nearest-neighbor preserves its crisp miniature pixels. `cursors.css` provides explicit PNG hotspot examples.

Windows CUR files contain32×32,32-bit BGRA DIBs with matching AND masks and embedded0,0 hotspots. They were decoded back and compared against the PNG pixels exactly. Loading and input behavior in the actual game/OS still need integration checks.

`preview.png` shows8× nearest-neighbor enlargements and native32px samples on dark and light backgrounds. Production files do not include the preview’s labels or backgrounds. `validation.json` records native dimensions, alpha, hotspots, CUR round trips and the speech bubble’s three distinct dots after reduction.

The revised gauntlets were produced with built-in image generation. The exact user-selected open gauntlet supplied the edit source and preserved thumb placement. Both poses now have four upper fingers plus a separate thumb. The iron sword cursor supplied the simplified silver-blue facet treatment; the revised grabbing gauntlet supplied the closed fist’s matching materials. `reference/GAUNTLET_REVISION.json` records the replacement prompt set and supersedes the two original glove prompts in `reference/PROMPTS.json`. Technical finishing includes alpha cleanup, palette reduction and uniform fitting. Both new hands were drawn in the intended orientation and need no registration rotation. The bubble’s tail stays on its lower middle.

Replace both existing hand PNGs/CURs using the same filenames; no registry remapping is needed. The talk PNG/CUR remain byte-identical to the prior package. The package contains only the current production hands, not the discarded glove art.
