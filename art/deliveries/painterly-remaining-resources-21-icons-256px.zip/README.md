# Remaining RPG resources — painterly 256×256

This pack contains 21 individual PNG icons: 12 metal resources (copper, iron, Verdane, Caerite, Orivane and Auralith, each as ore and one ingot), plus wheat bundle, flour bag, round sourdough loaf, rough sandstone, sand pile, glass pane, bones stack, raw hide, and worked leather stack. The metal colors progress from white iron → green Verdane → blue Caerite → purple Orivane → prismatic, abalone-like Auralith; copper remains a separate warm red-orange base metal. Keldrite and Cindral are not used.

`metals/` and `materials/` contain standalone RGBA PNGs, each exactly 256×256, with transparent backgrounds and alpha values restricted to 0 or 255. Preserve alpha and square aspect ratio on import. Use mipmaps or texture filtering at non-integer UI sizes. The glass body is painted opaque pale blue with highlights so its alpha remains binary. The flour bag has a bold wheat emblem on its front.

These are item cutouts, so they are not locked to the 2:1 building-icon isometric orientation. No border, cast shadow, UI background or text is baked in. `metals-preview.png` and `materials-preview.png` show full-size comparisons; `all-resources-72px-preview.png` shows UI-scale legibility.

Created with built-in image generation using the approved 48px shapes and the painterly resource set as references, then cropped, resized with Lanczos filtering and alpha-thresholded at 128.
