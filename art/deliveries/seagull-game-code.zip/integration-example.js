// Copy seagull.js to <game>/seagull/seagull.js. Add this to index.html's module:
// import { makeSeagull, poseSeagull, disposeSeagull } from './seagull/seagull.js';
// The game already supplies its GFX namespace and scene.

// Create once:
// const gull = makeSeagull(GFX, {
//   material: flatMat({ vertexColors: true, side: GFX.DoubleSide }), phase: 0.13
// });
// scene.add(gull.g);
// let gullFlightState = 'glide';

// Every frame, use elapsed seconds:
// poseSeagull(gull, time, gullFlightState);
// Set gullFlightState = 'flap' or 'glide' at any time. The pose blends for 0.28 seconds.
// Optional parameters: poseSeagull(gull, time, 'flap', strength, cyclesPerSecond, blendSeconds).
// For a fully specified pose when scrubbing: poseSeagull(gull, chosenTime, 'flap', 1, 2.1, 0).
// Exact reference glide at any time: poseSeagull(gull, time, 'glide', 1, 2.1, 0).

// Simple placement above/alongside a boat (visual example, not flight AI):
// const u = 2.4, v = 2.8;
// gull.g.position.set(
//   b.x + Math.cos(b.h) * u + Math.sin(b.h) * v,
//   boatDeckY(b) + 1.8,
//   b.z - Math.sin(b.h) * u + Math.cos(b.h) * v
// );
// gull.g.rotation.y = b.h;

// Remove when finished: disposeSeagull(gull).
// To paste beside the existing boat helpers, use seagull-inline.js instead of an import.
