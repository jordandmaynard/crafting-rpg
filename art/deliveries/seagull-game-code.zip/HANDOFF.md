# Emberwild seagull — procedural code asset

One continuous, faceted JavaScript shell in the boat/dolphin coordinate frame: Y up, +Z forward, one unit per metre/tile. Wingspan is approximately 1.72 units; beak-to-tail length approximately 0.78 units. White head and belly, grey upper wings, dark primary tips, gold beak and tucked feet. The supplied front-view photograph guided the raised inner wings and lowered outer tips of the glide pose.

## Files

- `seagull.js`: shape builder, six-bone weighted rig, both flight states, and adapter for the game's GFX renderer.
- `seagull-inline.js`: the same implementation without export keywords, ready to paste beside the boat helpers in the game's module.
- `integration-example.js`: how to create, animate, position, and dispose of the gull.
- `preview.html`: independent local preview, using a classic script with no imports or network requests.
- `seagull-flap.gif`: a normal animated image of the exact mesh's flap loop, for apps that cannot open HTML.
- PNGs showing the reference glide from the front, a three-quarter view, a top view, and topology.
- `validation.json`: checked geometry and animation properties.

## Shell and rig

**436 unique shell vertices, 868 triangles, one closed connected surface.** The beak, head, torso, tail fan, wings and tucked feet are parts of the same manifold. Wing roots share the body's edges and vertices; no intersecting primitive parts or separate wing shells are used. Eye markings replace faces in the head's surface.

Six bones: body; right inner wing → right outer wing; left inner wing → left outer wing; tail. Both inner wings and the tail are children of body. Each shell vertex has normalized weights to at most two bones. The immutable rest topology and weights are cached and shared. Each independently animated instance reuses its own position buffer. Triangle corners are repeated only in the drawing buffer for flat per-face colors; their deformed positions still come from the same connected shell.

## Two states

`glide` holds the authored reference shape: high elbows, gently lowered outer wings, swept dark tips and tucked feet. It is time invariant after the transition completes. `flap` adds a cyclic inner-wing stroke and delayed outer-wing flex, mirrored left/right, with a small stabilizing tail adjustment. State changes blend over 0.28 seconds by default.

`makeSeagull(GFX, { material, phase })` returns `{ g, mesh, skin, ... }`. Add `g` to the scene and call `poseSeagull(gull, elapsedSeconds, 'flap')` or `poseSeagull(gull, elapsedSeconds, 'glide')` every frame. Optional arguments after the state are strength, cycles per second (default 2.1), and transition duration. Set duration to zero for exact pose sampling or scrubbing. `disposeSeagull(gull)` removes and releases the instance; caller-supplied materials remain caller-owned.

The adapter performs weighted bone skinning on the CPU because the current GFX classes do not expose a smooth skinned-mesh class. It flags the existing position attribute for upload and uses the normal flat-shaded vertex-color material, shadows and outlines. No renderer change, imported model, material creation, geometry rebuilding or topology work is performed per frame.

## Validation and limits

Verified with the game's actual math/geometry/scene/material classes. The logical shell has one connected component, no loose vertices, zero boundary/non-manifold edges, consistent winding, positive volume and non-degenerate triangles. Weights are normalized. Forty-nine flap samples are finite and retain non-zero triangle area. The flap loop closes, glide matches the authored shape at all times after settling, and a state switch at the same time preserves the current pose before blending to glide. Independent instances, persistent buffers and GPU update flags were checked. Preview controls are execution-checked.

The images and animation are rendered from the JavaScript mesh and its rig. In-game visual review remains after integration. This is a model/animation asset and a placement example; it does not add autonomous bird spawning, flight paths, avoidance or gameplay collisions. No existing game files have been replaced or published.
