# Wanderer’s Kit — Region toast additions

Three additive emblems matching the existing region/POI set: open ocean, medium town and small hamlet. Keep the existing `town.png` as the **large town** icon. Do not replace or rename the original19 files.

| Name | New filename stem | Shape |
|---|---|---|
| Open ocean | `open-ocean` | Two curling waves and a rolling swell; no shores |
| Medium town | `town-medium` | Four modest clustered rooftops; no spire or fortifications |
| Small hamlet | `hamlet-small` | Two simple thatched cottages |

## Install

Merge `glyphs-256/` and `badges-96/` alongside the corresponding folders from the first package. Each contains exactly three new PNGs. `shared/toast-badge-blank-96.png` is copied byte-for-byte from the original set, so an existing copy can be retained. Append entries from `icons-additions.json` to the game’s icon registry; adapt IDs to actual game enums.

The 256×256 files are transparent glyphs only. The 96×96 files are complete drop-in badges with the existing leather/brass backing. Use the full96px badge canvas at **x242,y1,width80,height80** relative to the known558×151 toast frame, matching the old sun/moon/region crest slot. Scale the complete toast assembly once. Preserve all transparent export padding.

Draw a badge above the existing frame to cover its baked-in star. Do not put a transparent glyph directly over that star. For an empty inset or runtime composition, draw the shared backing and place the full256px glyph canvas at **12,12,72,72** in the backing’s native96px coordinate space. Do not auto-trim or independently enlarge silhouettes. Keep the full medallion visible above the text panel’s clip rectangle.

Exports are lossless sRGB straight RGBA with smooth antialiased alpha, matching the original painterly UI icons. Use linear filtering and uniform scaling; no nine-slicing. Hover/selected/unavailable treatments, if used elsewhere, remain runtime tints. No changes to the toast frame, text, animation or event timing are supplied.

The overview includes the existing large-town badge for size/style comparison only; that original icon is not duplicated as a new export. All three symbols were made with built-in image generation using the original large-town art as the material reference. `reference/PROMPTS.json` records the prompt set. They were alpha-cleaned and fitted to the original circular safe area. `validation.json` records transparent padding, circular fit and unchanged backing/rim checks. Game event integration is still performed by the implementation agent.
