(function (global) {
  'use strict';
  const ORDER = ['places', 'roads', 'terrain', 'waters', 'markers'];
  const LABELS = ['Places', 'Roads', 'Terrain', 'Waters', 'Markers'];
  let serial = 0;
  const loadImage = url => new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error('Could not load image: ' + url));
    image.src = url;
  });
  const clamp = (x, lo, hi) => Math.max(lo, Math.min(hi, x));
  const niceFloor = n => {
    const p = 10 ** Math.floor(Math.log10(Math.max(n, 1e-9)));
    return [1, 2, 5, 10].filter(v => v * p <= n).pop() * p || p;
  };

  class WandererWorldMap {
    constructor(options = {}) {
      this.options = options;
      this.assetBase = options.assetBase || './ui/map/';
      this.width = 1224; this.height = 700;
      this.bounds = options.bounds || {x: 0, y: 0, width: 1, height: 1};
      this.camera = {x: this.bounds.x + this.bounds.width / 2, y: this.bounds.y + this.bounds.height / 2, zoom: 1};
      this.player = options.player || null;
      this.source = options.source || null;
      this.layers = options.layers || [];
      this.layerState = {...Object.fromEntries(ORDER.map(k => [k, false])), ...(options.layerState || {places: true})};
      this.unitsPerMeter = Number.isFinite(options.worldUnitsPerMeter) && options.worldUnitsPerMeter > 0 ? options.worldUnitsPerMeter : null;
      this.maskCanvas = document.createElement('canvas');
      this.revealedCanvas = document.createElement('canvas');
      this.paperCanvas = document.createElement('canvas');
      this._raf = 0; this._destroyed = false; this._drag = null;
      this.events = new AbortController();
      this._buildDOM();
      this._bind();
      this.resize();
      // Fully unexplored until the game explicitly supplies authoritative exploration data.
      this.setExplored({columns: 1, rows: 1, data: new Uint8Array(1)});
      this.ready = loadImage(this.assetBase + 'fog-parchment-tile.png').then(paper => {
        this.paper = paper;
        this._paintPaper(); this.draw(); return this;
      });
    }

    _buildDOM() {
      const id = 'world-map-title-' + (++serial);
      this.element = document.createElement('section');
      this.element.className = 'wm-root';
      this.element.setAttribute('role', 'dialog');
      this.element.setAttribute('aria-modal', 'false');
      this.element.setAttribute('aria-labelledby', id);
      this.element.innerHTML = `<div class="wm-backdrop"></div><div class="wm-panel">
        <div class="wm-viewport"><canvas class="wm-canvas" tabindex="0" aria-label="World map. Drag to pan, scroll to zoom."></canvas>
          <div class="wm-footer-sheet"></div><div class="wm-legend"><button class="wm-locate" aria-label="Center on player" title="Center on player"><img src="${this.assetBase}compass-rose.png" alt=""></button><span class="wm-n">N</span><span class="wm-e">E</span><span class="wm-s">S</span><span class="wm-w">W</span><canvas class="wm-scale" aria-label="Map scale"></canvas></div>
          <div class="wm-help">Drag to pan · Scroll to zoom</div>
        </div>
        <div class="wm-bookmarks"></div><img class="wm-frame" src="${this.assetBase}frame-body.png" alt="">
        <div class="wm-title"><img src="${this.assetBase}title-plaque.png" alt=""><h1 id="${id}">WORLD MAP</h1></div>
        <button class="wm-close" aria-label="Close world map" title="Close world map">×</button>
      </div>`;
      (this.options.parent || document.body).appendChild(this.element);
      this.panel = this.element.querySelector('.wm-panel');
      this.canvas = this.element.querySelector('.wm-canvas');
      this.scaleCanvas = this.element.querySelector('.wm-scale');
      this.closeButton = this.element.querySelector('.wm-close');
      this.buttons = {};
      const holder = this.element.querySelector('.wm-bookmarks');
      ORDER.forEach((name, index) => {
        const button = document.createElement('button');
        button.className = 'wm-bookmark'; button.dataset.layer = name;
        button.setAttribute('aria-pressed', String(!!this.layerState[name]));
        button.innerHTML = `<img src="${this.assetBase}glyph-${name}.png" alt=""><span>${LABELS[index]}</span>`;
        holder.appendChild(button); this.buttons[name] = button;
      });
    }

    _bind() {
      const signal = this.events.signal;
      this.closeButton.addEventListener('click', () => this.close(), {signal});
      this.element.querySelector('.wm-locate').addEventListener('click', () => this.locatePlayer(), {signal});
      for (const name of ORDER) this.buttons[name].addEventListener('click', () => this.setLayer(name, !this.layerState[name]), {signal});
      this.element.addEventListener('keydown', e => {
        if (e.key === 'Escape') {e.preventDefault(); this.close();}
        if (e.target !== this.canvas) return;
        const step = 50 / this.camera.zoom;
        const moves = {ArrowLeft: [-step, 0], ArrowRight: [step, 0], ArrowUp: [0, -step], ArrowDown: [0, step]};
        if (moves[e.key]) {e.preventDefault(); this.camera.x += moves[e.key][0]; this.camera.y += moves[e.key][1]; this._clampCenter(); this.invalidate();}
        if (e.key === '+' || e.key === '=') {e.preventDefault(); this.zoomBy(1.2);}
        if (e.key === '-') {e.preventDefault(); this.zoomBy(1 / 1.2);}
      }, {signal});
      this.canvas.addEventListener('wheel', e => {
        e.preventDefault(); this.zoomBy(2 ** (-clamp(e.deltaY, -600, 600) / 700), this.localPoint(e));
      }, {passive: false, signal});
      this.canvas.addEventListener('pointerdown', e => {
        if (e.button !== 0) return;
        e.preventDefault(); this.canvas.focus({preventScroll: true});
        const p = this.localPoint(e);
        this._drag = {id: e.pointerId, last: p, start: p, moved: false};
        this.canvas.setPointerCapture(e.pointerId);
      }, {signal});
      this.canvas.addEventListener('pointermove', e => {
        const drag = this._drag;
        if (!drag || drag.id !== e.pointerId) return;
        const p = this.localPoint(e);
        if (Math.hypot(p.x - drag.start.x, p.y - drag.start.y) > 4) drag.moved = true;
        if (drag.moved) {
          this.camera.x -= (p.x - drag.last.x) / this.camera.zoom;
          this.camera.y -= (p.y - drag.last.y) / this.camera.zoom;
          this._clampCenter(); this.invalidate();
        }
        drag.last = p;
      }, {signal});
      const finish = e => {
        const drag = this._drag;
        if (!drag || drag.id !== e.pointerId) return;
        if (e.type === 'pointerup' && !drag.moved && this.options.onMapClick) {
          const world = this.screenToWorld(this.localPoint(e));
          if (this.isExplored(world.x, world.y)) this.options.onMapClick(world);
        }
        this._drag = null;
        if (this.canvas.hasPointerCapture(e.pointerId)) this.canvas.releasePointerCapture(e.pointerId);
      };
      this.canvas.addEventListener('pointerup', finish, {signal});
      this.canvas.addEventListener('pointercancel', finish, {signal});
      window.addEventListener('resize', () => this.resize(), {signal});
    }

    localPoint(event) {
      const r = this.canvas.getBoundingClientRect();
      return {x: (event.clientX - r.left) * this.width / r.width, y: (event.clientY - r.top) * this.height / r.height};
    }
    screenToWorld(p) {return {x: this.camera.x + (p.x - this.width / 2) / this.camera.zoom, y: this.camera.y + (p.y - this.height / 2) / this.camera.zoom};}
    worldToScreen(p) {return {x: this.width / 2 + (p.x - this.camera.x) * this.camera.zoom, y: this.height / 2 + (p.y - this.camera.y) * this.camera.zoom};}
    _clampCenter() {
      this.camera.x = clamp(this.camera.x, this.bounds.x, this.bounds.x + this.bounds.width);
      this.camera.y = clamp(this.camera.y, this.bounds.y, this.bounds.y + this.bounds.height);
    }
    resize() {
      this.uiScale = Math.min(innerWidth / 1920, innerHeight / 1080);
      this.element.style.setProperty('--wm-scale', this.uiScale);
      this.ratio = Math.max(1, Math.min(4, (devicePixelRatio || 1) * this.uiScale));
      for (const canvas of [this.canvas, this.paperCanvas, this.revealedCanvas]) {
        canvas.width = Math.round(this.width * this.ratio); canvas.height = Math.round(this.height * this.ratio);
      }
      this._paintPaper(); this.invalidate();
    }
    setSource(source, bounds) {
      this.source = source;
      if (bounds) this.bounds = {...bounds};
      this._clampCenter(); this.invalidate();
    }
    setLayers(layers) {this.layers = layers || []; this.invalidate();}
    setLayer(name, enabled, {notify = true} = {}) {
      if (!ORDER.includes(name)) throw new Error('Unknown map layer: ' + name);
      this.layerState[name] = !!enabled;
      this.buttons[name].setAttribute('aria-pressed', String(!!enabled));
      if (notify) {
        if (this.options.onLayerChange) this.options.onLayerChange(name, !!enabled);
        this.element.dispatchEvent(new CustomEvent('worldmap:layer-change', {detail: {name, enabled: !!enabled}}));
      }
      this.invalidate();
    }
    setExplored({columns, rows, data}) {
      if (!Number.isInteger(columns) || !Number.isInteger(rows) || columns < 1 || rows < 1 || !data || data.length !== columns * rows) throw new Error('Exploration grid dimensions/data do not match');
      this.exploration = {columns, rows, data: Uint8Array.from(data, v => v ? 1 : 0)};
      this.maskCanvas.width = columns; this.maskCanvas.height = rows;
      const ctx = this.maskCanvas.getContext('2d'); const image = ctx.createImageData(columns, rows);
      for (let i = 0; i < data.length; i++) {image.data[i * 4] = image.data[i * 4 + 1] = image.data[i * 4 + 2] = 255; image.data[i * 4 + 3] = data[i] ? 255 : 0;}
      ctx.putImageData(image, 0, 0); this.invalidate();
    }
    isExplored(x, y) {
      const b = this.bounds, e = this.exploration;
      if (!e || x < b.x || y < b.y || x >= b.x + b.width || y >= b.y + b.height) return false;
      const col = Math.floor((x - b.x) * e.columns / b.width), row = Math.floor((y - b.y) * e.rows / b.height);
      return !!e.data[row * e.columns + col];
    }
    setCamera({x = this.camera.x, y = this.camera.y, zoom = this.camera.zoom}) {
      this.camera = {x, y, zoom: Math.max(1e-4, zoom)}; this._clampCenter(); this.invalidate();
    }
    zoomBy(factor, p = {x: this.width / 2, y: this.height / 2}) {
      const fixed = this.screenToWorld(p);
      const fit = Math.min(this.width / this.bounds.width, this.height / this.bounds.height);
      const zoom = clamp(this.camera.zoom * factor, fit * .65, fit * 6);
      this.camera.zoom = zoom;
      this.camera.x = fixed.x - (p.x - this.width / 2) / zoom;
      this.camera.y = fixed.y - (p.y - this.height / 2) / zoom;
      this._clampCenter(); this.invalidate();
    }
    locatePlayer() {
      if (this.player) this.setCamera({x: this.player.x, y: this.player.y});
      if (this.options.onLocate) this.options.onLocate();
    }
    _paintPaper() {
      if (!this.paperCanvas.width) return;
      const ctx = this.paperCanvas.getContext('2d');
      ctx.setTransform(this.ratio || 1, 0, 0, this.ratio || 1, 0, 0);
      ctx.clearRect(0, 0, this.width, this.height);
      ctx.fillStyle = '#e5bd86';
      if (this.paper) {const p = ctx.createPattern(this.paper, 'repeat'); p.setTransform(new DOMMatrix().scale(.5)); ctx.fillStyle = p;}
      ctx.fillRect(0, 0, this.width, this.height);
      if (this.options.folds !== false) {
        // Creases belong to the physical sheet. The explored map paints over them.
        ctx.fillStyle = '#65401f12'; ctx.fillRect(0, Math.round(this.height * .54), this.width, 1);
        ctx.fillStyle = '#fff5db16'; ctx.fillRect(0, Math.round(this.height * .54) + 1, this.width, 1);
        ctx.fillStyle = '#65401f09'; ctx.fillRect(Math.round(this.width * .36), 0, 1, this.height);
      }
    }
    invalidate() {
      if (this._destroyed || this._raf) return;
      this._raf = requestAnimationFrame(() => {this._raf = 0; this.draw();});
    }
    draw() {
      if (this._destroyed || this.element.hidden) return;
      const w = this.width, h = this.height, d = this.ratio, b = this.bounds, c = this.camera;
      const revealed = this.revealedCanvas.getContext('2d');
      revealed.setTransform(1, 0, 0, 1, 0, 0); revealed.clearRect(0, 0, this.canvas.width, this.canvas.height);
      revealed.setTransform(d, 0, 0, d, 0, 0); revealed.imageSmoothingEnabled = false;
      const tx = w / 2 - c.x * c.zoom, ty = h / 2 - c.y * c.zoom;
      revealed.save(); revealed.translate(tx, ty); revealed.scale(c.zoom, c.zoom);
      revealed.beginPath(); revealed.rect(b.x, b.y, b.width, b.height); revealed.clip();
      if (this.source) revealed.drawImage(this.source, b.x, b.y, b.width, b.height);
      for (const layer of this.layers) {
        if (!this.layerState[layer.id]) continue;
        revealed.save();
        if (layer.source) revealed.drawImage(layer.source, b.x, b.y, b.width, b.height);
        if (layer.draw) layer.draw(revealed, {bounds: b, camera: {...c}});
        revealed.restore();
      }
      if (this.options.drawWorldOverlay) {revealed.save(); this.options.drawWorldOverlay(revealed, {bounds: b, camera: {...c}}); revealed.restore();}
      revealed.restore();
      // Apply the authoritative world-space exploration mask to EVERY content layer.
      revealed.globalCompositeOperation = 'destination-in';
      revealed.save(); revealed.translate(tx, ty); revealed.scale(c.zoom, c.zoom);
      revealed.drawImage(this.maskCanvas, b.x, b.y, b.width, b.height); revealed.restore();
      revealed.globalCompositeOperation = 'source-over';
      const ctx = this.canvas.getContext('2d'); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
      ctx.drawImage(this.paperCanvas, 0, 0); ctx.drawImage(this.revealedCanvas, 0, 0);
      this._drawScale();
    }
    _drawScale() {
      const canvas = this.scaleCanvas; const d = this.ratio;
      canvas.width = Math.round(166 * d); canvas.height = Math.round(42 * d);
      const ctx = canvas.getContext('2d'); ctx.scale(d, d); ctx.strokeStyle = '#684124'; ctx.fillStyle = '#684124';
      const segment = niceFloor(140 / this.camera.zoom / 3); const px = segment * 3 * this.camera.zoom;
      const x = 12, y = 10; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + px, y); ctx.stroke();
      const meters = this.unitsPerMeter ? segment / this.unitsPerMeter : segment;
      const km = this.unitsPerMeter && meters * 3 >= 1000; const unit = this.unitsPerMeter ? (km ? 'km' : 'm') : 'units';
      ctx.font = '12px Spectral, serif'; ctx.textAlign = 'center';
      for (let i = 0; i < 4; i++) {const xx = x + px * i / 3; ctx.beginPath(); ctx.moveTo(xx, y - 5); ctx.lineTo(xx, y + 5); ctx.stroke(); const value = meters * i / (km ? 1000 : 1); ctx.fillText(Number(value.toPrecision(3)).toString(), xx, y + 19);}
      ctx.textAlign = 'right'; ctx.fillText(unit, 160, 39);
      canvas.setAttribute('aria-label', `Scale: ${Number((meters * 3 / (km ? 1000 : 1)).toPrecision(3))} ${unit}`);
    }
    open({focus = false} = {}) {
      this.element.hidden = false;
      if (focus) {this.previousFocus = document.activeElement; this.closeButton.focus({preventScroll: true});}
      this.invalidate();
    }
    close() {
      this.element.hidden = true; this._drag = null;
      if (this.options.onClose) this.options.onClose();
      this.element.dispatchEvent(new CustomEvent('worldmap:close'));
      if (this.previousFocus && this.previousFocus.isConnected) this.previousFocus.focus({preventScroll: true});
    }
    destroy() {
      this._destroyed = true; this.events.abort(); cancelAnimationFrame(this._raf); this.element.remove();
    }
  }
  WandererWorldMap.loadImage = loadImage;
  WandererWorldMap.layerOrder = ORDER.slice();
  global.WandererWorldMap = WandererWorldMap;
})(window);
