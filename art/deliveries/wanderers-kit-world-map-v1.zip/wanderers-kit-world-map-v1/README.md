# Wanderer’s Kit — World Map production v1

World-map add-on for the already handed-off Desktop V3 kit. The leather casing, raised title, five colored cloth bookmarks, paper fog, compass and close control follow the approved pixel-map mockup.

## Start here

- Open `preview.html` in a modern desktop browser for the assembled reference implementation. M toggles the map; Escape closes it. Drag, wheel, arrow keys and +/− control the map. The compass centers on the sample player.
- Open `asset-proof.html` to inspect bookmark and close-control states.
- Give the coding agent `WORLD_MAP_CODING_HANDOFF.md`, `ASSET_SPEC.md`, `layout.json`, `manifest.json`, `ui/map/`, `css/world-map.css`, `js/world-map.js` and the font files/licenses.
- `world-map-preview-1920x1080.png` shows the actual assembled implementation. `approved-vs-production-world-map.png` compares it with the approved mockup. `world-map-fog-proof.png` shows unknown, partial and fully explored states.

## Contents and scope

43 production PNGs, plus a compass SVG source; fixed 2× frame/control exports; six states for each bookmark; four close states; five separate glyphs; an opaque seamless paper tile. Text, compass directions and scale values are live.

This is a standalone add-on, not a replacement of Desktop V3. The inventory, character equipment and four-output refining window remain in V3. `demo/hud-ui`, `demo/hud-icons` and `demo/hud.css` reuse the V3 HUD only to show context.

The preview uses a crop of the supplied game screenshot, uniformly scaled with nearest-neighbor sampling. Its labels, roads and player arrow are already baked in. Bookmark events and button states work, but cannot remove those baked features. Production wiring must supply the game’s real layers, camera and exploration data. The sample exploration shape and sample units-to-meters conversion are demonstration data, not gameplay requirements.

## Validation

`browser-validation.json` records successful checks at 1280×720, 1920×1080, 2560×1440, 3840×2160 and 3440×1440: layout bounds, HUD clearance, image loading, independent layer toggles, pointer pan, cursor-anchored zoom, close/reopen, explored-only clicks and opaque fog concealment of a test overlay. `asset-validation.json` records file-level checks.

No game repository was supplied or modified. The included JavaScript is a tested reference renderer and integration starting point; the coding agent must connect it to the actual game.
