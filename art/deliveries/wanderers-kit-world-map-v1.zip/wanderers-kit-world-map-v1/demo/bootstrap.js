(async function () {
  const updateHUD = () => document.body.style.setProperty('--s', Math.min(innerWidth / 1920, innerHeight / 1080));
  updateHUD(); addEventListener('resize', updateHUD);
  const source = await WandererWorldMap.loadImage('./demo/runtime-map.png');
  const mapButton = document.querySelector('[data-map-command]');
  window.worldMapEvents = [];
  const map = new WandererWorldMap({
    source, bounds: {x: 0, y: 0, width: source.width, height: source.height},
    player: {x: source.width * .5, y: source.height * .5},
    // This scale conversion is sample-only; the game must supply its actual units.
    worldUnitsPerMeter: .1,
    layerState: {places: true, roads: false, terrain: false, waters: false, markers: false},
    onLayerChange: (name, enabled) => worldMapEvents.push({name, enabled}),
    onClose: () => {document.body.classList.remove('map-open'); mapButton.setAttribute('aria-pressed', 'false');}
  });
  window.mapView = map;
  const sample = {columns: SAMPLE_EXPLORED.columns, rows: SAMPLE_EXPLORED.rows, data: SAMPLE_EXPLORED.data.slice()};
  map.setExplored(sample);
  const initial = {x: source.width * .5, y: source.height * .5, zoom: 1.4};
  map.setCamera(initial);
  const toggle = () => {
    if (map.element.hidden) {document.body.classList.add('map-open'); mapButton.setAttribute('aria-pressed', 'true'); map.open({focus: true});}
    else map.close();
  };
  mapButton.addEventListener('click', toggle);
  addEventListener('keydown', e => {
    if (e.key === 'Escape' && !map.element.hidden && !e.defaultPrevented) {e.preventDefault(); map.close(); return;}
    if (e.key.toLowerCase() === 'm' && !/input|textarea|select/i.test(e.target.tagName)) {e.preventDefault(); toggle();}
  });
  window.mapDemo = {
    initialCamera: {...initial}, sample,
    fog(mode) {map.setExplored(mode === 'sample' ? sample : {columns: sample.columns, rows: sample.rows, data: new Uint8Array(sample.columns * sample.rows).fill(mode === 'none' ? 1 : 0)}); map.draw();},
    reset() {map.setCamera(initial); this.fog('sample');}
  };
  await map.ready; map.draw();
  window.mapReady = true;
})().catch(error => {window.mapError = error.message; console.error(error);});
