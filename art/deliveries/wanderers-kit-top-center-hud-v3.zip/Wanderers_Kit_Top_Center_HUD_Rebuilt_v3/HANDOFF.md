# Wanderer’s Kit top-center HUD — rebuilt exports v3

This set rebuilds the complete top-center asset exports from the intact original **Wanderer’s Kit Leather UI Atlas.png**. No v1/v2 cropped PNG is used as an input. The artwork is preserved rather than repainted: the directly extracted crest RGB values match the original source pixels exactly. Every object has a new crop and independent alpha-component mask, so neighboring atlas objects cannot enter its export. The toast is recovered as a complete frame, including its full crest and continuous upper border.

## Replace the complete previous set

Use this ZIP as one coherent set. Remove the old optional-icon files and rough toast slices from the integration; do not combine old UVs, old sprite dimensions or old alpha bounds with these files. No game repository was provided, so these are assets and exact integration instructions, not an implemented game change.

| Asset | Native PNG dimensions | Role |
|---|---|---|
| `assets/npc_frame_blank.png` | 896×144 | NPC name and profession |
| `assets/enemy_frame_blank.png` | 1088×144 | Enemy target frame |
| `assets/toast_frame_blank.png` | 558×151 | Full floating toast; complete default compass crest |
| `assets/level_medallion_blank.png` | 64×64 | Blank enemy level surround |
| `assets/hp_track_back.png` | 636×28 | Empty HP track |
| `assets/hp_track_rim_overlay.png` | 636×28 | Rim drawn above HP fill |
| `assets/hp_fill_amber.png`, `hp_fill_red.png` | 616×12 each | Fixed-size full fill, revealed by clipping |
| `assets/hp_fill_clip_mask.png` | 616×12 | Optional separate rounded alpha mask |
| `assets/crests/{compass,sun,moon,dawn,dusk,diamond}.png` | 96×96 each | One complete circular badge per file, with transparent padding |
| `assets/ornaments/*.png` | See manifest | Separate star glyph, two laurels, line and diamond; optional decorations |

Four additional module PNGs provide the top-banner construction described below. `asset_manifest.json` lists every exact dimension and hash; `layout.json` is the machine-readable positioning contract. All values in this document are native PNG pixels. Multiply all positions, dimensions, clip widths and font sizes by one shared UI display scale. For example, scale 0.625 displays the enemy at 680×90 pixels. Keep the game’s existing scale policy; do not assume these PNG pixels are automatically 2× logical units.

## Enemy layout

| Layer | Rectangle / center at native scale |
|---|---|
| Frame | `(0,0,1088,144)` |
| Level surround | `(164,38,64,64)` |
| Live level text | center `(196,70)`, font size 28 |
| Name | rect `(260,34,636,34)`, center `(578,51)`, font size 30 |
| HP back and rim | `(260,78,636,28)` |
| HP fill | `(270,86,616,12)` |
| HP fill relative to track | `(10,8,616,12)`, rounded radius 5 |

Use the existing Wanderer’s Kit Spectral SemiBold, cream `#F0DFB7`, and dark brown shadow `#21130D` at `(1,1)`. Match the engine’s actual font metrics, rather than treating center coordinates as baselines. Levels 1,9,10,99 were measured and rendered; 99 uses 30×19 pixels inside a 36×30 safe ink area. The surround’s visible bounds are `[171,45,221,96)` within the frame, with clear leather above and below. Do not enlarge it until it overlaps stitching or the lower border. Level 99 is a fit test, not a new progression cap.

Draw frame, medallion and live level, HP back, clipped HP fill, HP rim, then name. HP fraction is `p = maxHP>0 ? clamp(currentHP/maxHP,0,1) : 0`. At native width reveal `616*p` pixels of the full interior texture from the left. Draw the fill at its full fixed rectangle, then clip; do not shrink the texture to the percentage. At zero skip the fill; at 100% show it fully. The exported fills already have rounded alpha. Apply the separate mask only if the renderer requires it, without multiplying the antialiased edge twice.

The back/rim have fixed 14-pixel caps. For a wider track, keep source x `[0,14)` and `[622,636)` fixed and stretch only x `[14,622)`. The fill follows the new full interior width, while its reveal still clips by fraction. Do not stretch the end-cap curvature.

## NPC layout

The native NPC frame is 896×144. Name center `(448,53)`, size30; profession center `(448,89)`, size24. Use the existing Spectral Italic for profession if desired. No HP or level is added to NPCs. Measure text within the interior: reduce one font step or ellipsize if it exceeds the available width; keep the full name in the existing tooltip/accessibility path.

## Toast and crest swapping

The toast is a **558×151** full sprite, including its raised crest and eight pixels of transparent safety padding around the entire extracted artwork. Allocate the full height; do not clip it to the rectangular text body. Draw the title at center `(279,96)`, size25, within `(35,77,488,38)`. Keep one line and measure/ellipsize very long messages within that box.

The default star is already painted into the frame. For a variant, draw exactly one complete `assets/crests/*.png` badge at `(242,1,80,80)`. Render the **entire 96×96 source canvas** into that rectangle, including its transparent padding. The colored disc covers the existing star disc and ring. Do not crop the icon to old atlas UVs or use the old sun/moon source sizes. All six source badges use the same canvas convention.

Suggested events: compass for discovery, sun for Day Rises, moon for Night Falls, dawn/dusk for those transitions, diamond for region entry. The contents and timing remain controlled by existing game logic. Fade/move the entire toast group, including the variant crest and title. `previews/all-toast-variants.png` shows every complete combination built with these exact coordinates.

The complete toast is scaled uniformly for different UI sizes. No rough toast slices are supplied or required. Do not stretch only its middle or clip away the raised crest. If the product later needs a truly variable-width toast, build and verify a separate protected-crest construction rather than improvising UV cuts.

## Top-banner width construction

Four sprites form five regions: left cap 192×144, straight repeat 32×144, fixed center notch 64×144, the same straight repeat on the right, and right cap 192×144. Keep rigid hardware/curves fixed. Only the straight leather and stitching repeat.

```text
W = 448 + 64*n
left cap:   x=0
left tiles: x=192+32*i, i=0…n-1
notch:      x=192+32*n, once only
right tiles:x=256+32*n+32*i, i=0…n-1
right cap:  x=256+64*n
```

NPC uses n=7; enemy uses n=10. Wider names can use a larger integer n within the viewport. Both sides use the same count so the single notch stays centered. All file paths are in `assets/modules/`. Repeat first/last columns and cap/notch join columns match exactly. Use complete 32-pixel repeats with clamp/extrusion for each sprite, not partial tiles or stretched buckles. The reconstructed whole frames already match this construction at their native sizes.

For enemy width W, level stays fixed at its left-side coordinates; HP rect becomes `(260,78,W-452,28)`, fill rect `(270,86,W-472,12)`, and name box `(260,34,W-452,34)`. Center the name within its new box.

Anchor NPC/enemy groups top-center. Native frames include eight transparent top pixels: a root y offset of `-8*displayScale` places the first visible art at the viewport edge. Apply that translation uniformly to all child layers. Toast remains floating at the existing toast offset. Background artwork remains decorative and passes pointer input through.

## Rendering and verification

Use smooth linear sampling, sRGB color textures and normal RGBA blending. Files contain straight alpha; convert once if the renderer expects premultiplied alpha. Fully transparent RGB is cleared. Opaque interiors have been restored from the source’s slightly translucent generated alpha; alpha edges remain antialiased. Do not add a global warm tint: the gold/leather colors are already from the approved source.

Every exported asset is shown individually against light and dark in `previews/all-assets-dark-and-light.png`. The overview, all toast variants and level/HP states are assembled from exported files. The crest crops each contain one complete foreground object, have transparent padding on all sides, and retain exactly the source foreground RGB. The toast’s complete upper curve and star are inside its alpha bounds. The checks also cover level text fit, frame containment, zero/full HP, long names and fixed-notch joins. See `reference/validation.json` and `reference/extraction-source.json` for the recorded bounds and provenance.

These are export and assembly checks. The coding agent still needs to validate the actual game’s UI scale, glyph metrics, clipping containers and HP updates after integration. In particular, remove any previous toast body-height scissor and old cropped-icon UVs so they cannot reintroduce the same visible clipping.
