/* Reference DOM adapter. Bind these events to the game's existing storage controller. */
(() => {
  const assetRoot = new URL('../assets/', document.currentScript.src).href;
  class WanderersCrateWindow extends HTMLElement {
    constructor() {
      super();
      this.crateId='';this.items=Array(10).fill(null);this.unavailable=Array(10).fill(false);this.selectedIndex=-1;
    }
    connectedCallback() {
      if(this._ready) return;this._ready=true;
      this.classList.add('wk-crate');
      this.setAttribute('role','dialog');
      this.setAttribute('aria-modal','false');
      this.setAttribute('aria-label','Wooden Crate storage');
      this.style.setProperty('--wk-slot-mask',`url("${assetRoot}crate-slot-tint-mask@2x.png")`);
      const frame = document.createElement('img');
      frame.className='wk-frame';frame.src=assetRoot+'crate-window-normal@2x.png';frame.alt='';frame.draggable=false;
      this.append(frame);
      const drag = document.createElement('div');drag.className='wk-drag';drag.setAttribute('aria-hidden','true');
      drag.addEventListener('pointerdown',e => this.dispatchEvent(new CustomEvent('crate-drag-start',{bubbles:true,detail:{crateId:this.crateId,pointerEvent:e}})));
      this.append(drag);
      this.heading=document.createElement('h2');this.heading.className='wk-title';this.heading.textContent='Wooden Crate';this.append(this.heading);
      this.counter=document.createElement('span');this.counter.className='wk-capacity';this.counter.setAttribute('aria-live','polite');this.append(this.counter);
      this.closeButton=document.createElement('button');this.closeButton.className='wk-close';this.closeButton.type='button';this.closeButton.setAttribute('aria-label','Close crate');
      const closeArt=document.createElement('img');closeArt.src=assetRoot+'crate-close-normal@2x.png';closeArt.alt='';closeArt.draggable=false;this.closeButton.append(closeArt);
      this.closeButton.addEventListener('click',() => this.requestClose());this.append(this.closeButton);
      this.slots=Array.from({length:10},(_,index) => {
        const b=document.createElement('button');b.className='wk-slot';b.type='button';b.dataset.index=String(index);
        b.style.left=(106+(index%5)*128)+'px';b.style.top=(154+Math.floor(index/5)*122)+'px';
        b.addEventListener('click',() => { if(this.unavailable[index]) return; this.setSelected(index); this.emitSlot('crate-slot-activate',index); });
        b.addEventListener('contextmenu',e => { e.preventDefault(); if(!this.unavailable[index]) this.emitSlot('crate-slot-context',index); });
        b.addEventListener('dragover',e => { if(!this.unavailable[index]) e.preventDefault(); });
        b.addEventListener('drop',e => { e.preventDefault();if(!this.unavailable[index]) this.emitSlot('crate-slot-drop',index,{dataTransfer:e.dataTransfer}); });
        b.addEventListener('keydown',e => {
          const delta={ArrowLeft:-1,ArrowRight:1,ArrowUp:-5,ArrowDown:5}[e.key];
          if(delta!==undefined){e.preventDefault();this.slots[Math.max(0,Math.min(9,index+delta))].focus();}
        });
        this.append(b);return b;
      });
      this.addEventListener('keydown',e => { if(e.key==='Escape'){e.stopPropagation();this.requestClose();} });
      this.render();
    }
    emitSlot(name,index,extra={}) { this.dispatchEvent(new CustomEvent(name,{bubbles:true,detail:{crateId:this.crateId,index,item:this.items[index],...extra}})); }
    open(crateId,title='Wooden Crate') {
      this.crateId=String(crateId);this.heading.textContent=String(title);this.heading.title=String(title);
      this.setAttribute('aria-label',String(title)+' storage');this.hidden=false;this.closeButton.focus({preventScroll:true});
    }
    requestClose() {
      const accepted=this.dispatchEvent(new CustomEvent('crate-close-request',{bubbles:true,cancelable:true,detail:{crateId:this.crateId}}));
      if(accepted) this.hidden=true;
    }
    setContents(items) {
      if(!Array.isArray(items)||items.length>10) throw new RangeError('Crate contents require an array with at most ten entries.');
      this.items=Array.from({length:10},(_,i)=>items[i]?{...items[i]}:null);this.render();
    }
    setSlotUnavailable(index,value) { if(!Number.isInteger(index)||index<0||index>9) throw new RangeError('Invalid crate slot');this.unavailable[index]=Boolean(value);this.render(); }
    setSelected(index) { this.selectedIndex=Number.isInteger(index)&&index>=0&&index<10?index:-1;this.render(); }
    render() {
      if(!this.slots) return;
      this.counter.textContent=this.items.filter(Boolean).length+' / 10';
      this.slots.forEach((b,index) => {
        const item=this.items[index];b.replaceChildren();b.setAttribute('aria-pressed',String(this.selectedIndex===index));
        b.setAttribute('aria-disabled',String(this.unavailable[index]));
        b.setAttribute('aria-label',`Slot ${index+1}: ${item?.label||'Empty'}${this.unavailable[index]?', unavailable':''}`);
        b.title=item?.label||'Empty slot';
        if(item?.iconUrl){const im=document.createElement('img');im.className='wk-item';im.src=item.iconUrl;im.alt='';im.draggable=false;b.append(im);}
        if(item?.quantity>1){const q=document.createElement('span');q.className='wk-quantity';q.textContent=String(item.quantity);b.append(q);}
      });
    }
  }
  customElements.define('wk-crate-window',WanderersCrateWindow);
})();
