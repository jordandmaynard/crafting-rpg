(function (global) {
  'use strict';
  const PERIODS = ['night', 'dawn', 'day', 'dusk'];
  const DEFAULT_KEYS = [
    {phase: 0, sky: 'night'}, {phase: .19, sky: 'night'},
    {phase: .25, sky: 'dawn'}, {phase: .31, sky: 'day'},
    {phase: .69, sky: 'day'}, {phase: .75, sky: 'dusk'},
    {phase: .81, sky: 'night'}, {phase: 1, sky: 'night'}
  ];
  const clamp = (n, lo, hi) => Math.max(lo, Math.min(hi, n));
  function normalize(phase) {
    if (!Number.isFinite(phase)) throw new Error('Watch phase must be a finite number.');
    return ((phase % 1) + 1) % 1;
  }
  function validateKeys(keys) {
    if (!Array.isArray(keys) || keys.length < 2 || keys[0].phase !== 0 || keys.at(-1).phase !== 1 || keys[0].sky !== keys.at(-1).sky) throw new Error('Watch keys must span 0–1 and use the same sky at both ends.');
    for (let i = 0; i < keys.length; i++) {
      if (!Number.isFinite(keys[i].phase) || !PERIODS.includes(keys[i].sky) || (i && keys[i].phase <= keys[i - 1].phase)) throw new Error('Invalid or unordered watch keyframes.');
    }
    return keys.map(k => ({phase: k.phase, sky: k.sky}));
  }
  function weightsForPhase(phase, keys = DEFAULT_KEYS) {
    const p = normalize(phase); const out = Object.fromEntries(PERIODS.map(k => [k, 0]));
    let index = 0;
    while (index < keys.length - 2 && p >= keys[index + 1].phase) index++;
    const a = keys[index], b = keys[index + 1];
    const f = clamp((p - a.phase) / (b.phase - a.phase), 0, 1);
    const t = f * f * (3 - 2 * f);
    out[a.sky] += 1 - t; out[b.sky] += t;
    return out;
  }
  function loadImage(url) {
    return new Promise((resolve, reject) => {
      const image = new Image();
      image.onload = () => resolve(image);
      image.onerror = () => reject(new Error('Could not load watch asset: ' + url));
      image.src = url;
    });
  }

  class CelestialWatchStrip {
    constructor(canvas, options = {}) {
      if (!canvas || !canvas.getContext) throw new Error('A watch canvas is required.');
      this.canvas = canvas; this.width = 272; this.height = 34;
      const base = options.assetBase || './ui/minimap/';
      this.assetBase = new URL(base.endsWith('/') ? base : base + '/', document.baseURI).href;
      this.keys = validateKeys(options.keyframes || DEFAULT_KEYS);
      this.phase = normalize(options.phase ?? 0);
      this.destroyed = false; this.images = null;
      this.resize(options.pixelRatio || 1);
      this.ready = Promise.all([...PERIODS.map(k => ['sky-' + k, 'sky-' + k + '.png']), ['sun', 'sun.png'], ['moon', 'moon.png']].map(async ([name, file]) => [name, await loadImage(this.assetBase + file)])).then(entries => {
        if (!this.destroyed) {this.images = Object.fromEntries(entries); this.draw();}
        return this;
      });
    }

    resize(pixelRatio = 1) {
      if (!Number.isFinite(pixelRatio) || pixelRatio <= 0) throw new Error('Invalid watch pixel ratio.');
      this.ratio = clamp(pixelRatio, 1, 4);
      this.canvas.width = Math.ceil(this.width * this.ratio);
      this.canvas.height = Math.ceil(this.height * this.ratio);
      this.draw();
    }
    setPhase(phase) {
      if (this.destroyed) return;
      this.phase = normalize(phase); this.draw();
    }
    setKeyframes(keys) {this.keys = validateKeys(keys); this.draw();}

    frameState() {
      const p = this.phase, w = this.width, h = this.height;
      const distance = event => normalize(event - p + .5) - .5;
      const altitude = Math.cos(2 * Math.PI * (p - .5));
      return {
        phase: p, weights: weightsForPhase(p, this.keys),
        tileWidth: w, skyOffset: -p * w,
        sun: {x: w / 2 + distance(.5) * w * 1.4, y: h * (.92 - .42 * altitude), size: 36, alpha: clamp(1 + altitude * 5, 0, 1)},
        moon: {x: w / 2 + distance(0) * w * 1.4, y: h * .44, size: 28, alpha: clamp(1 - altitude * 1.5, 0, 1)}
      };
    }

    _tile(ctx, image, offset) {
      // Same UV/offset for every lighting layer. These textures are all 8:1.
      const tileWidth = this.width;
      for (let x = offset - tileWidth; x < this.width; x += tileWidth) ctx.drawImage(image, x, 0, tileWidth, this.height);
    }
    draw() {
      if (this.destroyed) return;
      const ctx = this.canvas.getContext('2d');
      ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
      ctx.fillStyle = '#17253b'; ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
      ctx.setTransform(this.ratio, 0, 0, this.ratio, 0, 0); ctx.imageSmoothingEnabled = true;
      const state = this.frameState(); this.lastFrame = state;
      if (!this.images) return;
      const active = PERIODS.map(k => [k, state.weights[k]]).filter(([, w]) => w > 0);
      // Paint the first image opaque. Subsequent source-over alpha is its share
      // of the accumulated weights, avoiding transparency/darkening in a dissolve.
      let accumulated = 0;
      for (const [name, weight] of active) {
        ctx.globalAlpha = accumulated === 0 ? 1 : weight / (accumulated + weight);
        this._tile(ctx, this.images['sky-' + name], state.skyOffset);
        accumulated += weight;
      }
      for (const name of ['sun', 'moon']) {
        const marker = state[name];
        ctx.globalAlpha = marker.alpha;
        ctx.drawImage(this.images[name], marker.x - marker.size / 2, marker.y - marker.size / 2, marker.size, marker.size);
      }
      ctx.globalAlpha = 1;
    }
    destroy() {this.destroyed = true; this.images = null;}
  }
  CelestialWatchStrip.normalizePhase = normalize;
  CelestialWatchStrip.weightsForPhase = weightsForPhase;
  CelestialWatchStrip.defaultKeyframes = DEFAULT_KEYS.map(k => ({...k}));
  global.CelestialWatchStrip = CelestialWatchStrip;
})(window);
