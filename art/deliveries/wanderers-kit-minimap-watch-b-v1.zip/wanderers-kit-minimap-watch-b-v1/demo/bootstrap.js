(async function () {
  const params = new URLSearchParams(location.search);
  const root = document.querySelector('.wk-mini');
  const compass = root.querySelector('.wk-mini-compass');
  const timeText = root.querySelector('.wk-mini-time');
  const slider = document.querySelector('[data-phase]');
  const readout = document.querySelector('[data-readout]');
  const play = document.querySelector('[data-play]');
  if (params.get('proof') === '1') document.body.classList.add('proof');
  if (params.get('dock') === '1') {document.body.classList.add('docked'); root.classList.add('wk-mini-dock');}
  const sampleLabel = phase => phase < .19 || phase >= .81 ? 'Night' : phase < .31 ? 'Dawn' : phase < .5 ? 'Morning' : phase < .69 ? 'Afternoon' : 'Dusk';
  const watch = new CelestialWatchStrip(root.querySelector('canvas'), {phase: .625});
  function setPhase(phase, label) {
    watch.setPhase(phase);
    timeText.textContent = label || sampleLabel(watch.phase); timeText.title = timeText.textContent;
    slider.value = watch.phase;
    readout.textContent = `Phase ${watch.phase.toFixed(3)} · ` + Object.entries(watch.frameState().weights).filter(([, w]) => w > .001).map(([name, weight]) => `${name} ${Math.round(weight * 100)}%`).join(' + ');
  }
  function resize() {
    const scale = Math.min(innerWidth / 1920, innerHeight / 1080);
    document.documentElement.style.setProperty('--hud-scale', scale);
    const rect = root.querySelector('.wk-watch-aperture').getBoundingClientRect();
    watch.resize((devicePixelRatio || 1) * rect.width / watch.width);
  }
  compass.addEventListener('click', () => {
    // Fixture-only: the game adapter must call the actual north-lock command.
    const locked = compass.getAttribute('aria-pressed') !== 'true';
    compass.setAttribute('aria-pressed', String(locked));
    root.style.setProperty('--north-angle', locked ? '0deg' : '-35deg');
  });
  root.style.setProperty('--north-angle', '-35deg');
  slider.addEventListener('input', () => {play.checked = false; setPhase(Number(slider.value));});
  for (const button of document.querySelectorAll('[data-preset]')) button.addEventListener('click', () => {play.checked = false; setPhase(Number(button.dataset.preset), button.textContent);});
  document.querySelector('[data-compact]').addEventListener('change', e => {root.dataset.worldMapOpen = String(e.target.checked); resize();});
  let frame = 0, last = 0;
  function animate(now) {
    if (play.checked && last) setPhase(watch.phase + Math.min((now - last) / 1000, .1) / 45);
    last = now; frame = requestAnimationFrame(animate);
  }
  play.addEventListener('change', () => {last = 0;});
  addEventListener('resize', resize);
  window.watchDemo = {watch, root, setPhase, setCompact(on) {root.dataset.worldMapOpen = String(on); resize();}, stop() {play.checked = false; cancelAnimationFrame(frame);}};
  await watch.ready; await document.fonts.ready;
  await Promise.all([...root.querySelectorAll('img')].map(i => i.complete && i.naturalWidth ? Promise.resolve() : new Promise((resolve, reject) => {i.onload = resolve; i.onerror = () => reject(Error('Could not load preview image'));})));
  resize();
  const initial = params.has('phase') && Number.isFinite(Number(params.get('phase'))) ? Number(params.get('phase')) : .625;
  setPhase(initial, params.get('label'));
  frame = requestAnimationFrame(animate);
  window.watchReady = true;
})().catch(error => {window.watchError = error.message; console.error(error);});
