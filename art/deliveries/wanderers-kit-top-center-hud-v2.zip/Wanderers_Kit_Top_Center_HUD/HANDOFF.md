# Wanderer’s Kit — corrected top-center HUD, v2

This package replaces the previous top-center HUD ZIP. Keep the existing leather artwork and folded strap ends. The corrected enemy level surround is smaller and sits within the leather, clear of the strap, top stitching and lower brass border. The HP track has a defined native size and inset. A fixed center-notch piece and repeatable straight leather replace the previous repeating center panel.

## Coordinates and scale

All coordinates below are **native PNG pixels**, in the enemy frame’s local coordinate system. Multiply every position, size and font size by the same display scale. The enemy frame is 895×121. A display scale of 0.5 makes it 447.5×60.5 on screen. Use the game’s existing desktop HUD scaling convention; there is no implicit second 2× multiplier.

`layout.json` is authoritative. `asset_manifest.json` lists the actual exported file sizes and hashes. Do not use the earlier handoff’s approximate positions or original 279×45 track dimensions.

| Enemy element | Exact rectangle / center |
|---|---|
| Blank frame | `(0,0,895,121)` |
| Level surround | `(112,30,60,58)` |
| Level text | center `(142,59)`, Spectral SemiBold 28 |
| Level text safe box | `(123,43,38,32)` |
| Name | box `(202,27,588,29)`, center `(496,41.5)`, Spectral SemiBold 28 |
| HP back and rim | `(202,60,588,28)` |
| HP fill / mask | `(212,70,568,10)` |
| HP fill within track | `(10,10,568,10)`, corner radius 4 |

The final track is 588 pixels wide, slightly narrower than the initial 600-pixel review proposal, to retain clearance from the right-hand curved brass border after preserving rounded end-cap proportions. Its PNG already has the destination dimensions. The medallion PNG is already 60×58; do not render it at its old 80×78 size.

The level surround’s opaque visible bounds are `[116,33,167,83)` in the frame. The conservative stitching exclusion band ends at y=27, and the lower-border exclusion band begins at y=92: neither overlaps the badge. The actual stitching and brass outline have additional visible leather separation. Do not expand the medallion back toward those bands. Levels 1, 9, 10 and 99 were rendered and measured; 99 occupies 30×19 pixels inside the 38×32 safe text box. Center actual text using the renderer’s font metrics and account for the small shadow.

Text color is the existing warm cream (`#F0DFB7`) with a dark brown shadow (`#21130D`, offset 1,1). Use the Spectral fonts already supplied with Wanderer’s Kit. The corrected enemy previews use Spectral SemiBold; unchanged NPC/toast sample typography remains illustrative. All names, level numerals, HP values and fill percentages are runtime data, absent from the blank production skins. Do not infer a level cap of 99; it is a fit test.

## HP layers and runtime update

1. Draw `assets/enemy_frame_blank.png`.
2. Draw the separate level surround and live numeral.
3. Draw `assets/hp_track_back.png` at the exact HP rectangle.
4. Draw the full `hp_fill_amber.png` (or optional `hp_fill_red.png`) at the fill rectangle, revealing the left portion through a rectangular clip.
5. Draw `assets/hp_track_rim_overlay.png` at the same rectangle as the back.
6. Draw the enemy name within its measured box.

Compute `p = maxHP > 0 ? clamp(currentHP/maxHP,0,1) : 0`. Reveal width is `568*p` at native width. Keep the full texture’s destination size fixed while changing the clip; do not squeeze the fill texture to the percentage. At zero, skip the fill. At full health, reveal the whole interior. The exported fills already include the rounded alpha mask; the separate `hp_fill_clip_mask.png` is supplied for engines requiring an independent mask. Use one rounded-mask application, not two that darken its antialiased edge.

If widening the track, keep its 15-pixel left and right cap regions fixed and resize only the middle. At the native 588-pixel size these source regions are x=`[0,15)`, `[15,573)`, `[573,588)`. Apply the same construction to back and rim. The wider fill interior has its own width, with a fresh 4-pixel-radius clip; keep its full-width texture stable while animating health.

## Correct resizable top banners

For native sizes, use the unchanged full sprites: NPC 723×121, enemy 895×121. For wider layouts, use **five draw regions from four module sprites**:

| Region | Sprite | Native size | Position |
|---|---|---|---|
| Left folded cap and curved transition | `top_left_cap.png` | 160×121 | x=0 |
| Left straight span | `top_straight_repeat.png` | 32×121 per tile | x=160, repeated n times |
| One fixed center notch | `top_center_notch.png` | 64×121 | x=160+32n |
| Right straight span | same repeat sprite | 32×121 per tile | x=224+32n, repeated n times |
| Right curved transition and folded cap | `top_right_cap.png` | 160×121 | x=224+64n |

All module files are in `assets/modules/`. Width is `W=384+64n`. Choose the same integer n on both sides so the single notch remains centered. For a wider enemy, use n≥9 (960 pixels); wider NPC starts at n≥6 (768 pixels). To meet a measured required width, use `n=ceil((requiredWidth-384)/64)`, with the applicable minimum. Place complete 32-pixel repeats; no partial last tiles or stretched stitches. The repeat’s first and last columns match; cap/notch inner boundary columns were matched to that same column within an 8-pixel straight-leather transition. Buckles, folded ends, curves and the notch stay fixed.

At wider enemy width W:

```text
levelRect = (112,30,60,58)
nameRect = (202,27,W-307,29)
trackRect = (202,60,W-307,28)
fillRect = (212,70,W-327,10)
```

The level stays relative to the left folded cap; the name centers in its updated box. Measure long names and choose a wider quantized frame within the viewport. If that cannot fit, use the current UI’s compact scaling/ellipsis rules. Do not let name text run into the level badge or folded cap. The old `top_panel_center.png` must not be repeated: it contains a notch and both curved edges. It and the old rough top/toast slice files are deliberately omitted from this package.

## NPC and floating toast

NPC remains a two-line banner with no health or level; use text centers `(361.5,41)` and `(361.5,78.5)` at its native size. Toast remains the full 548×137 floating sprite with its crest protected; title center `(274,86)`. Do not stretch its star or improvise a three-slice resize from the retired rough cuts. Optional ornament/time icons are retained unchanged.

NPC/enemy root anchors are top-center. Their native images contain a 3-pixel transparent top margin: root y=-3 aligns the first visible artwork with viewport top. Apply this root translation to the entire banner group, including text, level and HP; keep all local coordinates above unchanged. Toast retains the game’s existing floating top offset. The finite folded ends stay visible; no faded or indefinitely extended strap texture is introduced.

Use sRGB color textures, linear sampling and normal RGBA blending. Convert straight alpha once if the engine requires premultiplied input. Atlas with padding/extrusion and clamp individual sprites. The backgrounds are decorative and should not capture pointer input across their full rectangle. Retain existing enemy targeting, NPC hover, toast timing and HP animation behavior.

## Verification

The corrected overview is assembled from the exact image selected in this thread. Only its enemy-banner rectangle was replaced; every pixel outside that rectangle is identical to the selected source. The runtime frame art, NPC and toast skins remain unchanged.

`previews/overview.png` shows the correction; `layout-and-resize-checks.png` shows native level 1, level 99/full HP, a widened long name and empty HP. These previews are assembled from the supplied PNGs and coordinates. `reference/validation.json` records the medallion exclusions, text fit, frame containment, matching repeat joins and 960/1088/1280-pixel resize checks. PNG decoding and ZIP integrity are checked before delivery. No game source was supplied, so in-game scaling, text metrics and behavior still need the coding agent’s integration check.
