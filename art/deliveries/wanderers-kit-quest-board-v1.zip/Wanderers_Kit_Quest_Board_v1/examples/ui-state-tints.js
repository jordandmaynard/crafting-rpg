// Reference math for normal UI button tints only. Item sprites remain untouched.
// rgb components and mask alpha are normalized0..1; alpha is unchanged.
export function buttonFaceReadyTint(rgb, maskAlpha, strength=0.70) {
  const weights=[0.2126,0.7152,0.0722];
  const tint=[0.77,0.91,0.36];
  const tintLum=tint.reduce((sum,c,i)=>sum+c*weights[i],0);
  const lum=rgb.reduce((sum,c,i)=>sum+c*weights[i],0);
  const w=Math.max(0,Math.min(1,maskAlpha))*strength;
  return rgb.map((c,i)=>Math.max(0,Math.min(1,c*(1-w)+lum*tint[i]/tintLum*w)));
}
export function buttonStateMultiply(rgb,state) {
  const factor={normal:1,hover:1.08,pressed:0.90,unavailable:0.72}[state]??1;
  return rgb.map(c=>Math.max(0,Math.min(1,c*factor)));
}
