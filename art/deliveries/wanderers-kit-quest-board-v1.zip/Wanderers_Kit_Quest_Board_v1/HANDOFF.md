# Wanderer’s Kit — Quest Board v1

Approved direction: option A. The quest board is a warm timber window with individual pinned parchment notices. Quest illustrations use the existing full-color 256px inventory item sprites. No new item icons are supplied, and no desaturation, posterization, sepia shader or parchment treatment is required for item art.

## Package and import

`assets/` contains 23 individual lossless RGBA PNGs: the complete board, four blank parchment orientations, primary/secondary/close buttons, three blank status tags, a brass pin, progress track/fill, a primary-face tint mask and small monochrome UI glyphs/backplates. UI glyphs are controls, not item art. The four papers are deterministic flips of one master; their grain and color therefore stay consistent. Never flip the notice’s text or item children.

`assets.json` is the authoritative sprite inventory, dimensions, logical sizes, slice borders and SHA-256 hashes. `layout.json` gives the reference assembly coordinates and styling. All coordinates use a top-left origin. Production art has no baked quest names, objectives, rewards or action labels. The wheat/hourglass/check emblems are intentionally baked into the status seals. The blank title plaque is part of the board.

Import as sRGB, straight/unassociated alpha. Use linear texture filtering and normal alpha blending. Disable automatic sprite trimming and importer padding changes, since those change the supplied bounds. Keep native PNGs lossless. If the engine premultiplies internally, convert once at import; do not premultiply twice. Transparent RGB is cleared and every runtime sprite has a transparent safety border. Do not key out parchment or dark wood by color.

## Assembly

Reference desktop viewport: **1920×1080**. Place the **1536×1024** board at **(192,28)**. At other sizes, scale the complete window uniformly by `min((viewportWidth-32)/1536, (viewportHeight-32)/1024, 1)`, then center it. All local coordinates, fonts and hit targets inherit the same scale. Do not stretch the roof or tile the planked center. The complete board is one continuous texture; it has no repeating leather/wood module or joined center patch.

Draw order:

1. Existing game world and a screen-wide dark scrim (about 55% black); modal blocks world clicks.
2. `frames/quest-board.png`.
3. Runtime header and close control.
4. Four papers at the origins below; the paper background is **608×384 logical pixels**.
5. Status tags, title/rule, existing item sprites, description, objective row, progress and reward text.
6. Action buttons and their labels/glyphs.
7. Brass pin at each paper’s top center, then normal hover/focus/pressed overlays.

| Notice | Board-local origin | Paper |
|---|---|---|
| Top left | 144,156 | `notice-a.png` |
| Top right | 784,156 | `notice-b.png` |
| Bottom left | 144,556 | `notice-c.png` |
| Bottom right | 784,556 | `notice-d.png` |

The papers clear the roof, uprights and lower rail. Keep this grid straight for text readability; rough edges and corner folds provide the handmade variation. No perspective taper or notice rotation is needed.

Header text uses board-local rectangle **(458,51,620,64)**. The close control is **(1356,53,56,56)**; overlay the white close glyph, tinted cream. The X is not baked into its button. Use the existing location name, e.g. “Emberbrook Quest Board”. Fit or shorten exceptionally long location names inside this plaque instead of extending text onto the roof fasteners.

## Per-notice layout

These rectangles are relative to a paper’s 608×384 canvas. Full machine-readable values are in `layout.json`.

| Element | x,y,width,height |
|---|---|
| Pin | 290,-5,28,28 |
| Status tag | 30,22,304,56 |
| Status label | 98,36,224,27 |
| Title | 176,88,402,40 |
| Solid title rule | 176,128,402,2 |
| Existing item icon | 26,136,140,136 |
| Description | 176,140,402,68 |
| Objective backplate | 176,216,402,34 |
| Objective checkbox | 182,222,22,22 |
| Objective text | 214,218,352,32 |
| Optional progress track | 176,254,360,18 |
| Rewards | 34,275,540,30 |
| Primary action | 90,316,280,54 |
| Secondary Re-roll | 394,316,152,54 |

Use the shipped Wanderer’s Kit UI serif, not the preview font. The preview uses DejaVu Serif only to demonstrate spacing. Body color is `#50301c`, primary button text `#f5e6bd`. Defaults: title 28px bold (fit to 21px), body 21px with 27px line spacing, status 17px bold, objective 20px bold, rewards 21px, primary action 22px and secondary action 20px. Keep status labels and actions in consistent positions across all papers.

Measure text using the actual game font. Keep the description to two lines. If a title still exceeds its box at 21px, use an 18px, two-line fallback inside the same 40px box (20px line height), or truncate with a tooltip exposing the full title. Do not let the title cross the rule, description or paper edge. Oversized objective/reward text should be shortened or receive a tooltip; it must not push the buttons off the paper. The supplied sample layout shows one objective row per notice; longer/multiple-objective designs need a deliberate alternate layout rather than spilling into the reward/action area.

## Item art and rewards

Resolve an item icon through the same registry/texture reference used by inventory. Draw the entire existing sprite with contain fitting inside the icon rectangle, preserving aspect and full color. Do not paint a paper rectangle, frame or drop shadow behind it. Do not trim away part of a weapon or hide. The same item must look the same here and in inventory.

The wolf sample uses `raw-hide-painterly-256x256.png`; the supply sample uses `sourdough-round-loaf-painterly-256x256.png`; the wood sample uses `wood-logs-painterly-256x256.png`. Names in the example data are asset references to map to your existing item IDs, not new gameplay identifiers. If an illustration is unavailable, leave its slot empty for now; do not synthesize a substitute or generate a new icon.

The combat preview uses two instances of the existing `sword-iron-painterly-256x256.png`, with one mirrored horizontally. This is optional UI composition of the same sprite, not a new item texture. A single existing sword is also valid. Item icons appear only inside the preview/reference images in this package; they are not duplicated under `assets/`.

The production assembly uses runtime text such as “Reward: 80 gold · 120 XP”. Reuse shipped currency/XP glyphs if those already exist; no new currency/item sprites are required. The approved mockup’s small reward pictures are not baked into the paper or runtime controls.

## Buttons, tints and slices

Use the one brown primary texture for both Accept Quest and Turn In Quest. A disabled In Progress label uses this same texture. Re-roll uses the quieter parchment secondary texture and `glyph-reroll.png` tinted dark brown. Small white glyph PNGs are alpha masks; tint their RGB at draw time. The checkbox outline and completed tick are separate layers.

Most component textures are supplied at 2× their logical height. For nine-slice controls, source border widths below are **source pixels**, not screen pixels. Set the sprite density to 2 source pixels per logical pixel, or divide the borders by two after scaling the texture to logical height. Do not stretch the corners or rivets.

| Texture | Source size | Left / top / right / bottom borders |
|---|---|---|
| Primary button + its face mask | 560×120 | 66 / 24 / 66 / 24 |
| Secondary button | 304×120 | 40 / 24 / 40 / 24 |
| Progress track | 720×40 | 22 / 12 / 22 / 12 |
| Objective backplate | 32×32 | 10 / 10 / 10 / 10 |

The objective backplate is a geometric tint mask, not a density-dependent textured control. Stretch its small center and retain a modest 5px logical corner. Tint it `#9d7538` at 10% opacity. The title rule is a continuous thin line; it is not a dashed divider.

Status tags use **horizontal three-slice only**. Their source size is 384×112, fixed left section 126px and fixed right section 24px. First scale the whole height to 56 logical pixels (0.5×), preserving the seal’s shape; then stretch only the middle ribbon to the desired width, normally 304px. Left becomes 63px and right 12px. Never stretch the wax seal or emblem with the ribbon. Runtime text starts after the seal, with clear padding at the right end. Longer localized labels can widen the ribbon within the paper’s available space or reduce label font size.

No separate hover, selected or disabled texture variants are included. Recommended normal-state reuse:

| State | Treatment |
|---|---|
| Hover / keyboard focus | RGB ×1.08, alpha unchanged; optional simple focus outline |
| Pressed | RGB ×0.90 and move button, label and glyph together down 1px |
| Unavailable / pending | RGB ×0.72, label opacity 0.65, input disabled |
| Ready primary | Optional olive face tint using the supplied face mask; brass and rivets remain untouched |

`button-primary-face-mask.png` covers the complete inset face and has holes around both rivets. Slice it exactly like the primary button. The preview’s ready tint preserves original face luminance/grain and blends toward olive at strength 0.70. `examples/ui-state-tints.js` gives the exact CPU reference. This is ordinary UI tint behavior, not processing of inventory icons. A normal brown Turn In button is acceptable if the UI renderer cannot apply a face mask; the green status and label still communicate readiness. There is no changed button geometry requiring separate pressed art.

## Objective progress

Draw the full empty track first. The fill sprite has source content rectangle **(4,4,24,24)** within its 32×32 canvas. Use those UVs, stretch to the full inner trough, then clip to `clamp(current/target,0,1)`. In the sample, a 360×18 track at (176,254) contains a 350×10 fill at (181,258). Round/clip the fill end as appropriate; do not scale the track or its caps by the completion ratio. Hide the progress bar for objectives that do not need one. Draw the checkbox tick only when complete.

## Interaction and data integration

Keep existing quest rules authoritative. This package supplies presentation and sample bindings, not a new quest economy, reward system or server implementation.

| Quest state | Primary control | Secondary control |
|---|---|---|
| Available | Accept Quest | Re-roll |
| Active, incomplete | Disabled In Progress | Hidden |
| Complete and claimable | Turn In Quest | Hidden |

Re-roll replaces the unaccepted offer in its slot. Keep the player on the same page. Do not silently reroll an accepted quest using this offer control. If existing gameplay has costs, limits or a different accepted-quest reroll rule, expose the real values/rule in the interaction layer; no new prices or timers are invented here. Accept, claim and reroll must use the game’s existing commands and authoritative results. Disable repeated input while a command is pending; update state only after success. On failure, restore the old offer/state and show the game’s ordinary error message.

Update objective counts from live quest data. On acceptance, show Active or Ready as appropriate. On successful turn-in, apply the game’s completed/removed/replaced-offer behavior. Closing/reopening the board must preserve accepted quest state. Use quest IDs, not array position or notice background, for action bindings. The displayed notices can remain stable when a neighboring quest updates.

The default board displays four offers/quests. For fewer entries, omit unused papers; do not duplicate a quest to fill the grid. For more than four, paginate with the supplied chevrons over the existing close-button background at 44×44. An optional header pagination group fits at board-local **(124,59,272,44)**: previous at x124, page label centered at x260, next at x352; it stays left of the title plaque. Hide the group for one page. Use the same hover/disabled tints for paging. Do not shrink all cards until their text is illegible or scroll papers through the wooden roof/rail.

ESC and the close button dismiss the modal. Tab focus follows visible enabled actions in reading order; Enter/Space activate the focused action. World movement/clicks remain blocked while open. Keep a text label alongside each status so color is not the only cue. Desktop is the initial target; no touch-specific controls are introduced.

## Reference and verification

`previews/assembly-1920x1080.png` is a real composition from the exported runtime pieces, with preview-only existing inventory icons. `assembly-transparent.png` is the same assembled window without the town backdrop. `asset-contact-sheet.png` shows every blank production element on a checker. `reference/approved-option-A.png` preserves the approved mockup for comparison. Generated masters were cut independently; there is no sprite sheet containing adjacent glyphs that could bleed into one another.

Checks in `validation.json` cover all 23 runtime PNG dimensions, RGBA mode, transparent border and cleared transparent RGB. The assembled preview was visually reviewed for complete rail/roof/corner/rivet silhouettes, pin placement, button face masking and content containment. The final ZIP also receives a decode/CRC check. In-engine font metrics, DPI, native input focus and authoritative quest command integration still require the implementation agent’s application checks.
