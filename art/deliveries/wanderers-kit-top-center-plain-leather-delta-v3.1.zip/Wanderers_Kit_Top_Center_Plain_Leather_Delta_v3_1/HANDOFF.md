# Wanderer’s Kit — plain leather delta v3.1

Replace the six PNGs below in the current v3 top-center HUD set. This removes the embossed repeating leather row and the central patch visible in the enemy and townsperson banners. The defect was baked into the v3 source images, including the complete frames; no game renderer correction is needed.

| Replacement path | Dimensions |
|---|---:|
| `assets/enemy_frame_blank.png` | 1088×144 |
| `assets/npc_frame_blank.png` | 896×144 |
| `assets/modules/top_left_cap.png` | 192×144 |
| `assets/modules/top_straight_repeat.png` | 32×144 |
| `assets/modules/top_center_notch.png` | 64×144 |
| `assets/modules/top_right_cap.png` | 192×144 |

Overlay these files on the existing v3 asset directory. Replace both complete frames even when the current names are short enough to use them without slicing. Replace all four module files together so widened banners use the same plain interior. Refresh generated texture atlases/caches if the project uses them; preserve the existing import scale and alpha settings.

All source dimensions, alpha masks, anchors, layout coordinates and source rectangles are unchanged. Keep the existing v3 `layout.json` and all current UI code. The HP, level surround, text positions, toast and crests continue to use their current files and placements.

Only the broad interior leather is repainted. The new plain material has subtle fine grain with no recognizable motif. Its body target is the existing panel’s median sRGB `(65,35,19)`; the fine grain varies by at most two channel values. This keeps the warm dark brown while preventing a visible ornamental repeat at game scale.

The brass outlines, stitching, rivets, folded straps and silhouette pixels outside the interior paint masks are unchanged. The alpha channel is identical pixel-for-pixel in every replacement. Both complete frames were reconstructed from the replacement modules and match that assembly exactly. Module boundary columns still match, including the fixed cap/notch joints.

`previews/before-after.png` compares the old source frames to the replacements. `previews/plain-leather-preview.png` assembles the actual replacement files with Hellhound / Walter Randulfson sample text and existing HP/level layers at native and game scale. Text is not baked into the replacement PNGs. `reference/validation.json` records the dimension, alpha, protected-pixel and seam checks; `manifest.json` supplies hashes.

The replacement material was made with the built-in image generation tool, then color-matched and reduced in contrast before an interior-only composite. The final prompt is in `reference/material-prompt.txt`. The game implementation was not available for integration testing; the supplied game-scale preview is an asset assembly check.
