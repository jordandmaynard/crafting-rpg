# Wooden weapon equipment icons — 256×256

New wood bow and wood spear, painted to match the existing wood sword. The preview includes the approved sword as a comparison; the ZIP includes just the two new individual weapon PNGs and preview.

Each standalone icon is RGBA at exactly 256×256 with transparent background and alpha values only 0 and 255. Preserve alpha and square aspect ratio. Use linear or mipmapped filtering at non-integer game sizes. No text, UI frame, cast shadow, black stroke, or mandatory 1:2 isometric angle is baked in.

The bow is strung with no arrow; the spear has a carved wooden point and wrapped neck, no metal head. Wood sword remains in the existing starter equipment pack. The artwork was created with built-in image generation using the sword for material/style and the 48px weapons for shape, then exported with Lanczos resizing and binary-alpha thresholding.
