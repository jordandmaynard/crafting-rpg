# Wanderer’s Kit — mode icons + settings

Replace the three current mode icon images with these backpack, wooden mallet and parchment map designs, restored from the supplied reference. Use the new matching ochre gear for settings. This update supplies exactly four normal icon textures; no frames, button backgrounds, key badges or state textures are included.

| Control | PNG |
|---|---|
| Inventory | `assets/mode-inventory-backpack.png` |
| Build | `assets/mode-build-hammer.png` |
| World map | `assets/mode-world-map-scroll.png` |
| Settings | `assets/settings-gear.png` |

All four files are 256 × 256 RGBA PNGs with transparent surroundings and smooth edges. Transparent holes in the backpack loop and the center of the gear are intentional. This is UI art, so preserve smooth alpha rather than applying the binary-alpha rule used by some item assets.

## Apply the change

1. Replace only the icon-image layer/source in each existing control. Preserve the current frame, background, button size, position, order, hit area, selected-mode state, click handler and keyboard bindings. Do not import anything from the reference screenshot behind the icons.
2. Draw each full 256px canvas in a square image area with aspect ratio preserved. Start with the existing icon image area; 48 × 48 logical pixels is a useful visual reference if the current layout needs an explicit value. The artwork has intentional padding and optical size balancing. Center the canvas in the current button interior; do not trim it again, stretch it, or enlarge the button to fit it. The gear is slightly smaller to balance its denser silhouette.
3. Remove the separate visible labels/captions below the current icons and their reserved caption space. Keep the button frames and backgrounds at their existing dimensions and positions. Do not add the reference’s B/N/M badges or bake key hints into these images. Preserve the current key bindings and expose names/current shortcuts in the existing tooltips and accessible names.
4. Keep normal icon color neutral/white in the renderer so the exported warm colors are visible. Continue to show hover, selected, unavailable and pressed state through existing runtime tints and the existing button state system. Reuse these same PNGs in every state; add no new painted state texture or mechanical movement. Preserve existing input validation and disabled behavior.
5. Keep icon images decorative for hit testing so the parent controls receive pointer input. Retain accessible control names: Inventory, Build, World map, Settings. Tooltip/focus behavior should remain available after removing visible captions.

## Check

Check all four at the actual desktop UI scale, especially around 40–48px. The backpack fastener, mallet silhouette, parchment curls and gear opening should stay readable. Confirm no rectangle from the screenshot is visible around an icon; backgrounds and frames must show through the transparent exterior and gear hole. Confirm labels are removed, each existing shortcut still works, and clicking an icon triggers its original action.

The preview is composed from the exact production PNGs; its text is documentation only and is not part of any asset. Dimensions, alpha range, transparent gear opening and export padding were checked. No game repository was supplied, so this is an asset handoff rather than an applied game-code change. Art was produced with the built-in image-generation tool; exact prompts are recorded in `generation-prompts.json` and file hashes in `asset-manifest.json`.
