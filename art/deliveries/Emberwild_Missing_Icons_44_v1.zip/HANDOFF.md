# Emberwild missing buildable and armor icons

44 runtime icons, each **256×256 RGBA lossless PNG**, named exactly after the icon IDs in the supplied game v642 reference pack. Alpha is binary: every pixel is either 0 or 255. The buildables are the approved painted versions; the armor uses the approved cloth equipment's rounded, painterly treatment rather than literal faceted model geometry.

## Runtime files

- `buildables/`: 12 icons, 1:2 isometric view, with a baked **one-pixel black exterior contour** at the final 256px resolution. Do not add another outline.
- `armor/`: 32 icons, four separate inventory pieces for each of eight sets. **No outline was added.** Apply the game's existing programmatic armor border at runtime.
- `assets.json`: exact IDs, relative paths, content hashes and export metadata.
- `previews/`: review sheets only; do not import as item textures.
- `validation.json`: export checks for all 44 runtime PNGs.
- `source/prompts.json`: painting prompts and reference roles. Art was created with the built-in image generator; resizing, binary-alpha conversion and buildable contour generation were performed afterward.

## Buildable mapping

| Icon ID / PNG stem | Item |
|---|---|
| woodstairs | Wood Stairs |
| stonestairs | Stone Stairs |
| woodwindow | Timber Window |
| stonewindow | Stone Window, arched |
| fence | Wood Fence |
| stonefence | Fieldstone Wall |
| ironfence | Iron Fence |
| gate | Wooden Gate |
| irondoor | Iron Door |
| irongate | Iron Gate |
| crate | Wooden Crate |
| chest | Iron Chest |

Each file is `buildables/<iconID>.png`. Preserve transparent spaces between railings and around the staircase. The crate intentionally has a closed planked top and an open front matching its model. No floor or cast shadow is baked in.

## Armor mapping

| Set | Torso | Legs | Boots | Helmet |
|---|---|---|---|---|
| Leather | leatherArmor | leatherPants | leatherBoots | leatherHelmet |
| Bone | boneArmor | bonePants | boneBoots | boneHelmet |
| Copper chain | chainArmor | chainPants | chainBoots | chainHelmet |
| Iron plate | plateArmor | platePants | plateBoots | plateHelmet |
| Verdane | verdaneArmor | verdanePants | verdaneBoots | verdaneHelmet |
| Caerite | caeriteArmor | caeritePants | caeriteBoots | caeriteHelmet |
| Orivane | orivaneArmor | orivanePants | orivaneBoots | orivaneHelmet |
| Auralith | auralithArmor | auralithPants | auralithBoots | auralithHelmet |

Each file is `armor/<iconID>.png`. IDs are case-sensitive. Every boots icon shows a pair. Helmets and clothing are empty items, with no wearer. Waist belts belong to the pants. The illustrations reinterpret the reference models as rounded equipment; they do not change in-world armor meshes.

Material identities are chestnut leather, ivory bone, reddish copper mail, cool iron, green Verdane, blue Caerite, purple Orivane and rainbow-iridescent Auralith.

## Import and rendering

Use the full 256px square canvas with aspect-fit scaling; do not stretch, trim, or separately normalize each component. The art is uniformly fitted within a 240px square before the buildable contour is added, leaving safe transparent margins. Use normal white tint to preserve the painted colors.

Keep alpha rather than color-keying black. Avoid lossy texture compression. At smaller display sizes, use the game's established item-icon sampling; if strict binary edges are required after GPU scaling, apply the existing alpha-test policy. Armor outlines belong in the existing runtime pass. The buildable contour is already present, so bypass that pass for this category.

Only the 44 PNGs in `buildables/` and `armor/` are runtime assets. Preview backgrounds and labels are not part of any icon.
