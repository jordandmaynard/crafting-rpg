(function () {
  const params = new URLSearchParams(location.search);
  const initial = WandererCraftingView.skins.includes(params.get('station')) ? params.get('station') : 'weapon';
  if (params.get('proof') === '1') document.body.classList.add('proof');
  const inventory = {...CRAFTING_INITIAL_INVENTORY};
  const outputs = {}; const requests = [];
  const clone = value => JSON.parse(JSON.stringify(value));
  const view = new WandererCraftingView({
    station: initial, recipes: clone(CRAFTING_FIXTURES[initial]),
    getOwned: id => inventory[id] || 0,
    onCraft: async request => {
      requests.push({...request});
      // The real game adapter must validate and transact authoritatively.
      await new Promise(resolve => setTimeout(resolve, 200));
      const recipe = CRAFTING_FIXTURES[request.stationId].find(r => r.id === request.recipeId);
      if (!recipe || request.count !== 1 || recipe.costs.some(c => (inventory[c.id] || 0) < c.amount)) return {ok: false, message: 'Materials changed. Try again.'};
      for (const cost of recipe.costs) inventory[cost.id] -= cost.amount;
      outputs[request.recipeId] = (outputs[request.recipeId] || 0) + 1;
      return {ok: true};
    }
  });
  const buttons = [...document.querySelectorAll('button[data-station]')];
  function station(id) {
    view.setStation(id, clone(CRAFTING_FIXTURES[id]));
    for (const button of buttons) button.setAttribute('aria-pressed', String(button.dataset.station === id));
  }
  for (const button of buttons) button.addEventListener('click', () => {if (!view.pending) {station(button.dataset.station); view.open();}});
  station(initial);
  document.querySelector('[data-reset]').addEventListener('click', () => {
    if (view.pending) return;
    Object.assign(inventory, CRAFTING_INITIAL_INVENTORY);
    for (const id of Object.keys(outputs)) delete outputs[id];
    requests.length = 0; view.refresh(); view.open();
  });
  window.craftingView = view;
  window.craftingDemo = {inventory, outputs, requests, station, reset() {
    Object.assign(inventory, CRAFTING_INITIAL_INVENTORY);
    for (const id of Object.keys(outputs)) delete outputs[id];
    requests.length = 0; view.refresh(); view.open();
  }};
  window.craftingReady = true;
})();
