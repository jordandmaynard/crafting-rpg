(function (global) {
  const icon = name => './demo/icons/' + name + '.png';
  const cost = (id, name, amount, image) => ({id, name, amount, icon: icon(image)});
  const recipe = (id, name, image, costs) => ({id, name, icon: icon(image), costs});
  // All recipes and counts here are illustrative fixtures, not game balance data.
  global.CRAFTING_FIXTURES = {
    weapon: [
      recipe('wooden-sword', 'Wooden Sword', 'sword', [cost('planks', 'Planks', 10, 'planks')]),
      recipe('wooden-bow', 'Wooden Bow', 'bow', [cost('planks', 'Planks', 8, 'planks'), cost('thread', 'Thread', 2, 'thread')]),
      recipe('wooden-spear', 'Wooden Spear', 'spear', [cost('planks', 'Planks', 6, 'planks'), cost('leather', 'Leather', 2, 'leather')])
    ],
    armor: [
      recipe('leather-tunic', 'Leather Tunic', 'tunic', [cost('leather', 'Leather', 8, 'leather'), cost('thread', 'Thread', 4, 'thread')]),
      recipe('leather-pants', 'Leather Pants', 'pants', [cost('leather', 'Leather', 6, 'leather'), cost('thread', 'Thread', 3, 'thread')]),
      recipe('leather-boots', 'Leather Boots', 'boots', [cost('leather', 'Leather', 4, 'leather'), cost('thread', 'Thread', 2, 'thread')])
    ],
    alchemy: [
      recipe('healing-draught', 'Healing Draught', 'healing', [cost('herb', 'Healing Herb', 3, 'herb'), cost('bottle', 'Glass Bottle', 1, 'bottle'), cost('bone-dust', 'Bone Dust', 2, 'bone-dust'), cost('water', 'Clean Water', 1, 'bottle')]),
      recipe('stamina-tonic', 'Stamina Tonic', 'stamina', [cost('herb', 'Herbs', 4, 'herb'), cost('bottle', 'Glass Bottle', 1, 'bottle'), cost('water', 'Clean Water', 1, 'bottle')]),
      recipe('antidote', 'Antidote', 'antidote', [cost('herb', 'Herbs', 2, 'herb'), cost('bottle', 'Glass Bottle', 1, 'bottle'), cost('bone-dust', 'Bone Dust', 1, 'bone-dust')])
    ]
  };
  global.CRAFTING_INITIAL_INVENTORY = {planks: 16, leather: 12, thread: 6, herb: 9, bottle: 4, 'bone-dust': 6, water: 2};
})(window);
