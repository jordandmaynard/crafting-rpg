(function (global) {
  'use strict';
  const SKINS = ['weapon', 'armor', 'alchemy'];
  const TITLES = {weapon: 'Weapon Crafting', armor: 'Armor Crafting', alchemy: 'Alchemy Crafting'};
  let serial = 0;
  const element = (tag, className, text) => {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  };
  const icon = (src, className) => {
    const image = element('img', className); image.alt = ''; image.draggable = false;
    if (src) image.src = src; else image.hidden = true;
    return image;
  };

  class WandererCraftingView {
    constructor(options = {}) {
      this.options = options;
      const base = options.assetBase || './ui/crafting/';
      this.assetBase = new URL(base.endsWith('/') ? base : base + '/', document.baseURI).href;
      this.pending = false; this.destroyed = false; this.requestSerial = 0;
      this.events = new AbortController();
      this._build(); this._bind(); this.resize();
      this.setStation(options.station || 'weapon', options.recipes || []);
    }

    _build() {
      const titleId = 'craft-title-' + (++serial);
      this.element = element('section', 'cw-root');
      this.element.setAttribute('role', 'dialog');
      this.element.setAttribute('aria-modal', 'false');
      this.element.setAttribute('aria-labelledby', titleId);
      this.panel = element('div', 'cw-window');
      this.frame = icon('', 'cw-frame'); this.frame.hidden = false;
      this.title = element('h1', 'cw-title'); this.title.id = titleId;
      this.closeButton = element('button', 'cw-close', '×');
      this.closeButton.type = 'button'; this.closeButton.setAttribute('aria-label', 'Close crafting');
      this.recipeHeading = element('h2', 'cw-recipe-heading', 'Recipes');
      this.ruleLeft = icon(this.assetBase + 'divider-h.png', 'cw-rule-left');
      this.divider = icon(this.assetBase + 'divider-v.png', 'cw-divider');
      this.recipeList = element('div', 'cw-recipes');
      this.recipeList.setAttribute('role', 'group'); this.recipeList.setAttribute('aria-label', 'Recipes');
      this.detailTitle = element('h2', 'cw-item-title');
      this.ruleRight = icon(this.assetBase + 'divider-h.png', 'cw-rule-right');
      this.preview = element('div', 'cw-preview');
      this.previewFrame = icon(this.assetBase + 'frame-preview.png', 'cw-preview-frame');
      this.previewIcon = icon('', 'cw-preview-icon');
      this.preview.append(this.previewFrame, this.previewIcon);
      this.materialHeading = element('h2', 'cw-material-heading', 'Materials');
      this.ruleMaterials = icon(this.assetBase + 'divider-h.png', 'cw-rule-materials');
      this.materialPanel = element('div', 'cw-material-panel');
      this.materialCaption = element('div', 'cw-material-caption', 'Owned / Needed');
      this.materialList = element('div', 'cw-materials');
      this.materialList.setAttribute('role', 'list'); this.materialList.setAttribute('aria-label', 'Required materials');
      this.materialList.tabIndex = 0;
      this.materialPanel.append(this.materialCaption, this.materialList);
      this.craftButton = element('button', 'cw-craft', 'Craft'); this.craftButton.type = 'button';
      this.footerRule = icon(this.assetBase + 'divider-h.png', 'cw-footer-rule');
      this.status = element('p', 'cw-status', 'Select a recipe to craft.');
      this.status.setAttribute('role', 'status'); this.status.setAttribute('aria-live', 'polite');
      this.panel.append(this.frame, this.title, this.closeButton, this.ruleLeft, this.recipeHeading,
        this.divider, this.recipeList, this.detailTitle, this.ruleRight, this.preview,
        this.ruleMaterials, this.materialHeading, this.materialPanel, this.craftButton,
        this.footerRule, this.status);
      this.element.append(this.panel);
      (this.options.parent || document.body).append(this.element);
      this._setAssetVariables();
    }

    _setAssetVariables() {
      const files = {
        'row': 'row-recipe', 'row-hover': 'row-recipe-hover', 'row-pressed': 'row-recipe-pressed',
        'row-selected': 'row-recipe-selected', 'row-selected-hover': 'row-recipe-selected-hover',
        'row-selected-pressed': 'row-recipe-selected-pressed', 'row-focus': 'row-recipe-focus', 'row-poor': 'row-recipe-poor',
        'craft': 'btn-craft', 'craft-hover': 'btn-craft-hover', 'craft-pressed': 'btn-craft-pressed',
        'craft-focus': 'btn-craft-focus', 'craft-disabled': 'btn-craft-disabled', 'craft-busy': 'btn-craft-busy',
        'close': 'btn-close', 'close-hover': 'btn-close-hover', 'close-pressed': 'btn-close-pressed',
        'close-focus': 'btn-close-focus', 'materials': 'panel-materials'
      };
      for (const [name, file] of Object.entries(files)) {
        this.element.style.setProperty('--cw-' + name, `url("${this.assetBase + file}.png")`);
      }
    }

    _bind() {
      const signal = this.events.signal;
      this.closeButton.addEventListener('click', () => this.close(), {signal});
      this.craftButton.addEventListener('click', () => this.craft(), {signal});
      this.craftButton.addEventListener('keydown', e => {
        if (e.repeat && ['Enter', ' '].includes(e.key)) e.preventDefault();
      }, {signal});
      this.element.addEventListener('keydown', e => {
        if (e.key === 'Escape') {e.preventDefault(); this.close();}
      }, {signal});
      this.recipeList.addEventListener('click', e => {
        const button = e.target.closest('button[data-recipe-id]');
        if (button && this.recipeList.contains(button)) this.selectRecipe(button.dataset.recipeId);
      }, {signal});
      this.recipeList.addEventListener('keydown', e => {
        if (!['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(e.key) || this.pending) return;
        const buttons = [...this.recipeList.querySelectorAll('button')];
        if (!buttons.length) return;
        const current = Math.max(0, buttons.indexOf(document.activeElement));
        const index = e.key === 'Home' ? 0 : e.key === 'End' ? buttons.length - 1 :
          Math.max(0, Math.min(buttons.length - 1, current + (e.key === 'ArrowDown' ? 1 : -1)));
        e.preventDefault(); buttons[index].focus({preventScroll: true}); buttons[index].click();
        buttons[index].scrollIntoView({block: 'nearest'});
      }, {signal});
      window.addEventListener('resize', () => this.resize(), {signal});
    }

    resize() {
      this.scale = Math.min(innerWidth / 1920, innerHeight / 1080);
      this.element.style.setProperty('--cw-scale', this.scale);
    }

    setStation(station, recipes = this.recipes || []) {
      if (this.pending) throw new Error('Wait for the current craft request before changing station.');
      const id = typeof station === 'string' ? station : station.id;
      if (!SKINS.includes(id)) throw new Error('Unknown crafting skin: ' + id);
      this.station = {id, title: typeof station === 'string' ? TITLES[id] : station.title || TITLES[id]};
      this.frame.src = this.assetBase + 'frame-' + id + '.png'; this.frame.hidden = false;
      this.title.textContent = this.station.title; this.element.dataset.station = id;
      this.setRecipes(recipes);
    }

    setRecipes(recipes) {
      if (this.pending) throw new Error('Wait for the current craft request before replacing recipes.');
      const seen = new Set();
      this.recipes = recipes.map(recipe => {
        if (!recipe.id || seen.has(recipe.id)) throw new Error('Recipe IDs must be nonempty and unique.');
        seen.add(recipe.id);
        const costs = new Map();
        for (const cost of recipe.costs || []) {
          if (!cost.id || !Number.isSafeInteger(cost.amount) || cost.amount < 1) throw new Error('Invalid recipe material.');
          const existing = costs.get(cost.id);
          const amount = (existing ? existing.amount : 0) + cost.amount;
          if (!Number.isSafeInteger(amount)) throw new Error('Material requirement exceeds supported count.');
          costs.set(cost.id, {...cost, amount});
        }
        return {...recipe, costs: [...costs.values()]};
      });
      this.recipeList.replaceChildren(); this.recipeButtons = new Map();
      for (const recipe of this.recipes) {
        const button = element('button', 'cw-recipe'); button.type = 'button'; button.dataset.recipeId = recipe.id;
        button.append(icon(recipe.icon, 'cw-recipe-icon'), element('span', 'cw-recipe-name', recipe.name));
        this.recipeList.append(button); this.recipeButtons.set(recipe.id, button);
      }
      if (!this.recipes.length) this.recipeList.append(element('p', 'cw-empty', 'No recipes available.'));
      this.selectedId = this.recipes.some(r => r.id === this.selectedId) ? this.selectedId : this.recipes[0]?.id;
      this._renderDetails(); this.refresh();
    }

    get selectedRecipe() {return this.recipes.find(r => r.id === this.selectedId) || null;}
    selectRecipe(id) {
      if (this.pending || !this.recipes.some(r => r.id === id)) return;
      this.selectedId = id; this._renderDetails(); this.refresh();
    }

    _owned(id) {
      const value = this.options.getOwned ? this.options.getOwned(id) : 0;
      return Number.isFinite(value) && value >= 0 ? Math.floor(value) : 0;
    }

    _reason(recipe) {
      if (!recipe) return 'Select a recipe to craft.';
      if (recipe.disabledReason) return recipe.disabledReason;
      const external = this.options.getBlockReason?.(recipe, this.station);
      if (external) return String(external);
      if (recipe.costs.some(c => this._owned(c.id) < c.amount)) return 'Insufficient materials.';
      if (!this.options.onCraft) return 'Crafting is not connected.';
      return '';
    }

    _renderDetails() {
      const recipe = this.selectedRecipe;
      this.detailTitle.textContent = recipe ? recipe.name : 'Choose a recipe';
      this.detailTitle.title = recipe ? recipe.name : 'Choose a recipe';
      this.previewIcon.hidden = !recipe?.icon;
      if (recipe?.icon) this.previewIcon.src = recipe.icon; else this.previewIcon.removeAttribute('src');
      this.materialList.replaceChildren(); this.materialRows = [];
      for (const cost of recipe?.costs || []) {
        const row = element('div', 'cw-material'); row.setAttribute('role', 'listitem');
        const name = element('span', 'cw-material-name', cost.name || cost.id); name.title = cost.name || cost.id;
        const count = element('span', 'cw-material-count');
        row.append(icon(cost.icon, 'cw-material-icon'), name, count);
        this.materialList.append(row); this.materialRows.push({cost, row, count});
      }
      if (recipe && !recipe.costs.length) this.materialList.append(element('p', 'cw-no-cost', 'No materials required.'));
      this.materialList.scrollTop = 0;
    }

    refresh({message} = {}) {
      if (this.destroyed) return;
      for (const recipe of this.recipes) {
        const button = this.recipeButtons.get(recipe.id);
        button.setAttribute('aria-pressed', String(recipe.id === this.selectedId));
        button.dataset.poor = String(recipe.costs.some(c => this._owned(c.id) < c.amount));
        button.disabled = this.pending;
      }
      for (const {cost, row, count} of this.materialRows || []) {
        const owned = this._owned(cost.id); const missing = owned < cost.amount;
        count.textContent = `${owned} / ${cost.amount}`;
        row.dataset.missing = String(missing);
        row.setAttribute('aria-label', `${cost.name || cost.id}: ${owned} owned, ${cost.amount} needed${missing ? ', insufficient' : ''}`);
      }
      const reason = this._reason(this.selectedRecipe);
      this.craftButton.disabled = this.pending || !!reason;
      this.craftButton.dataset.busy = String(this.pending);
      this.craftButton.setAttribute('aria-busy', String(this.pending));
      this.craftButton.textContent = this.pending ? 'Crafting…' : 'Craft';
      this.craftButton.title = reason || 'Craft one item';
      this.status.textContent = message !== undefined ? message : this.pending ? 'Crafting…' : reason || 'Select a recipe to craft.';
      this.status.dataset.problem = String(!!reason && !this.pending && !message);
    }

    async craft() {
      if (this.destroyed || this.element.hidden || this.pending) return false;
      const recipe = this.selectedRecipe;
      const reason = this._reason(recipe); // Recheck at activation; game must also validate atomically.
      if (reason) {this.refresh({message: reason}); return false;}
      const request = Object.freeze({stationId: this.station.id, recipeId: recipe.id, count: 1});
      const token = ++this.requestSerial;
      this.pending = true; this.refresh();
      let message;
      try {
        const result = await this.options.onCraft(request);
        if (this.destroyed || token !== this.requestSerial) return false;
        if (result === false || result?.ok === false) {
          message = result?.message || 'Could not craft this item.';
          return false;
        }
        message = result?.message || `Crafted ${recipe.name}.`;
        this.element.dispatchEvent(new CustomEvent('crafting:crafted', {detail: request}));
        return true;
      } catch (error) {
        message = 'Craft failed. Try again.';
        this.options.onError?.(error);
        return false;
      } finally {
        if (!this.destroyed && token === this.requestSerial) {
          this.pending = false; this.refresh({message});
        }
      }
    }

    open({focus = false} = {}) {
      this.element.hidden = false; this.refresh();
      if (focus) {
        if (!this.element.contains(document.activeElement)) this.previousFocus = document.activeElement;
        this.closeButton.focus({preventScroll: true});
      }
    }
    close() {
      if (this.destroyed || this.element.hidden) return;
      this.element.hidden = true;
      this.options.onClose?.(); this.element.dispatchEvent(new CustomEvent('crafting:close'));
      if (this.previousFocus?.isConnected) this.previousFocus.focus({preventScroll: true});
    }
    destroy() {
      this.destroyed = true; this.requestSerial++; this.events.abort(); this.element.remove();
    }
  }
  WandererCraftingView.skins = SKINS.slice();
  global.WandererCraftingView = WandererCraftingView;
})(window);
