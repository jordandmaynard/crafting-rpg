# Kinghaven merchant brig

Replacement game code for Emberwild. A broad wooden hull with a forest-green upper band, dark structural ribs, cream sails, restrained gilt crests, red pennant, stern lanterns and under-deck windows. The proportions and palette are based on Jordan's two game screenshots.

## Install

This delivery is based on **v496**, GitHub blob `31eb349a787279f2241acc7d11d6f0011d4eecdc` for `index.html`. The handoff supplied v495, but main acquired the raised helm and animated wheel during this work; those additions are preserved here.

For a v496 checkout, apply `merchant-brig.patch` from the repository root, or replace the existing `index.html` and `README.md` with the supplied copies. Keep the repository's existing `src/`, art and other assets. The supplied HTML is a replacement game file, not a standalone preview site.

For a newer checkout, replace **only `boatShapes()`** using `boat-shapes.js`, review any newer boat changes, and assign the next available game version. The complete supplied HTML marks this local revision as v497.

## Gameplay compatibility

- No changes to `BOAT`, `boatHB`, `boatGH`, `boatKeel`, `boatYards`, `boatFloor`, `buildBoats`, `poseBoat`, sailing or boarding code.
- Main deck surface remains at y=0. Both 0.7 m gangway openings remain open at the original positions. Gangplank slats have a flush y=0 surface.
- v496's raised helm platform, ramps and rails retain their existing geometry. The wheel stays a separate animated mesh at its existing hub and radius, preserving the hand placement and turning behavior.
- Mast and wheel supports fit their existing collision obstacles. Decorative lanterns sit behind the walkable stern boundary; windows and hull ribs are outside/below the walking area.
- Unit sail, furl roll, anchor, chain and gangplank transforms match the existing assembly and animation code.
- One existing vertex-color material, cached geometry shared across boats, no added lights or per-frame geometry work.

## Validation

The extracted full game module and the replacement function pass `node --check`. Geometry was evaluated with the game's actual geometry/math classes and emission helpers, checking finite coordinates/colors, shared caching, buffer restoration, unit sail bounds, flush unit gangplank and unit chain. **6,612 triangles per fully assembled boat**, including all four sails and furl rolls, the wheel, anchor, chain and gangplank; budget is approximately 15,000.

The renders show the emitted game geometry in Blender, with separate review lighting. The game supplies its own lighting, water, outlines and pixelation. No browser/WebGPU tests were run, as requested by the handoff. Visual/gameplay testing remains in-game: board from either side, walk both ramps, take/leave the helm, steer both ways, and cycle furled/half/full sails and the anchor. `GAME.boats()` and `GAME.aboard()` remain available.

## Files

- `boat-shapes.js`: reusable replacement function.
- `index.html`, `README.md`: complete local v497 revision based on v496.
- `merchant-brig.patch`: the two-file source patch.
- `boat-preview.png`, `boat-deck-preview.png`: sails set and furled/deck views.
- `validation.json`: geometry totals and checked contracts.

This delivery is local; it has not been committed, pushed or published.
