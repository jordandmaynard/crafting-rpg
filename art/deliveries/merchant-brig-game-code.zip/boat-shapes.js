// Kinghaven merchant brig — replacement for v496 boatShapes().
// Uses the existing BOAT, boatHB, boatGH, boatKeel, boatYards and boatMat.
// Geometry is created once; buildBoats() and poseBoat() remain compatible.
function boatShapes() {
  if (BOAT_GEO) return BOAT_GEO;
  const B = BOAT, save = OUT, made = {};
  const C = {
    wood: '#815537', dark: '#4a2e21', edge: '#503925', cap: '#aa8050',
    green: '#395749', greenLight: '#516a50', gold: '#b8923a', iron: '#2e2e34',
    rope: '#494135', canvas: '#e8dcc0', canvasShade: '#ddd0b2'
  };
  const take = (name, fn) => {
    OUT = new Buf();
    try { fn(); const mesh = OUT.mesh(boatMat); made[name] = mesh && mesh.geometry; }
    finally { OUT = save; }
  };
  // A thin ribbon wrapped around the existing collision outline; no textures.
  const sidePoint = (v, y) => {
    const hb = boatHB(v), ky = boatKeel(v);
    const sec = [[hb + 0.055, boatGH(v)], [hb + 0.04, 0],
      [hb * 0.99, ky * 0.18], [hb * 0.91, ky * 0.36],
      [hb * 0.78, ky * 0.54], [hb * 0.5, ky * 0.78], [0, ky]];
    for (let j = 0; j < sec.length - 1; j++) if (y >= sec[j + 1][1]) {
      const t = (y - sec[j][1]) / (sec[j + 1][1] - sec[j][1]);
      return sec[j][0] + (sec[j + 1][0] - sec[j][0]) * t;
    }
    return 0;
  };
  take('hull', () => {
    // Exact gangway stations make both 0.7 m rail openings explicit.
    const vs = Array.from({ length: 25 }, (_, k) => B.stern + (B.bow - B.stern) * k / 24);
    vs.push(B.gangV - 0.35, B.gangV + 0.35);
    vs.sort((a, b) => a - b);
    const gap = (a, b) => a >= B.gangV - 0.350001 && b <= B.gangV + 0.350001;
    const ys = v => [boatGH(v), 0, ...[0.18, 0.36, 0.54, 0.78, 1].map(f => boatKeel(v) * f)];
    const colors = [C.green, '#92613e', '#815234', '#74492e', '#603c29', '#4a2e21'];
    for (let k = 0; k < vs.length - 1; k++) {
      const a = vs[k], b = vs[k + 1], ya = ys(a), yb = ys(b), open = gap(a, b);
      if (b - a < 1e-6) continue;
      for (const s of [-1, 1]) {
        for (let j = 0; j < ya.length - 1; j++) {
          if (j === 0 && open) continue;
          const p = (v, y) => [s * sidePoint(v, y), y, v];
          quad(p(a, ya[j]), p(b, yb[j]), p(b, yb[j + 1]), p(a, ya[j + 1]),
            shade(CC(colors[j]), 0.94 + hs(k, j + (s > 0 ? 11 : 0), 496) * 0.1));
        }
        // Narrow dark seams, broad readable strakes below the green paint.
        for (let j = 2; j < ya.length - 1; j++) {
          const p = (v, y) => [s * (sidePoint(v, y) + 0.004), y, v];
          quad(p(a, ya[j] + 0.009), p(b, yb[j] + 0.009),
            p(b, yb[j] - 0.009), p(a, ya[j] - 0.009), CC(C.dark));
        }
        if (!open) {
          // Inner bulwark and cap close the shell's thickness.
          const ha = boatHB(a), hb = boatHB(b), ga = boatGH(a), gb = boatGH(b);
          quad([s * ha, 0, a], [s * hb, 0, b], [s * hb, gb, b], [s * ha, ga, a], CC(C.wood));
          quad([s * ha, ga, a], [s * hb, gb, b], [s * (hb + 0.055), gb, b],
            [s * (ha + 0.055), ga, a], CC(C.cap));
          seg(G.box, C.cap, [s * (ha + 0.04), ga, a], [s * (hb + 0.04), gb, b], 0.035);
          // One continuous cream/gilt pinstripe below the cap.
          quad([s * (sidePoint(a, ga - 0.09) + 0.004), ga - 0.09, a],
            [s * (sidePoint(b, gb - 0.09) + 0.004), gb - 0.09, b],
            [s * (sidePoint(b, gb - 0.12) + 0.004), gb - 0.12, b],
            [s * (sidePoint(a, ga - 0.12) + 0.004), ga - 0.12, a], CC(C.gold));
        }
      }
      // Fixed-width, parallel deck planks, clipped to the hull at each station.
      quad([-boatHB(a), -0.012, a], [-boatHB(b), -0.012, b],
        [boatHB(b), -0.012, b], [boatHB(a), -0.012, a], CC(C.dark));
      for (let q = -7; q < 7; q++) {
        const left = q * 0.2 + 0.007, right = (q + 1) * 0.2 - 0.007;
        const clip = (x, v) => Math.max(-boatHB(v), Math.min(boatHB(v), x));
        const al = clip(left, a), ar = clip(right, a), bl = clip(left, b), br = clip(right, b);
        if (ar - al + br - bl < 1e-6) continue;
        quad([al, 0, a], [bl, 0, b], [br, 0, b], [ar, 0, a],
          shade(CC(q % 3 === 0 ? '#b48a58' : '#a77e50'), 0.96 + hs(q, Math.floor((a + 4.2) / 1.5), 496) * 0.07));
      }
    }
    // Close rail ends without putting a threshold across either gangway.
    for (const v of [B.gangV - 0.35, B.gangV + 0.35]) for (const s of [-1, 1]) {
      const h = boatHB(v), y = boatGH(v);
      quad([s * h, 0, v], [s * (h + 0.04), 0, v],
        [s * (h + 0.055), y, v], [s * h, y, v], CC(C.cap));
    }
    // Raised external ribs echo the half-timbered buildings. They stay outside the deck.
    for (const v of [-3.9, -2.9, -1.9, -0.9, 0.65, 1.7, 2.7, 3.55]) for (const s of [-1, 1]) {
      const y = boatGH(v), low = -0.67;
      seg(G.box, C.edge, [s * (sidePoint(v, low) + 0.015), low, v],
        [s * (sidePoint(v, y - 0.04) + 0.015), y - 0.04, v], 0.023);
    }
    // Solid transom, restrained stern lights, and a carved diamond crest.
    const st = B.stern;
    for (const v of [st, B.bow]) {
      const levels = ys(v);
      for (let j = 0; j < levels.length - 1; j++) {
        const u = sidePoint(v, levels[j]), l = sidePoint(v, levels[j + 1]);
        quad([-u, levels[j], v], [u, levels[j], v], [l, levels[j + 1], v], [-l, levels[j + 1], v], CC(colors[j]));
      }
    }
    part(G.box, C.cap, 0, boatGH(st), st, { sx: boatHB(st) * 2 + 0.11, sy: 0.065, sz: 0.065 });
    for (const x of [-0.57, 0.57]) {
      part(G.box, C.dark, x, -0.25, st - 0.018, { sx: 0.38, sy: 0.31, sz: 0.035 });
      part(G.box, '#718b83', x, -0.25, st - 0.04, { sx: 0.29, sy: 0.22, sz: 0.016 });
      part(G.box, C.gold, x, -0.25, st - 0.055, { sx: 0.027, sy: 0.23, sz: 0.02 });
      part(G.box, C.gold, x, -0.25, st - 0.055, { sx: 0.29, sy: 0.025, sz: 0.02 });
    }
    part(G.box, C.gold, 0, 0.19, st - 0.045, { sx: 0.19, sy: 0.19, sz: 0.035, rz: Math.PI / 4 });
    // Stem and compact bowsprit; no furniture on the walking plane.
    seg(G.box, C.dark, [0, boatKeel(B.bow), B.bow], [0, boatGH(B.bow) + 0.2, B.bow + 0.055], 0.035);
    const sprit = [0, 1.7, B.bow + 1.65];
    seg(G.cyl8, C.cap, [0, 0.7, B.bow - 0.3], sprit, 0.065);
    for (const m of B.masts) {
      seg(G.frust7, C.wood, [0, -0.25, m.v], [0, m.h, m.v], 0.155);
      // Mast partners fit comfortably within the existing radius-0.42 obstacle.
      part(G.cyl8, C.dark, 0, 0.09, m.v, { sx: 0.48, sy: 0.18, sz: 0.48 });
      for (const y of [0.32, m.h * 0.59, m.h * 0.85])
        part(G.cyl8, C.iron, 0, y, m.v, { sx: y < 1 ? 0.31 : 0.22, sy: 0.055, sz: y < 1 ? 0.31 : 0.22 });
      part(G.box, C.dark, 0, m.h * 0.64, m.v, { sx: 0.65, sy: 0.09, sz: 0.5 });
      for (const [y, w] of boatYards(m)) {
        seg(G.cyl8, C.dark, [-w / 2, y, m.v + 0.14], [w / 2, y, m.v + 0.14], 0.055);
        for (const s of [-1, 1]) seg(G.cyl6, C.rope, [0, y + 0.6, m.v], [s * w * 0.46, y, m.v + 0.14], 0.01);
      }
      for (const s of [-1, 1]) for (const dv of [-0.26, 0.2]) {
        const v = m.v + dv;
        seg(G.cyl6, C.rope, [s * (boatHB(v) + 0.05), boatGH(v), v], [0, m.h * 0.86, m.v], 0.012);
      }
      part(G.oct, C.gold, 0, m.h + 0.04, m.v, { sx: 0.14, sy: 0.19, sz: 0.14 });
    }
    const [fore, main] = B.masts;
    for (const [a, b] of [
      [[0, fore.h, fore.v], sprit], [[0, main.h, main.v], [0, fore.h * 0.82, fore.v]],
      [[0, main.h, main.v], [0, B.helmP + 0.6, B.stern + 0.08]]
    ]) seg(G.cyl6, C.rope, a, b, 0.012);
    // Swallowtail pennant, faceted rather than textured.
    quad([0, main.h, main.v], [0, main.h - 0.36, main.v],
      [0.06, main.h - 0.31, main.v - 0.62], [0.06, main.h - 0.03, main.v - 0.62], CC('#a8322a'));
    tri([0.06, main.h - 0.03, main.v - 0.62], [0.06, main.h - 0.17, main.v - 0.62], [0, main.h - 0.06, main.v - 1.04], CC('#b84432'));
    tri([0.06, main.h - 0.17, main.v - 0.62], [0.06, main.h - 0.31, main.v - 0.62], [0, main.h - 0.36, main.v - 1.04], CC('#923127'));
    // Keep v496's raised helm and separate animated wheel.
    part(G.box, C.dark, 0, B.wheelY / 2, B.wheelV, { sx: 0.13, sy: B.wheelY, sz: 0.13 });
    // (v496, Jordan) the helm deck behind the wheel: planked, a step face between the ramps (behind the wheel), a
    // ramp up to it either side of the wheel, and a rail round its stern and sides
    const P = B.helmP, F = B.helmFront, RV = B.rampV, RU = B.rampU;
    const hvs = [B.stern, (B.stern + F) / 2, F];
    for (let k = 0; k + 1 < hvs.length; k++) {
      const v0 = hvs[k], v1 = hvs[k + 1], hb0 = boatHB(v0), hb1 = boatHB(v1), K = 8;
      for (let q = 0; q < K; q++) {
        const f0 = -1 + 2 * q / K, f1 = -1 + 2 * (q + 1) / K, col = shade(CC(q % 2 ? '#b8905e' : '#ab8352'), 0.95 + hs(q, k, 497) * 0.1);
        quad([f0 * hb0, P, v0], [f0 * hb1, P, v1], [f1 * hb1, P, v1], [f1 * hb0, P, v0], col);
      }
    }
    quad([-RU, 0, F], [RU, 0, F], [RU, P, F], [-RU, P, F], CC('#6b4528'));
    part(G.box, '#8a5a34', 0, P - 0.015, F + 0.02, { sx: RU * 2, sy: 0.04, sz: 0.05 });
    for (const sg of [-1, 1]) {
      const hbF = boatHB(F), hbR = boatHB(RV);
      // the ramp's top, cleated, and its inner side down to the deck
      quad([sg * RU, P, F], [sg * hbF, P, F], [sg * hbR, 0, RV], [sg * RU, 0, RV], CC('#a87e4e'));
      for (let c = 1; c < 5; c++) { const t = c / 5, v = F + (RV - F) * t, y = P * (1 - t) + 0.02, hb = boatHB(v); seg(G.box, '#7a5432', [sg * (RU + 0.04), y, v], [sg * (hb - 0.04), y, v], 0.025); }
      tri([sg * RU, 0, RV], [sg * RU, P, F], [sg * RU, 0, F], CC('#5e3c22'));
      part(G.box, '#8a5a34', sg * RU, P / 2, F + 0.03, { sx: 0.06, sy: P, sz: 0.06 });
    }
    // its rail: posts round the stern and down each side to the platform's front
    const TR = P + 0.36, rail = [];
    for (const sg of [-1, 1]) { rail.push([]); for (const v of [F, (F + B.stern) / 2, B.stern + 0.08]) rail[rail.length - 1].push([sg * (boatHB(v) - 0.03), v]); }
    for (const side of rail) {
      for (const [u, v] of side) seg(G.box, '#6b4528', [u, P, v], [u, TR, v], 0.05);
      for (let k = 0; k + 1 < side.length; k++) seg(G.box, '#8a5a34', [side[k][0], TR, side[k][1]], [side[k + 1][0], TR, side[k + 1][1]], 0.05);
    }
    seg(G.box, '#8a5a34', [rail[0][2][0], TR, rail[0][2][1]], [rail[1][2][0], TR, rail[1][2][1]], 0.05);
    // (the backstay comes down to a post at the rail's middle, clear over the head of whoever's at the wheel)
    seg(G.box, '#6b4528', [0, P, B.stern + 0.08], [0, TR + 0.25, B.stern + 0.08], 0.06);
    // Lanterns sit over the stern rail, behind the permitted walking region.
    for (const s of [-1, 1]) {
      const x = s * 0.86, z = st - 0.025, y = boatGH(st) + 0.25;
      seg(G.box, C.iron, [x, boatGH(st), z], [x, y + 0.28, z], 0.019);
      part(G.box, '#d3ab5f', x, y, z, { sx: 0.14, sy: 0.19, sz: 0.14 });
      for (const dy of [-0.12, 0.12]) part(G.box, C.iron, x, y + dy, z, { sx: 0.19, sy: 0.045, sz: 0.19 });
      part(G.cone4, C.iron, x, y + 0.18, z, { sx: 0.23, sy: 0.12, sz: 0.23, ry: Math.PI / 4 });
    }
    part(G.box, C.dark, 0.9, 0.25, 3.4, { sx: 0.5, sy: 0.12, sz: 0.14 });
  });
  take('sail', () => {
    const nu = 10, nv = 8;
    const pt = (u, v, offset = 0) => {
      const width = 0.94 + 0.06 * v;
      // Top edge stays exactly y=0, bottom exactly y=-1, for the existing furl animation.
      return [(u - 0.5) * width, -v,
        0.3 * (1 - (2 * u - 1) ** 2) * Math.sin(Math.PI * v) + offset];
    };
    for (let i = 0; i < nu; i++) for (let j = 0; j < nv; j++) {
      const col = j === nv - 1 ? C.greenLight : i % 2 ? C.canvas : C.canvasShade;
      quad(pt(i / nu, j / nv), pt((i + 1) / nu, j / nv),
        pt((i + 1) / nu, (j + 1) / nv), pt(i / nu, (j + 1) / nv), shade(CC(col), 0.97 + j * 0.004));
    }
    // Clip the crest onto each cloth triangle so it follows the actual faceted surface.
    // A single large decal quad would cut through the sail's curved belly.
    const cross = (a, b, p) => (b[0] - a[0]) * (p[1] - a[1]) - (b[1] - a[1]) * (p[0] - a[0]);
    const crest = (diamond, color, offset) => {
      for (let i = 0; i < nu; i++) for (let j = 0; j < nv; j++) {
        const a = [i / nu, j / nv], b = [(i + 1) / nu, j / nv];
        const c = [(i + 1) / nu, (j + 1) / nv], d = [i / nu, (j + 1) / nv];
        for (const uv of [[a, b, c], [a, c, d]]) {
          let poly = uv;
          for (let k = 0; k < 4 && poly.length; k++) {
            const p = diamond[k], q = diamond[(k + 1) % 4], next = [];
            for (let n = 0; n < poly.length; n++) {
              const u = poly[n], v = poly[(n + 1) % poly.length];
              const du = cross(p, q, u), dv = cross(p, q, v);
              if (du >= 0) next.push(u);
              if ((du >= 0) !== (dv >= 0)) {
                const t = du / (du - dv);
                next.push([u[0] + (v[0] - u[0]) * t, u[1] + (v[1] - u[1]) * t]);
              }
            }
            poly = next;
          }
          if (poly.length < 3) continue;
          const abc = uv.map(p => pt(...p)), denom = cross(...uv);
          const surface = p => {
            const w0 = cross(uv[1], uv[2], p) / denom;
            const w1 = cross(uv[2], uv[0], p) / denom, w2 = 1 - w0 - w1;
            return abc[0].map((n, k) => n * w0 + abc[1][k] * w1 + abc[2][k] * w2 + (k === 2 ? offset : 0));
          };
          for (let k = 1; k + 1 < poly.length; k++)
            tri(surface(poly[0]), surface(poly[k]), surface(poly[k + 1]), CC(color));
        }
      }
    };
    for (const face of [-1, 1]) {
      crest([[0.5, 0.24], [0.61, 0.43], [0.5, 0.62], [0.39, 0.43]], C.green, face * 0.004);
      crest([[0.5, 0.33], [0.555, 0.43], [0.5, 0.53], [0.445, 0.43]], C.gold, face * 0.008);
    }
  });
  take('wheel', () => {
    const R = B.wheelR, Rh = R + 0.1;
    const wp = (a,r) => [Math.cos(a)*r, Math.sin(a)*r, 0];
    for (let k=0;k<12;k++) seg(G.box, C.cap, wp(k*Math.PI/6,R), wp((k+1)*Math.PI/6,R),0.0225);
    for (let k=0;k<8;k++) seg(G.cyl6,C.wood,wp(k*Math.PI/4,0.035),wp(k*Math.PI/4,Rh),0.021);
    part(G.cyl8,C.gold,0,0,0,{sx:0.1,sy:0.07,sz:0.1,rx:Math.PI/2});
  });
  take('furl', () => {
    part(G.cyl8, C.canvasShade, 0, 0, 0, { sx: 1, sy: 1, sz: 1, rz: Math.PI / 2 });
    for (const x of [-0.32, 0, 0.32]) part(G.cyl8, C.rope, x, 0, 0, { sx: 1.035, sy: 0.025, sz: 1.035, rz: Math.PI / 2 });
  });
  take('anchor', () => {
    // Ring top at the local origin; all metal hangs below it.
    for (let k = 0; k < 8; k++) {
      const p = a => [Math.cos(a) * 0.065, -0.065 + Math.sin(a) * 0.065, 0];
      seg(G.cyl6, C.iron, p(k * Math.PI / 4), p((k + 1) * Math.PI / 4), 0.013);
    }
    seg(G.cyl6, C.iron, [0, -0.12, 0], [0, -0.85, 0], 0.035);
    part(G.box, C.dark, 0, -0.23, 0, { sx: 0.055, sy: 0.065, sz: 0.52 });
    for (const s of [-1, 1]) {
      seg(G.cyl6, C.iron, [0, -0.85, 0], [s * 0.32, -0.72, 0], 0.035);
      seg(G.cyl6, C.iron, [s * 0.32, -0.72, 0], [s * 0.4, -0.54, 0], 0.032);
      part(G.cone4, C.iron, s * 0.38, -0.57, 0, { sx: 0.18, sy: 0.2, sz: 0.12, rz: -s * 0.4 });
    }
  });
  take('chain', () => part(G.box, C.iron, 0, -0.5, 0, { sx: 0.035, sy: 1, sz: 0.035 }));
  take('plank', () => {
    // No raised rungs: the entire walking surface is flush at local y=0.
    part(G.box, C.dark, 0.5, -0.059, 0, { sx: 1, sy: 0.062, sz: 0.62 });
    for (let j = 0; j < 4; j++) part(G.box, j % 2 ? '#a77e50' : '#b48a58', 0.5, -0.014, -0.2325 + j * 0.155,
      { sx: 1, sy: 0.028, sz: 0.145 });
  });
  return BOAT_GEO = made;
}
