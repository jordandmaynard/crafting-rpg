# Wanderer's Kit loading window — 11-slice production handoff

This package resizes the approved blank loading window while keeping the compass, shoulders, corner turns and rivets in proportion. Use eleven images, not a conventional single-sprite nine-slice: the header has five columns so its unique compass section stays centered. All eleven core pieces are cuts from the selected source, with no regenerated frame artwork or RGB recoloring. The selected source had slightly translucent interior pixels and isolated faint background pixels; only alpha was cleaned. Native-size reassembly is pixel-identical to `window-reference-1254.png`.

## Files

- `assets/`: eleven required RGBA PNG cuts; one optional parchment tile.
- `layout.json`: exact source coordinates, resize directions, sampling and minimums.
- `renderer.js`: framework-free reference Canvas renderer; port its rectangles to the game's sprite/UI renderer.
- `resize-preview.html`: open after extracting the entire ZIP to drag width, height and frame-scale sliders. All assets stay relative to this file; no service or external dependencies.
- `previews/`: native, wide, tall, compact and landscape examples; a slice diagram; a comparison sheet.
- `validation.json`: verification results.

## Source-space dimensions

The original canvas is **1254 × 1254**. Keep its transparent margins; anchors below include them. Top-left is the origin. At the original source scale, left/right columns are 160 px, top band 280 px, bottom band 134 px, and the fixed center header is 314 px wide. The header's compass shoulders are included in this center piece. Do not cut the center piece further.

| PNG | Source x, y | Source width × height | Resize |
|---|---|---|---|
| top_left | 0, 0 | 160 × 280 | Uniform frame scale only |
| top_span_left | 160, 0 | 310 × 280 | Horizontal |
| top_center | 470, 0 | 314 × 280 | Uniform frame scale only; horizontally centered |
| top_span_right | 784, 0 | 310 × 280 | Horizontal |
| top_right | 1094, 0 | 160 × 280 | Uniform frame scale only |
| body_left | 0, 280 | 160 × 840 | Vertical |
| body_center | 160, 280 | 934 × 840 | Horizontal and vertical |
| body_right | 1094, 280 | 160 × 840 | Vertical |
| bottom_left | 0, 1120 | 160 × 134 | Uniform frame scale only |
| bottom_center | 160, 1120 | 934 × 134 | Horizontal |
| bottom_right | 1094, 1120 | 160 × 134 | Uniform frame scale only |

## Runtime assembly

Use target canvas size `W × H` and shared frame scale `s`. A useful starting value for desktop UI is `s = 0.5`; use your existing UI/DPI scale to adjust it. At `s = 1`, 1254 × 1254 reproduces the source layout.

1. Compute shared x boundaries: `0`, `160s`, `(W−314s)/2`, `(W+314s)/2`, `W−160s`, `W`.
2. Compute shared y boundaries: `0`, `280s`, `H−134s`, `H`.
3. Round each boundary once to the same pixel grid, then subtract adjacent boundaries to obtain destination widths/heights. Do not round each independent rectangle separately; that can open gaps.
4. Draw the five header images across the first row. Draw body left, center, right across the middle. Draw the three bottom images across the bottom row. No overlaps, duplicate caps or extra backing layer are required.
5. Stretch only in the directions listed above. Do not horizontally stretch the whole header or repeat the compass. Do not tile the raw edge strips; their endpoints are not seamless tiles.
6. Draw the runtime title, screenshot, loading text, progress bar, metadata and button after the background. None are baked into this asset set.

Reference use:

```js
const assets = await WanderersKitWindow.load('/ui/loading/assets');
const content = WanderersKitWindow.draw(ctx, assets, x, y, 840, 800, 0.5);
// content.title is the safe title rectangle.
// content.body is the safe parchment rectangle.
```

Minimum size is **762s × 478s**. At s = 0.5 this is 381 × 239. This is the frame's structural minimum, not a promise that every loading control fits. For smaller panels reduce `s` uniformly; never allow the left/right spans to become negative. Keep the actual loading dialog large enough for the screenshot and controls. Increasing width/height stretches the straight seams/stitching and parchment texture; if very large texture grain is undesirable, use the optional fill treatment below. These are bitmap assets, not resolution-independent vectors.

## Place the 16:9 game image and controls

The blank body spans `(160s, 280s)` through `(W−160s, H−134s)`. Give its contents an additional 16s inset. The title's recommended safe rectangle is `(160s,124s,W−320s,88s)`, below the compass. Keep all runtime content inside these areas.

Let screenshot width be at most `body.width − 32s` and height `width × 9/16`. Leave space underneath for the journey line, progress bar, status, seed/version row and Set Out button; if there is insufficient room, make the screenshot smaller or increase the window height. Preserve 16:9 rather than stretching the game image with the window.

## Sampling and alpha

- Use the existing UI straight-alpha source-over pipeline consistently. If the engine imports premultiplied alpha, premultiply exactly once; do not mix conventions.
- Use linear filtering and clamp-to-edge on the required cuts. Keep all pieces on the same pixel-snapped coordinate grid.
- Prefer individual textures. If packing an atlas, extrude each sprite's edge texels by at least 2 px into an atlas gutter; never sample a neighbor sprite. Disable mipmaps for screen-space UI unless the engine generates a correctly padded mip chain.
- Retain the transparent pixels in every cut: trimming sprites changes the supplied anchors. If an atlas trimmer is unavoidable, apply its trim offsets explicitly.
- Keep normal tint white. These pieces already contain the chosen leather and brass hues.

## Optional large-window fill

`optional_parchment_tile_512.png` is a new generated parchment texture, color matched to the source center and made periodic at opposing edges. It is **not required** for assembly and is not used in the supplied previews or default renderer. The frame, header and eleven source cuts were not regenerated.

For extremely large centers, you may draw this repeating texture over the existing `body_center` at its natural detail scale. Fade the overlay from zero opacity at all four center edges to full opacity over 48s pixels. This keeps the exact-source transitions into the side/top/bottom slices; replacing the center with an unblended solid tile will expose a different border transition. Implement the fade in a shader or an offscreen alpha mask. Set repeat wrapping on this optional texture only. Avoid high-contrast embossing, stamped patterns or color tints.

## Verification

The eleven cuts reassembled to the alpha-cleaned reference at 1254 × 1254 with an exact RGBA match. RGB values in the original frame silhouette are unchanged. The compass/shoulders and corner rivets remain fully included in their fixed cuts. Wide 1800 × 1254, tall 1254 × 1700, compact 900 × 1000 and landscape 1500 × 950 were assembled and inspected. The center is fully opaque in all four layouts. Opposite edges of the optional tile match exactly.
