/* Wanderer's Kit 11-slice window. Plain browser JS; no framework required. */
(function (root) {
  'use strict';
  const NAMES = [
    'top_left', 'top_span_left', 'top_center', 'top_span_right', 'top_right',
    'body_left', 'body_center', 'body_right',
    'bottom_left', 'bottom_center', 'bottom_right'
  ];

  async function load(baseUrl) {
    const assets = {};
    await Promise.all(NAMES.map(name => new Promise((resolve, reject) => {
      const image = new Image();
      image.onload = () => { assets[name] = image; resolve(); };
      image.onerror = () => reject(new Error('Cannot load ' + name));
      image.src = baseUrl.replace(/\/$/, '') + '/' + name + '.png';
    })));
    return assets;
  }

  // All boundaries are shared and snapped once to avoid fractional gaps.
  // Sizes refer to the complete transparent canvas, not visible brass bounds.
  function layout(width, height, frameScale = 1) {
    const w = Math.round(width), h = Math.round(height), s = frameScale;
    if (![w,h,s].every(Number.isFinite) || s <= 0 || w < 762*s || h < 478*s) {
      throw new RangeError('Window minimum: 762 × 478 multiplied by frameScale.');
    }
    const x = [0, Math.round(160*s), Math.round((w-314*s)/2),
      Math.round((w+314*s)/2), w-Math.round(160*s), w];
    const y = [0, Math.round(280*s), h-Math.round(134*s), h];
    const rect = (l,t,r,b) => ({x:l,y:t,width:r-l,height:b-t});
    return {
      top_left: rect(x[0],y[0],x[1],y[1]),
      top_span_left: rect(x[1],y[0],x[2],y[1]),
      top_center: rect(x[2],y[0],x[3],y[1]),
      top_span_right: rect(x[3],y[0],x[4],y[1]),
      top_right: rect(x[4],y[0],x[5],y[1]),
      body_left: rect(x[0],y[1],x[1],y[2]),
      body_center: rect(x[1],y[1],x[4],y[2]),
      body_right: rect(x[4],y[1],x[5],y[2]),
      bottom_left: rect(x[0],y[2],x[1],y[3]),
      bottom_center: rect(x[1],y[2],x[4],y[3]),
      bottom_right: rect(x[4],y[2],x[5],y[3])
    };
  }

  function draw(ctx, assets, x, y, width, height, frameScale = 1) {
    const boxes = layout(width, height, frameScale);
    const ox = Math.round(x), oy = Math.round(y), s = frameScale;
    ctx.save();
    ctx.imageSmoothingEnabled = true;
    for (const name of NAMES) {
      const b = boxes[name];
      if (!assets[name]) throw new Error('Missing slice: ' + name);
      ctx.drawImage(assets[name], ox+b.x, oy+b.y, b.width, b.height);
    }
    ctx.restore();
    // Place all runtime content after the window, in these safe areas.
    return {
      title: { x: ox+Math.round(160*s), y: oy+Math.round(124*s),
        width: Math.round(width)-Math.round(320*s), height: Math.round(88*s) },
      body: { x: ox+boxes.body_center.x, y: oy+boxes.body_center.y,
        width: boxes.body_center.width, height: boxes.body_center.height }
    };
  }

  const api = { names: NAMES, load, layout, draw };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.WanderersKitWindow = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
