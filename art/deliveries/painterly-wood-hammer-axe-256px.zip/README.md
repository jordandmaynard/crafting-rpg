# Wooden hammer and axe — painterly 256×256 item icons

The individual PNGs are `hammer-wood-painterly-256x256.png` and `axe-wood-painterly-256x256.png`. The preview includes the existing wood sword for comparison only.

Both icons are RGBA, exactly 256×256 pixels, with transparent backgrounds and strictly binary alpha values of 0 or 255. Preserve their alpha and square aspect ratio when importing; use filtering and mipmaps if displayed at smaller non-integer sizes. Neither UI borders nor shadows are baked in.

The hammer has a massive upright blocky wooden striking head proportioned after the in-game reference. The axe has a single broad wooden blade. Both follow the same warm hand-painted wooden equipment style as the sword, bow and spear. Source artwork was made with the built-in image generator, cropped and downscaled, and the alpha was thresholded at 128.
