// Copy dolphin.js to <game>/dolphin/dolphin.js, then add this import to index.html's module:
// import { makeDolphin, poseDolphin } from './dolphin/dolphin.js';
// The game already has GFX, scene, flatMat, boatDeckY and BOAT.

// Create once, after selecting the boat to accompany:
// const dolphin = makeDolphin(GFX, {
//   material: flatMat({ vertexColors: true, side: GFX.DoubleSide }), phase: 0.25
// });
// scene.add(dolphin.g);

// Each frame, after the boat is posed:
// poseDolphin(dolphin, time); // time is elapsed seconds, NOT frame delta
// const u = 2.8, v = 1.5;   // across/forward in the boat's local frame
// dolphin.g.position.set(
//   b.x + Math.cos(b.h) * u + Math.sin(b.h) * v,
//   boatDeckY(b) - BOAT.free - 0.24,
//   b.z - Math.sin(b.h) * u + Math.cos(b.h) * v
// );
// dolphin.g.rotation.y = b.h;

// The placement above is a simple visual companion. The model does not add wildlife
// spawning, navigation, shore avoidance or gameplay collisions to the game.
// Pause at any swim pose: poseDolphin(dolphin, chosenTime).
// Neutral/bind pose: poseDolphin(dolphin, 0, 0).
// Change stroke and cadence: poseDolphin(dolphin, time, 0.8, 1.1).
// Reuse one material for several dolphins; give each a different phase.

// If pasting directly inside the existing game module is easier, use dolphin-inline.js.
// It contains the same implementation with the export keywords removed.
