# Emberwild dolphin — procedural code asset

The dolphin is constructed directly in JavaScript in the same coordinate frame as the boat: **Y up, +Z forward, one unit per metre/tile**. It is approximately 3.59 units long and 1.76 units across the flipper tips. Colors are muted blue-grey above and pale grey below, using the game's flat lighting and vertex-color material.

## What is supplied

- `dolphin.js`: importable JavaScript module containing the shape builder, six-bone skinning rig, animation, and GFX mesh adapter.
- `dolphin-inline.js`: identical implementation without `export` keywords, for pasting into the game's existing module beside the boat helpers.
- `integration-example.js`: creation, per-frame update, and placement alongside a boat using its heading and deck height.
- `preview.html`: self-contained animated preview. Double-click to open; no server, network, libraries or model downloads are required. It supports pause/scrub, orbit, top/side views, topology edges, a rig overlay, and a view beside the merchant brig.
- PNG previews and `validation.json`.
- `dolphin-swim.gif`: an animated image of the actual weighted swimming loop, for apps that cannot open local HTML. It opens in a normal image viewer or browser. The local HTML preview uses a classic script and has no module-loading requirement.

## Shape and topology

**485 unique shell vertices, 966 triangles, one connected, closed, consistently wound surface.** Body sections form the beak, forehead, torso and tail stalk. The dorsal fin, both flippers and both tail flukes extend from removed patches of that same surface. Their roots share vertices and edges with the body. There are no intersecting primitives, separate closed fin pieces, open seams or loose vertices. The eye markings are inset patches in the surface, and the mouth is colored into it.

The logical indexed topology is retained in `dolphinShape().positions` and `.triangles`. The drawing buffer repeats triangle corners so individual faces can carry flat colors, as with the boat's immediate-mode output. Repeated corners use the same underlying deformed vertex position, so this does not create moving cracks or separate shells.

## Rig and animation

Six bones: **body → tail_base → tail_mid → flukes**, plus **flipper_right** and **flipper_left**, both parented to body. Every vertex has normalized weights to at most two bones. Increasingly delayed rotations along the tail create a continuous vertical swimming stroke, with subtle body pitch and small flipper adjustments. The tail flukes are horizontal.

The current GFX renderer has no built-in smooth skeletal mesh class. The adapter therefore applies the six bone matrices to the weighted vertices on the CPU and flags the existing position attribute for upload. It uses the existing lit, flat-shaded material, including the normal game lighting, shadows and outlines; no renderer or shader change is required. The rest shape, weights and palette are cached and shared. Each independently animated dolphin has its own small, reusable position buffer. No topology, BufferGeometry or material is recreated each frame.

API: `dolphinShape()`, `dolphinSkin()`, `poseDolphinSkin(skin, seconds, amplitude=1, cyclesPerSecond=0.85)`, `makeDolphin(GFX, options)`, `poseDolphin(dolphin, seconds, amplitude=1, cyclesPerSecond=0.85)`, and `disposeDolphin(dolphin)`. `options` accepts a shared material and a phase offset in seconds.

## Verification

Checked with the game's actual geometry, math, scene and material classes. The canonical shell has exactly one connected component, two incident faces per edge, zero boundary/non-manifold edges, zero loose vertices, consistent winding, positive enclosed volume and no degenerate triangles. All weights are normalized. A complete swim cycle was sampled at 49 poses, with finite positions and a seamless loop. Neutral amplitude recovers the bind pose. Independent GFX instances, persistent buffers and GPU update flags were also checked. The self-contained preview's drawing, views, boat comparison, rig overlay, pause and scrub controls pass execution checks.

The PNGs are rendered from the exact JavaScript geometry and bone poses. No Blender model or model import is involved. In-game visual testing remains to be done after integrating the helpers. The supplied boat-relative placement is a visual example; wildlife spawning, movement AI, shore avoidance and gameplay collisions are outside this modeling asset.

No existing game file has been replaced or published.
