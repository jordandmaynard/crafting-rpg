# Torso body-type icon delta

Nine new runtime icons: male torso variants for all eight armor sets, plus a female variant of the blue cloth starting torso. Every runtime image is **256×256 RGBA PNG, binary alpha, with no added black border**. Use the existing programmatic item-outline treatment.

This is an additive delta. Keep the existing female armor torso icons and the current blue cloth starting shirt. Reuse the existing pants, boots and helmets for both body types. No item IDs, equipment rules, recipes or inventory quantities need to change; these are presentation variants of the same items.

## Files and selection

| Existing armor icon ID | Female presentation | Male presentation added here |
|---|---|---|
| leatherArmor | Existing `leatherArmor.png` | `armor/leatherArmor_male.png` |
| boneArmor | Existing `boneArmor.png` | `armor/boneArmor_male.png` |
| chainArmor | Existing `chainArmor.png` | `armor/chainArmor_male.png` |
| plateArmor | Existing `plateArmor.png` | `armor/plateArmor_male.png` |
| verdaneArmor | Existing `verdaneArmor.png` | `armor/verdaneArmor_male.png` |
| caeriteArmor | Existing `caeriteArmor.png` | `armor/caeriteArmor_male.png` |
| orivaneArmor | Existing `orivaneArmor.png` | `armor/orivaneArmor_male.png` |
| auralithArmor | Existing `auralithArmor.png` | `armor/auralithArmor_male.png` |

For the starting cloth torso, keep `cloth-shirt-painterly-256x256.png` for the male presentation and use `armor/cloth-shirt-female-painterly-256x256.png` for the female presentation. Bind this to the game's existing starting-shirt item; the delta does not invent a new gameplay item ID. `clothShirt_female` in the manifest is an asset key only.

Select the appropriate torso artwork using the game's existing character body-type value. Apply that resolver wherever torso item icons follow the current character's body type, such as inventory, equipment slots and item tooltips. Shared item definitions remain shared. If a context has no body-type selection, retain the game's existing default icon policy.

The male variants preserve each approved armor set's material palette, trim and painterly treatment while using broader shoulders/chest and straighter waists. The female cloth shirt preserves the original royal blue cloth, green scarf and plain blue hem, with a subtly fitted shape. Neither starting shirt has a waist belt; belts remain on the pants.

## Import

Use the complete 256px canvas, aspect-fit scaling and normal white tint. Art fits within a 240px square, leaving safe transparent margins. Preserve alpha and avoid lossy texture compression. Do not add a baked source border or recolor the images. Use the existing runtime outline after selecting the body-type variant.

Only the nine PNGs under `armor/` are runtime textures. `previews/` contains review layouts with labels and backgrounds. `assets.json` records the exact filenames, body types and source item IDs; `validation.json` records dimensions, binary-alpha checks and verification that the previous 44 runtime icons remain unchanged. `source/prompts.json` records the painting prompts and reference roles; artwork was created using the built-in image generator and then resized and converted to binary alpha for export. Higher-resolution painted sources are in the separate Painted Masters archive.
