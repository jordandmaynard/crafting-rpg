# Wanderer’s Kit — Iron Chibi Cursors

Five actual **32×32** cursors based on the existing iron weapons, with compact oversized heads, silver-blue facets, brown grips/shafts and a dark outer contour. The click point for **every cursor is pixel(0,0), measured from the top-left of the32×32 canvas**. The sword, spear, arrow and axe have opaque contact pixels there. For the corrected hammer, the hotspot remains(0,0) in transparent space, as requested; its head preserves proper crosswise construction.

| Weapon | PNG | CUR | Direction |
|---|---|---|---|
| Sword | `png/cursor-sword-32.png` | `cur/cursor-sword.cur` | Blade points top-left |
| Spear | `png/cursor-spear-32.png` | `cur/cursor-spear.cur` | Spearhead points top-left |
| Hammer | `png/cursor-hammer-32.png` | `cur/cursor-hammer.cur` | Crosswise head in upper-left; corner transparent |
| Bow | `png/cursor-bow-arrow-32.png` | `cur/cursor-bow-arrow.cur` | Arrow alone points top-left |
| Axe | `png/cursor-axe-32.png` | `cur/cursor-axe.cur` | Cutting corner/head top-left |

## Import

Use PNGs for the game engine’s cursor API or software cursor renderer. Set the hotspot explicitly to **0,0**. For software rendering, the sprite’s top-left is at the pointer coordinates; do not subtract half the sprite size. Disable automatic trimming, centering and added padding, which would move the click point. If an importer stores pixel coordinates from the bottom-left, convert the same physical top-left point to **0,31** for this32px image; use the actual importer’s coordinate convention.

Use the32px art at its intended logical size, subject to the game’s/system’s existing DPI policy. If deliberately scaling a software cursor, nearest-neighbor scaling preserves the crisp native pixel edges. Do not independently enlarge these via the inventory-item icon scale. The32px files are the production images; the enlarged review images are not runtime art.

PNGs are lossless sRGB straight RGBA with binary alpha(0 or255). Transparent RGB is cleared. The reduced palette and opaque dark contour keep the miniature facets readable across light and dark environments. No glow, drop shadow, backing frame or additional pointer arrow is baked into the images.

The Windows `.cur` files contain a32×32,32-bit BGRA DIB with an AND transparency mask and embedded **0,0** hotspot. They have been parsed and decoded back to the exact PNG pixels. OS/game loading and the engine’s input integration still need to be checked in the actual target application.

For browser use, `cursors.css` gives explicit PNG hotspots, for example:

```css
.wk-cursor-sword {
  cursor: url('./png/cursor-sword-32.png') 0 0, auto;
}
```

Apply the chosen cursor through the existing equipped-weapon/input-mode logic. The bow maps to the arrow asset. No new weapon rules, animations, pressed-state art or tint states are introduced by this package.

## Provenance and verification

The five source references were the existing `sword-iron-painterly-256x256.png`, `spear-iron-painterly-256x256.png`, `hammer-iron-painterly-256x256.png`, `bow-iron-painterly-256x256.png` and `axe-iron-painterly-256x256.png` files. The original item icons remain unchanged.

Built-in image generation produced the chibi sources. `reference/PROMPTS.json` records the original prompt set. `reference/HAMMER_REVISION.json` supersedes the old hammer-corner constraints with the corrected crosswise head and permitted transparent hotspot. Technical finishing included alpha cleanup, uniform fitting, a small clockwise axe registration adjustment, palette reduction and native-pixel hotspot alignment. Revision1.1 replaced the hammer with a true T-shaped maul: its long head axis crosses the handle, which attaches at the center. No pixel is forced into its empty top-left corner. Each final32px texture was inspected in the comparison preview.

`cursors.json` records paths, dimensions, hashes and hotspots. `validation.json` records32×32 dimensions, binary alpha, each hotspot’s alpha state and exact CUR-to-PNG decoding for all five. The four other PNG/CUR pairs are byte-identical to the original set. `preview.png` shows8× nearest-neighbor enlargements and actual32px samples on dark/light grounds; the small gold guide outside each enlarged sample is preview-only.


## Revision1.2 — squatter chibi hammer

The hammer has a shorter, thicker block head with closer end bands, a shorter wood neck and a stout grip. Its correct crosswise orientation and center handle attachment are retained. Pixel(0,0) remains transparent and the embedded hotspot remains(0,0). This supersedes the1.1 head proportions. `reference/HAMMER_CHIBI_REVISION.json` records the exact selected image, markup reference and final built-in image-edit prompt. The other four PNG/CUR pairs remain byte-identical.
