# Wanderer’s Kit — map bookmarks delta v1

Start with `MAP_BOOKMARKS_DELTA_HANDOFF.md` and `layout.json`. Import the 14 PNGs in `assets/`: one common border, six leather faces, six separate painted icons and one interaction tint mask. The road is an unmarked fantasy dirt path.

Replace only the six current world-map bookmarks. Reuse the current main map frame, map renderer, parchment fog, compass, footer and handlers. Keep the border neutral and apply state overlays only through the face mask. The common frame is extracted from the approved mockup, so all six tabs use exactly the same leather hue and tone.

The PNGs contain no baked labels. The supplied CSS is a visual-layer reference, not a new map controller. Previews are documentation and must not become map textures. No game code has been modified.
