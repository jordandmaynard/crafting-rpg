# Cathedral stained-glass textures v1

Four separate lossless RGBA PNG textures, drawn as viewed from outside the cathedral. Top of each image is the top of its window. There is no lettering in the textures.

| Design | Primary asset | Optional closer-view asset |
|---|---|---|
| Grail with god rays | `256/01-grail-god-rays.png` | `512/01-grail-god-rays.png` |
| Knight with sword raised and sun rays | `256/02-knight-sun-rays.png` | `512/02-knight-sun-rays.png` |
| Praying priestess | `256/03-praying-priestess.png` | `512/03-praying-priestess.png` |
| Generic geometric rose | `256/04-geometric.png` | `512/04-geometric.png` |

The 256 folder is the requested production set. The 512 folder contains the same four designs with twice the spatial resolution; use one size per window, not both layered together.

## Geometry and alpha

Each primary image is exactly 256×256. The circular glass is centered at `(128,128)` in continuous image coordinates, radius 125 pixels, diameter 250 pixels. With integer pixel indices 0–255, this is centered between indices 127 and 128. Coverage is evaluated at pixel centers:

```text
inside = (x + 0.5 - 128)^2 + (y + 0.5 - 128)^2 <= 125^2
alpha = 255 if inside else 0
```

Every pixel inside the circle is fully opaque, including the dark figure and lead. Everything outside is fully transparent with zero RGB. No semi-transparent edge pixels or holes. At 512×512 the center/radius double to `(256,256)` / 250, retaining the same UV footprint.

## Color and readability

Pane colors are uniform flat palette fills, with no gradients, texture noise or dithering. Lead is exactly `#16121A` (22,18,26). Main pane seams target approximately 3–6 pixels at 256; the circular outer lead rim is 4 pixels radially. Details and stroke sizes scale by two in the 512 exports.

The knight’s armor and priestess’s robe use the near-black lead family to preserve the large dark silhouettes. Colored panes are saturated and have a maximum RGB channel above 115; lead and silhouette pixels have every channel below 30. The hues are intended to survive the game’s brightness boost. The grail uses a broad gold cup and descending rays; geometric panes use a large eight-point medallion with concentric diamonds/triangles.

`stained-glass-preview.png` is a labeled contact sheet for review only. Its checkerboard and labels are not present in any window texture. An approximate blurred projection was checked during preparation; the actual game shader was not supplied or tested.

## Verification and provenance

`reference/validation.json` records dimensions, circular alpha checks, palette checks and SHA-256 hashes for all eight exports. `reference/source-provenance.json` identifies the generated source designs and fitted source-circle bounds. `reference/prompts.json` records the final prompt set and use of the built-in image generation tool. Technical export preparation flattened pane colors, normalized lead thickness, and applied the exact circular mask.
