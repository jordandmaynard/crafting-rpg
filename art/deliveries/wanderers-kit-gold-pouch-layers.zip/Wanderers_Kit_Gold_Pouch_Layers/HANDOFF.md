# Wanderer's Kit gold pouch — three registered layers

## Production files

1. **gold-pouch-closed.png** — intact front of the bag. Both upright mounting straps and brass snaps have been removed. The original folded mouth, drawstring and brass cord tips remain.
2. **gold-pouch-back-shell.png** — empty concave inside back shell, with the front leather, front rope ends and cutaway rim removed. This is the interior seen from the front, not an exterior rear view.
3. **gold-pouch-cutaway-overlay.png** — foreground leather, rope, cord tips, rolled cut edge and stitches. The opening is genuinely transparent. Draw it over the back shell to reproduce the cutaway.

All three are **1254 × 1254 RGBA PNGs**, with the same anchor `(0,0)` and the same external silhouette. Alpha is binary: 0 or 255. Do not trim or recenter them independently. No title or gold coins are baked in.

Visible bag bounds in this shared canvas are `x=218, y=157, width=797, height=1078`. Empty space above the bag is intentional: removing the straps did not enlarge or reposition the pouch. The internal cutaway opening bounds are `x=436, y=570, width=518, height=585`; its contour is curved, not a rectangular viewport.

## Rendering

- **Intact state:** draw `gold-pouch-closed.png` alone.
- **Cutaway state:** draw back shell, procedural coins, then cutaway overlay, in that order.
- **Back-only state:** draw the back shell alone when the complete front is meant to disappear.
- Give all image layers the exact same destination rectangle, scale, UV orientation and origin. Scale the whole group uniformly. These organic shapes should not be nine-sliced or stretched independently.
- Use white tint and the same opacity/color pipeline for every layer. The leather and brass are already colored.
- Preserve source-canvas offsets if an engine/atlas trims sprites. The simplest import is untrimmed textures with clamp-to-edge sampling.

The visible coin mask can be derived from the production images without another supplied art asset:

```text
coinMask = (backShell.alpha > 0) AND (cutawayOverlay.alpha == 0)
```

Intersect with the back alpha as shown; simply inverting the overlay alpha would also include all the empty space outside the pouch. For the partial-cutaway state, clip the procedural coin drawing to this curved mask. The front overlay then supplies the physical edge and stitching. For a full back-only view, clip to the complete back-shell alpha instead. No rectangular black backing should be drawn in the opening.

## Matching and verification

The three files were registered to a single shared silhouette. Shared front leather/rope artwork was copied from one source master instead of generating independent foregrounds. Original cutaway reference pixels below y=330 were retained in that master; only the top mounting-tab region required a new painted edge. The closed-front patch fills the opening and removes its stitched lip.

The newly revealed back shell is one continuous painted surface. Its lining color and contrast were calibrated against the visible lining in the supplied cutaway reference. The inside is naturally darker than the outer leather; that is shading of the lining, not a different outer-leather tint.

Verified:

- Closed and back-shell alpha silhouettes match exactly.
- The overlay has the same outer bounds, with only the internal opening removed.
- Every opaque overlay pixel is copied byte-for-byte from the shared cutaway master.
- All three PNGs have binary alpha and clear canvas edges.
- Back shell + overlay reproduces `previews/cutaway-reassembled.png` exactly, with zero mismatched RGBA pixels.

`verification.json` records the dimensions, bounds, palette calibration and checks. `previews/layer-preview.png` shows the three production layers followed by the assembled cutaway. Its common display crop is only for review; use the full-size production files in game. The preview images are not additional runtime layers.
