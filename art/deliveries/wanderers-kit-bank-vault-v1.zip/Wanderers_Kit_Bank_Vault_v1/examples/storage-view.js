// Reference geometry/bindings; adapt draw and command calls to the game.
// Supply the parsed layout.json. Container operations remain game-owned.
export function vaultSlotRect(index, layout) {
  if (!Number.isInteger(index) || index < 0 || index >= 20) throw new RangeError('Vault index must be0..19');
  return layout.slots[index].rect.slice();
}

export function vaultSlotAt(localX, localY, layout) {
  const [gx, gy] = layout.grid_rect;
  const dx = localX - gx, dy = localY - gy;
  if (dx < 0 || dy < 0) return null;
  const column = Math.floor(dx / 108), row = Math.floor(dy / 108);
  if (column >= 4 || row >= 5 || dx % 108 >= 104 || dy % 108 >= 104) return null;
  return row * 4 + column;
}

export function occupiedVaultSlots(items) {
  // Example assumes null/undefined is empty. Map the game's sentinel as needed.
  if (items.length > 20) throw new RangeError('This vault layout has capacity20');
  return items.filter(item => item != null).length;
}

export function vaultView(items, layout) {
  if (items.length > 20) throw new RangeError('This vault layout has capacity20');
  return {
    occupancy: `${occupiedVaultSlots(items)} / 20`,
    slots: layout.slots.map(slot => ({
      index: slot.index,
      rect: slot.rect,
      sprite: 'cubby-normal', // Always the same sprite at every grid position.
      rotation: 0,
      item: items[slot.index] ?? null
    }))
  };
}
