# Wanderer’s Kit — Bank Vault v1

Approved design: **20 slots, four columns by five rows**, matching the backpack layout. This supersedes the earlier 40-slot and five-column mockups. The slots are front-facing iron cubbies, with one shared sprite repeated unchanged at every grid position. The round open door shows its inner locking mechanism and remains attached to the left jamb by both hinges.

This is an art/integration handoff. No game repository was supplied or modified. Wire the supplied presentation into the existing crate/storage and bank-vault code; keep storage rules and persistence authoritative in that code.

## Contents

Six lossless, transparent RGBA PNGs are under `assets/`:

| Asset | Pixels | Logical draw size | Use |
|---|---|---|---|
| `vault-shell.png` | 1792×1792 | 896×896 | Complete fixed shell: stone, iron jamb/backplate, blank plaques/count/close background, door and attached hinges |
| `cubby-normal.png` | 256×256 | 104×104 | The one empty iron cubby used by all 20 storage slots |
| `cubby-inner-mask.png` | 256×256 | 104×104 | Tint coverage for hover and valid/invalid drop feedback |
| `cubby-rim-mask.png` | 256×256 | 104×104 | Tint coverage for selection and keyboard focus |
| `close-face-mask.png` | 128×128 | 68×67 | Optional hover/pressed tint over the close control’s inset face |
| `glyph-close.png` | 64×64 | About 53×52 canvas | Existing neutral UI X, tinted cream; its actual strokes have internal padding |

`assets.json` lists the exact files, sizes and SHA-256 hashes. `layout.json` contains all live slot rectangles, text fields, styling and state tint values. `examples/storage-view.js` is small engine-neutral reference code for positioning, slot hit-testing and occupancy counting. Adapt it to your actual framework and data types; it is not a replacement for storage command validation.

The shell and door/hinges intentionally remain one composite so no cut seam can disconnect a hinge or cover its rivets. The door is decorative in this version, not an animated/interactable subcontrol. The twenty live item slots, their contents, all text and the close glyph are separate runtime layers. The shell has no baked slot grid, labels or occupancy number.

## Import and scaling

Import as **sRGB, straight/unassociated alpha**, with linear filtering. All runtime PNGs have transparent safety borders, smooth alpha and cleared transparent RGB. Disable automatic sprite trimming, border removal and arbitrary importer padding. If your engine premultiplies internally, convert once at import and use the corresponding blend mode; do not premultiply twice. Use lossless textures or verify any chosen compression at actual UI scale.

Render the full shell uniformly; do not nine-slice, tile or perspective-warp it. Its original grain, complete door silhouette, plaques and hinge connections rely on fixed proportions. There is no repeat module or joined center texture. The cubby is also drawn uniformly, never stretched differently in X and Y. There is no single global texture density: shell1792px maps to896logical, while cubby256px maps to104logical. Use the explicit logical sizes rather than dividing every PNG by two.

Standalone reference viewport is **1920×1080**, with the 896×896 logical group at **(512,92)**. For a standalone fit, use `scale=min(1,(viewportWidth-32)/896,(viewportHeight-32)/896)` and center the whole group. Scale the shell, slots, labels, hit regions, masks and drag placement together. Do not scale only the grid to make it fit.

In the actual game, position this independent storage window alongside the existing backpack, as with the crate. Keep both panels operable for transfers. The reference center position is a review composition, not a requirement to cover the backpack. If the backpack uses a different common logical slot size, choose the vault’s uniform group scale so the 104px cubby matches that slot size; preserve the 4×5 arrangement and relative coordinates. Do not introduce per-row offsets, camera tilt or varying inset depth.

## Assembly and coordinates

All coordinates below are local to the 896×896 group and use a top-left origin.

| Element | x,y,width,height |
|---|---|
| Shell | 0,0,896,896 |
| Header text | 352,54,247,47 |
| Occupancy text | 643,54,133,49 |
| Close control/hit region | 792,49,68,67 |
| Footer text | 379,778,384,56 |
| Complete grid | 367,176,428,536 |

Each slot canvas is **104×104**, with **108px pitch** in both directions. For zero-based `row=0..4` and `column=0..3`:

```text
x = 367 + column * 108
y = 176 + row * 108
index = row * 4 + column
```

Use **the exact same `cubby-normal.png`**, rotation0 and identical scale for every slot. Do not cut twenty separate cells from a mockup or generate angle-specific top/bottom/side slots. The reusable sprite contains the rim, shallow symmetric inset walls and centered iron backplate. It supplies the depth without a shared scene vanishing point. Its transparent padding is part of the canvas; do not trim it or squeeze gutters away.

Draw order:

1. Existing world/UI backdrop policy. If using a dim scrim, it must not disable or dim away the source backpack needed for transfers.
2. The complete blank vault shell.
3. Twenty normal cubby instances, in row-major order.
4. Optional slot tint overlays at the same rectangles.
5. Existing item icons and stack labels.
6. Header, live occupancy, footer and close glyph.
7. Any existing tooltip/drag ghost/focus layer that needs to appear over both windows.

Only the grid slots and close control receive actions. Transparent outside padding and the decorative door must not become extra storage/drop targets. Do not let a whole-window drag handler intercept item drags or close clicks. Use existing window movement behavior if the game already has it.

## Items, counts and text

Use existing full-color inventory sprites unchanged. There is **no new item icon** in this package and no runtime icon desaturation, posterization or tint treatment. Resolve item artwork through the same item registry as the backpack. Preserve the whole image, aspect ratio and normal color; use contain fitting inside the slot-relative **(14,14,76,76)** item rectangle. Keep the icon and its stack label above the cubby overlays. Hover/drop tint should not wash out the item art.

The example stack count anchor is slot-relative **(88,85)**, right-aligned, 16px UI serif, cream `#f7e9cd` with a small dark outline/shadow for legibility. Hide quantity1 if that matches current inventory behavior. Use the same conventions, tooltips and rarity indications as the existing backpack rather than introducing a new item presentation system.

Occupancy is **occupied storage slots / 20**, not the sum of stack quantities. For example, a stack of194 logs, a stack of4 bread, a stack of4 hide and one sword display **4 / 20**. A partial stack is still one occupied slot. Read the actual container state; do not hardcode preview quantities or sample data.

All labels are dynamic. Reuse the shipped Wanderer’s Kit UI serif. Preview text uses DejaVu Serif only for review and is not a new bundled game font. Defaults: title30px bold, occupancy30px, footer18px, stack count16px. Header/footer/close color is `#f5e4ba`; occupancy color is `#49301b`.

Center “Bank Vault” within the header field, and the occupancy string within its field. The footer is two centered lines: “Drag items between your backpack” and “and the vault.” Do not widen the stone frame to keep that sentence on one line. For localization, measure within the supplied fields and wrap or reduce font size before allowing labels to touch plaque bevels, rivets or stone joints. A missing item icon can remain blank with its tooltip; do not fabricate art.

## Interaction states

Keep one normal painted cubby. The white masks are alpha coverage for ordinary UI tint overlays, not additional physical frame variants. They have the same256px canvas and logical placement as the normal cubby. Normal tint values from `layout.json`:

| State | Mask / treatment |
|---|---|
| Hover | Inner mask, `#eee2ca`, opacity0.10 |
| Selected | Rim mask, `#d6b96a`, opacity0.42 |
| Keyboard focus | Rim mask, `#f4e1ae`, opacity0.58 |
| Valid drop | Inner mask, `#6e995e`, opacity0.24 |
| Invalid drop | Inner mask, `#c2574b`, opacity0.24 |
| Unavailable | Multiply normal cubby RGB by0.68; alpha unchanged |

Place normal art first, then draw a solid tint color through the selected mask’s alpha, multiplied by the opacity. Keep all masks unrotated and exactly aligned with the same104px rectangle. Only apply the highest-priority inner feedback at a time (drop state takes precedence over hover); focus/selection can retain a rim cue. Do not add perspective/shadow changes by row or move the cubby when pressed. No pressed geometry requires a separate painted image.

The close background is already in the shell. Place `close-face-mask.png` over the close rectangle for hover (`#fff0d5`,0.12) or pressed (`#100b08`,0.25), then draw the cream X above it. The mask stays inset from the brass rim. Center the64px glyph on a canvas about78% of the close rectangle’s width/height; its stroke shape has internal padding. Do not move the embedded frame out of the stone to simulate pressing.

## Storage binding

Set the vault UI capacity to **20**, not40. Bind indices0–19 to this vault container, and keep the player inventory/backpack bound separately. Reuse existing crate/storage operations for drag/drop, stack merge/split, transfers, tooltips, ownership and persistence, with the bank’s actual container identifier. The illustrations and slot backgrounds do not own item state.

Use the same4×5 reading order as the backpack. A drop target comes from the corresponding live slot rectangle, not the decorative backplate as a whole. Gutters are not extra slots. Validate moves through existing game commands, including occupied targets and full containers; update both panels from authoritative results. Do not lose or duplicate items on a rejected move or interrupted drag. Reuse any already supported transfer shortcut; this art does not introduce a new shortcut, transaction fee, account-balance UI or sort/deposit button.

Preserve storage independently of window visibility. Closing/reopening must not clear items. ESC and the close control should use the existing storage-window close policy and cancel/resolve any drag through existing input rules. Keep pointer interaction with the open backpack available while preventing unintended world clicks through the vault’s controls. Initial scope is desktop PC.

## Review and validation

`previews/assembly-empty-1920x1080.png` and `assembly-populated-1920x1080.png` are composed from the exported runtime art. The transparent assembly PNGs show the same window without scenery. `asset-contact-sheet.png` shows all six production pieces against a checker; `interaction-states.png` demonstrates runtime tints. The four existing item sprites used in the populated preview are not duplicated into `assets/`. The cropped/dimmed bank scene is only a preview backdrop.

`reference/approved-vault-4x5.png` preserves the approved mockup. `reference/PROMPTS.json` records the built-in image-edit prompts. Technical finishing includes silhouette/stray-alpha cleanup, safe padding and uniform fitting. The production PNGs preserve the generated masters’ material RGB during cutting; no per-row material grades are introduced.

`validation.json` records dimensions, alpha safety borders, transparent RGB cleanup, asset hashes,20-slot capacity, one shared slot reference and grid containment. Every package PNG is decoded and every JSON file parsed before packing; the ZIP receives a CRC check. The assembly was visually checked for complete door/frame edges, attached hinges, unclipped rivets, consistent slot views and text/item containment. Actual in-game font metrics, DPI/layout alongside the backpack, pointer input and storage-command integration remain application checks for the coding agent.
