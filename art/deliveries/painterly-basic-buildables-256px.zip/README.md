# Basic buildable icons — painterly 256×256

Five individual icons: `build-wood-floor`, `build-stone-floor`, `build-log-wall`, `build-stucco-wall`, and `build-stone-wall`, each suffixed `-painterly-256x256.png`.

The icons are 256×256 RGBA with transparent backgrounds and strictly binary alpha (0 or 255). Import each image as a standalone texture and preserve alpha and square aspect ratio. Use mipmaps or suitable texture filtering when displaying at smaller sizes. No UI border or background is baked in.

The walls and floor tiles follow the game's classic isometric 2:1 visual direction: vertical walls, receding top edges with a 1:2 rise-to-run angle. These are painterly illustrations rather than tileable level geometry, so use them as inventory/build menu icons. The 72px preview is for legibility review.

Artwork created with built-in image generation using the earlier 64px build icons as shape references and the painterly wood/stone resources as material references; final cutouts were resized and their alpha thresholded at 128.
